package com.welby.hae.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.welby.hae.R;
import com.welby.hae.model.Photo;
import com.welby.hae.utils.Define;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by WelbyDev.
 */

public class CameraRollAdapter extends RecyclerView.Adapter<CameraRollAdapter.CamRollViewHolder> {
    private final int numberOfSelectablePhotos;
    private List<Photo> photoList;
    private List<Integer> pickedPositions;
    private int cellSize; //size of item in pixel (picture)
    private CameraRollListener listener;

    public interface CameraRollListener {
        void onItemClick(int position);
    }

    public void setOnItemClickListener(final CameraRollListener listener) {
        this.listener = listener;
    }

    public CameraRollAdapter(List<Photo> photoList, int cellSize, int numberOfSelectablePhotos, List<Integer> pickedPositions) {
        this.photoList = photoList;
        this.cellSize = cellSize;
        this.numberOfSelectablePhotos = numberOfSelectablePhotos;
        this.pickedPositions = pickedPositions;
    }

    @Override
    public CamRollViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new CamRollViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.camera_roll_item, parent, false));
    }

    @Override
    public void onBindViewHolder(CamRollViewHolder holder, int position) {
        final int pos = position;

        holder.itemView.setLayoutParams(new GridView.LayoutParams(cellSize, cellSize));
        Glide.with(holder.itemView)
                .load(photoList.get(pos).getPath())
                .into(holder.ivThumbnail);

        if (pickedPositions.contains(pos)) {
            holder.tvPickedPos.setText(String.valueOf(pickedPositions.indexOf(pos) + 1));
            holder.tvPickedPos.setBackgroundResource(R.drawable.ic_image_selected);
        } else {
            holder.tvPickedPos.setText(Define.STR_EMPTY);
            holder.tvPickedPos.setBackgroundResource(R.drawable.ic_image_unselect);
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (listener == null) {
                    return;
                }
                listener.onItemClick(pos);
            }
        });
    }

    @Override
    public int getItemCount() {
        return photoList.size();
    }

    class CamRollViewHolder extends RecyclerView.ViewHolder {
        ImageView ivThumbnail;
        TextView tvPickedPos;

        private CamRollViewHolder(View itemView) {
            super(itemView);
            ivThumbnail = itemView.findViewById(R.id.iv_thumbnail);
            tvPickedPos = itemView.findViewById(R.id.tv_picked_pos);
        }
    }

    public void setItemSelected(int pos) {
        if (pickedPositions.contains(pos)) {
            pickedPositions.remove(pickedPositions.indexOf(pos));
            for (int i = 0; i < pickedPositions.size(); i++) {
                notifyItemChanged(pickedPositions.get(i));
            }
            notifyItemChanged(pos);
        } else {
            if (pickedPositions.size() == numberOfSelectablePhotos) {
                return;
            }
            pickedPositions.add(pos);
            notifyItemChanged(pos);
        }
    }

    public int getNumberOfPickedPhotos() {
        return pickedPositions.size();
    }

    public ArrayList<Photo> getPickedPhotos() {
        ArrayList<Photo> pickedPhotoList = new ArrayList<>();
        for (Integer pickedPos : pickedPositions) {
            pickedPhotoList.add(photoList.get(pickedPos));
        }
        return pickedPhotoList;
    }
}
