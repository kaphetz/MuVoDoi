package com.welby.hae.adapter;

import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.welby.hae.R;

/**
 * Created by WelbyDev.
 */

public class HomeDrawerAdapter extends RecyclerView.Adapter<HomeDrawerAdapter.DrawerViewHolder> {
    private static final int VIEW_TYPE_ITEM = 0;
    private static final int VIEW_TYPE_LABEL = 1;
    private static final int VIEW_TYPE_VERSION = 2;

    private String[] list;
    private OnItemClickListener listener;
    private int selectedPosition = -1; //initialized position = -1

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public HomeDrawerAdapter(String[] list) {
        this.list = list;
    }

    @Override
    public DrawerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_ITEM) {
            return new DrawerViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.main_drawer_item, parent, false));
        } else if (viewType == VIEW_TYPE_LABEL) {
            return new DrawerViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.main_drawer_item_label, parent, false));
        } else {
            return new DrawerViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.main_drawer_item_version, parent, false));
        }
    }

    @Override
    public void onBindViewHolder(DrawerViewHolder holder, int position) {
        final int pos = position;
        holder.tvTitle.setText(list[pos]);
        if (getItemViewType(position) == VIEW_TYPE_ITEM) {
            //set icon
            switch (pos) {
                case 0:
                    holder.tvTitle.setCompoundDrawablesWithIntrinsicBounds(ContextCompat.getDrawable(holder.tvTitle.getContext(), R.drawable.ic_drawer_home)
                            , null, ContextCompat.getDrawable(holder.tvTitle.getContext(), R.drawable.ic_drawer_arrow), null);
                    if (pos == selectedPosition) {
                        holder.tvTitle.setBackgroundResource(R.drawable.bg_drawer_item_rounded_selected);
                    } else {
                        holder.tvTitle.setBackgroundResource(R.drawable.bg_drawer_item_rounded);
                    }
                    break;
                case 1:
                    holder.tvTitle.setCompoundDrawablesWithIntrinsicBounds(ContextCompat.getDrawable(holder.tvTitle.getContext(), R.drawable.ic_drawer_edit)
                            , null, ContextCompat.getDrawable(holder.tvTitle.getContext(), R.drawable.ic_drawer_arrow), null);
                    if (pos == selectedPosition) {
                        holder.tvTitle.setBackgroundResource(R.drawable.bg_drawer_item_selected);
                    } else {
                        holder.tvTitle.setBackgroundResource(R.drawable.bg_drawer_item);
                    }
                    break;
                case 2:
                    holder.tvTitle.setCompoundDrawablesWithIntrinsicBounds(ContextCompat.getDrawable(holder.tvTitle.getContext(), R.drawable.ic_drawer_graph)
                            , null, ContextCompat.getDrawable(holder.tvTitle.getContext(), R.drawable.ic_drawer_arrow), null);
                    if (pos == selectedPosition) {
                        holder.tvTitle.setBackgroundResource(R.drawable.bg_drawer_item_selected);
                    } else {
                        holder.tvTitle.setBackgroundResource(R.drawable.bg_drawer_item);
                    }
                    break;
                case 3:
                    holder.tvTitle.setCompoundDrawablesWithIntrinsicBounds(ContextCompat.getDrawable(holder.tvTitle.getContext(), R.drawable.ic_drawer_guide)
                            , null, ContextCompat.getDrawable(holder.tvTitle.getContext(), R.drawable.ic_drawer_dup), null);
                    if (pos == selectedPosition) {
                        holder.tvTitle.setBackgroundResource(R.drawable.bg_drawer_item_selected);
                    } else {
                        holder.tvTitle.setBackgroundResource(R.drawable.bg_drawer_item);
                    }
                    break;
                case 4:
                    holder.tvTitle.setCompoundDrawablesWithIntrinsicBounds(null, null, null, null);
                    break;
                case 5:
                    holder.tvTitle.setCompoundDrawablesWithIntrinsicBounds(ContextCompat.getDrawable(holder.tvTitle.getContext(), R.drawable.ic_drawer_share)
                            , null, ContextCompat.getDrawable(holder.tvTitle.getContext(), R.drawable.ic_drawer_arrow), null);
                    if (pos == selectedPosition) {
                        holder.tvTitle.setBackgroundResource(R.drawable.bg_drawer_item_selected);
                    } else {
                        holder.tvTitle.setBackgroundResource(R.drawable.bg_drawer_item);
                    }
                    break;
                case 6:
                    holder.tvTitle.setCompoundDrawablesWithIntrinsicBounds(ContextCompat.getDrawable(holder.tvTitle.getContext(), R.drawable.ic_drawer_tree)
                            , null, ContextCompat.getDrawable(holder.tvTitle.getContext(), R.drawable.ic_drawer_arrow), null);
                    if (pos == selectedPosition) {
                        holder.tvTitle.setBackgroundResource(R.drawable.bg_drawer_item_selected);
                    } else {
                        holder.tvTitle.setBackgroundResource(R.drawable.bg_drawer_item);
                    }
                    break;
                case 7:
                    holder.tvTitle.setCompoundDrawablesWithIntrinsicBounds(null, null, null, null);
                    break;
                case 8:
                case 9:
                case 10:
                    holder.tvTitle.setCompoundDrawablesWithIntrinsicBounds(null, null, ContextCompat.getDrawable(holder.tvTitle.getContext(), R.drawable.ic_drawer_arrow), null);
                    if (pos == selectedPosition) {
                        holder.tvTitle.setBackgroundResource(R.drawable.bg_drawer_item_selected);
                    } else {
                        holder.tvTitle.setBackgroundResource(R.drawable.bg_drawer_item);
                    }
                    break;
                case 11:
                    holder.tvTitle.setCompoundDrawablesWithIntrinsicBounds(null, null, ContextCompat.getDrawable(holder.tvTitle.getContext(), R.drawable.ic_drawer_dup), null);
                    if (pos == selectedPosition) {
                        holder.tvTitle.setBackgroundResource(R.drawable.bg_drawer_item_selected);
                    } else {
                        holder.tvTitle.setBackgroundResource(R.drawable.bg_drawer_item);
                    }
                    break;
                case 12:
                    holder.tvTitle.setCompoundDrawablesWithIntrinsicBounds(null, null, null, null);
                    break;
                default:
                    break;
            }
            //set listener
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (listener != null) {
                        listener.onItemClick(pos);
                    }
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return list.length;
    }

    @Override
    public int getItemViewType(int position) {
        if (position == 4 || position == 7) { //label position
            return VIEW_TYPE_LABEL;
        } else if (position == list.length - 1) { //version position
            return VIEW_TYPE_VERSION;
        } else {
            return VIEW_TYPE_ITEM;
        }
    }

    class DrawerViewHolder extends RecyclerView.ViewHolder {

        TextView tvTitle;

        private DrawerViewHolder(View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tv_title);
        }
    }

    public int getSelectedPosition() {
        return selectedPosition;
    }

    public void setSelectedPosition(int position) {
        if (selectedPosition >= 0) {
            notifyItemChanged(selectedPosition);
        }
        selectedPosition = position;
        notifyItemChanged(selectedPosition);
    }
}
