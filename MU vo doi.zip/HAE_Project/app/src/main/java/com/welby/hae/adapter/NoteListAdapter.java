package com.welby.hae.adapter;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.welby.hae.HAEApplication;
import com.welby.hae.R;
import com.welby.hae.data.db.helper.RealmManager;
import com.welby.hae.data.db.model.PartDetail;
import com.welby.hae.data.db.model.Symptom;
import com.welby.hae.data.db.model.SymptomPartRelation;
import com.welby.hae.utils.Define;
import com.welby.hae.utils.RLog;
import com.welby.hae.utils.StringUtil;
import com.welby.hae.utils.TimeUtil;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Created by WelbyDev.
 */

public class NoteListAdapter extends RecyclerView.Adapter<NoteListAdapter.NoteViewHolder> {
    private List<Symptom> symptomList;
    private Context context;
    private String[] partLabels;
    private boolean isCalendarList;
    private OnItemClickListener onItemClickListener;

    public void setOnItemClickListener(OnItemClickListener onItemClickListener){
        this.onItemClickListener = onItemClickListener;
    }

    public interface OnItemClickListener {
        void onClick(Symptom symptom);
    }

    class NoteViewHolder extends RecyclerView.ViewHolder {
        private TextView noteTitle;
        private TextView noteDesciption;
        private ImageView treatmentStatus;
        private ImageView photoStatus;
        private ImageView memoStatus;
        private RelativeLayout rootView;

        NoteViewHolder(View view) {
            super(view);
            noteTitle = view.findViewById(R.id.note_title);
            noteDesciption = view.findViewById(R.id.note_description);
            treatmentStatus = view.findViewById(R.id.note_medical_img);
            photoStatus = view.findViewById(R.id.note_photo_img);
            memoStatus = view.findViewById(R.id.note_memo_img);
            rootView = view.findViewById(R.id.item_note_list);
        }
    }

    public NoteListAdapter(Context context, List<Symptom> symptomList, boolean isCalendarList) {
        this.context = context;
        this.symptomList = symptomList;
        this.isCalendarList = isCalendarList;
        partLabels = context.getResources().getStringArray(R.array.graph_part_category);
    }

    @Override
    public NoteViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.item_note_list, parent, false);

        return new NoteViewHolder(view);
    }

    @Override
    public void onBindViewHolder(NoteViewHolder holder, final int position) {
        final Symptom symptom = symptomList.get(position);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(symptom.getSeizureStartDate());

        if (!isCalendarList) {
            Calendar now = Calendar.getInstance();
            Calendar symptomDate = TimeUtil.dateToCalendar(symptom.getModified());
            Calendar nextDate = Calendar.getInstance();
            nextDate.setTime(symptomDate.getTime());
            nextDate.add(Calendar.DAY_OF_MONTH, 1);
            nextDate.set(Calendar.HOUR_OF_DAY, 0);
            nextDate.set(Calendar.MINUTE, 0);
            nextDate.set(Calendar.SECOND, 0);
            nextDate.set(Calendar.MILLISECOND, 0);

            Calendar endDate = Calendar.getInstance();
            endDate.setTime(symptomDate.getTime());
            endDate.add(Calendar.DAY_OF_MONTH, 2);
            endDate.set(Calendar.HOUR_OF_DAY, 0);
            endDate.set(Calendar.MINUTE, 0);
            endDate.set(Calendar.SECOND, 0);
            endDate.set(Calendar.MILLISECOND, 0);

            if (symptomDate.getTimeInMillis() + 21600000 > nextDate.getTimeInMillis()) { // 6 hours = 21600000ms
                if (now.getTimeInMillis() < endDate.getTimeInMillis()) {
                    holder.rootView.setBackgroundColor(ContextCompat.getColor(context, R.color.list_selected_color));
                } else {
                    holder.rootView.setBackgroundColor(ContextCompat.getColor(context, android.R.color.transparent));
                }
            } else {
                if (now.getTimeInMillis() < nextDate.getTimeInMillis()) {
                    holder.rootView.setBackgroundColor(ContextCompat.getColor(context, R.color.list_selected_color));
                } else {
                    holder.rootView.setBackgroundColor(ContextCompat.getColor(context, android.R.color.transparent));
                }
            }
        }

        holder.noteTitle.setText(context.getString(R.string.calendar_list_item_time
                ,TimeUtil.getTime(TimeUtil.FORMAT_4, symptom.getSeizureStartDate())
                ,StringUtil.convertDayOfWeekToString(context, calendar.get(Calendar.DAY_OF_WEEK))
                ,TimeUtil.getTime(TimeUtil.FORMAT_6, symptom.getSeizureStartDate())));
        if (symptom.getTreatmentFlag() == 1) {
            holder.treatmentStatus.setVisibility(View.VISIBLE);
        } else {
            holder.treatmentStatus.setVisibility(View.GONE);
        }

        if (!symptom.getSymptomPhotos().isEmpty()) {
            holder.photoStatus.setVisibility(View.VISIBLE);
        } else {
            holder.photoStatus.setVisibility(View.GONE);
        }

        if (null != symptom.getMemo() && !symptom.getMemo().isEmpty()) {
            holder.memoStatus.setVisibility(View.VISIBLE);
        } else {
            holder.memoStatus.setVisibility(View.GONE);
        }
        List<SymptomPartRelation> symptomPartRelationList = symptom.getSymptomPartRelations();
        holder.noteDesciption.setText(convertPartDetailToGroup(symptomPartRelationList));

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(onItemClickListener != null){
                    onItemClickListener.onClick(symptom);
                    HAEApplication.getInstance().trackEvent(context.getString(R.string.event_list_tap));
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return symptomList.size();
    }

    private String convertPartDetailToGroup(List<SymptomPartRelation> symptomPartRelationList) {
        String value = "";
        float[] partVals = new float[7];
        for (SymptomPartRelation symptomPartRelation : symptomPartRelationList) {
            int partDetailId = symptomPartRelation.getPartDetailId();
            if (partDetailId == 7) {
                partVals[1]++;
            } else {
                PartDetail partDetail = RealmManager.getRealmManager().getPartDetailFromId(partDetailId);
                switch (partDetail.getPartId()) {
                    case Define.BodyPart.FACE:
                        partVals[0]++;
                        break;
                    case Define.BodyPart.BODY:
                    case Define.BodyPart.BODY_BACK:
                        partVals[2]++;
                        break;
                    case Define.BodyPart.LEFT_ARM:
                    case Define.BodyPart.RIGHT_ARM:
                        partVals[3]++;
                        break;
                    case Define.BodyPart.LEFT_FINGER:
                    case Define.BodyPart.RIGHT_FINGER:
                        partVals[4]++;
                        break;
                    case Define.BodyPart.LEFT_TOE:
                    case Define.BodyPart.RIGHT_TOE:
                        partVals[5]++;
                        break;
                    case Define.BodyPart.LEFT_LEG:
                    case Define.BodyPart.LEFT_LEG_BACK:
                    case Define.BodyPart.RIGHT_LEG:
                    case Define.BodyPart.RIGHT_LEG_BACK:
                        partVals[6]++;
                        break;
                    default:
                        break;
                }
            }
        }

        for (int i = 0; i < partVals.length; i++) {
            if (partVals[i] != 0) {
                if (value.isEmpty()) {
                    value += partLabels[i];
                } else {
                    value += "／" + partLabels[i];
                }
            }
        }

        return value;
    }
}