package com.welby.hae.adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import com.welby.hae.data.db.model.Symptom;
import com.welby.hae.ui.calendar.list.content.NoteListFragment;

import java.util.List;

/**
 * Created by WelbyDev.
 */

public class NoteListPagerAdapter extends FragmentStatePagerAdapter {
    public static int LOOPS_COUNT = 500;
    private List<Symptom> symptomList;

    public NoteListPagerAdapter(FragmentManager fragmentManager, List<Symptom> symptomList) {
        super(fragmentManager);
        this.symptomList = symptomList;
    }

    @Override
    public Fragment getItem(int position) {
        return NoteListFragment.newInstance(symptomList);
    }

    @Override
    public int getCount() {
        return LOOPS_COUNT;
    }
}
