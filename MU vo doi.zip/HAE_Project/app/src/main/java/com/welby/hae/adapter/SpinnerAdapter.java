package com.welby.hae.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.welby.hae.R;

/**
 * Created by Welby Dev on 10/9/2017.
 */

public class SpinnerAdapter extends ArrayAdapter<String> {
    private Context mContext;
    private int mView;
    private String[] mResource;

    public SpinnerAdapter(Context context, int view, String[] resource) {
        super(context, view, resource);
        mContext = context;
        mView = view;
        mResource = resource;
    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return getCustomView(position, convertView, parent);
    }

    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return getCustomView(position, convertView, parent);
    }


    private View getCustomView(int position, View convertView, ViewGroup parent) {
        String item = mResource[position];

        convertView = LayoutInflater.from(mContext).inflate(mView, parent, false);
        TextView tvItem = (TextView) convertView.findViewById(R.id.tv_item);
        if (item != null) {
            tvItem.setText(item);
        }
        return convertView;
    }

    @Override
    public int getCount() {
        return mResource.length;
    }

    @Nullable
    @Override
    public String getItem(int position) {
        return mResource[position];
    }
}
