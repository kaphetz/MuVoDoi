package com.welby.hae.adapter;

import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import com.welby.hae.R;
import com.welby.hae.model.SymptomItem;
import com.welby.hae.ui.custom.CircularTextView;

import java.util.List;

/**
 * Created by WelbyDev.
 */

public class SymptomItemListAdapter extends RecyclerView.Adapter<SymptomItemListAdapter.ViewHolder> {

    private List<SymptomItem> symptomItemList;
    private boolean editable = true;

    public SymptomItemListAdapter(List<SymptomItem> symptomItemList, boolean editable) {
        this.symptomItemList = symptomItemList;
        this.editable = editable;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.symptom_item, parent, false));
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        final int pos = position;
        boolean isChosen = symptomItemList.get(pos).isChosen();
        holder.cbSymptom.setChecked(isChosen);
        holder.tvName.setText(symptomItemList.get(pos).getName());
        holder.tvIndex.setText(String.valueOf(symptomItemList.get(pos).getDetailPartId()));
        holder.cbSymptom.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                symptomItemList.get(pos).setChosen(isChecked);
            }
        });
        holder.cbSymptom.setEnabled(editable);
    }

    @Override
    public int getItemCount() {
        return symptomItemList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        CheckBox cbSymptom;
        CircularTextView tvIndex;
        TextView tvName;

        ViewHolder(View itemView) {
            super(itemView);
            cbSymptom = itemView.findViewById(R.id.cb_chooser);
            tvIndex = itemView.findViewById(R.id.tv_index);
            tvName = itemView.findViewById(R.id.tv_name);
            tvIndex.setSolidColor(ContextCompat.getColor(itemView.getContext(), R.color.orange_dark));
        }
    }

}
