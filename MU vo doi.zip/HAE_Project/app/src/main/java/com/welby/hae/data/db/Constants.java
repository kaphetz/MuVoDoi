package com.welby.hae.data.db;

/**
 * Created by Welby Dev on 10/9/2017.
 * File name: Constants
 */

public class Constants {
    public static final String RELATION_YOU = "you";
    public static final String RELATION_SPOUSE = "spouse";
    public static final String RELATION_FATHER = "father";
    public static final String RELATION_MOTHER = "mother";
    public static final String RELATION_SON = "son";
    public static final String RELATION_DAUGHTER = "daughter";
    public static final String RELATION_BROTHER = "brother";
    public static final String RELATION_SISTER = "sister";
    public static final String RELATION_GRAND_FATHER = "grandfather";
    public static final String RELATION_GRAND_MOTHER = "grandmother";
    public static final String RELATION_GRAND_CHILD = "grandchild";
    public static final String RELATION_UNCLE = "uncle";
    public static final String RELATION_AUNT = "aunt";
    public static final String RELATION_NEPHEW = "nephew";
    public static final String RELATION_NIECE = "niece";

    public static final String MAN = "man";
    public static final String WOMAN = "woman";





}
