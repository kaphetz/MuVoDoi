package com.welby.hae.data.db.helper;

import android.util.Log;

import com.welby.hae.data.db.Constants;
import com.welby.hae.data.db.model.Member;
import com.welby.hae.data.db.model.Relationship;
import com.welby.hae.utils.Field;

import java.util.Date;
import java.util.List;

import io.realm.Realm;
import io.realm.RealmList;
import io.realm.RealmResults;

/**
 * Created by Welby Dev on 10/16/2017.
 * File name: MemberHelper
 */

public class MemberHelper {

    private final String TAG = MemberHelper.class.getSimpleName();

    private Realm mRealm;
    private static MemberHelper memberHelper;

    public MemberHelper() {
        mRealm = RealmManager.getRealmManager().getRealm();
    }

    public static MemberHelper newInstance() {
        if (memberHelper == null) {
            memberHelper = new MemberHelper();
        }
        return memberHelper;
    }


    public int getNextMemberId() {
        try {
            Number number = mRealm.where(Member.class).max("id");
            if (number != null) {
                return number.intValue();
            } else {
                return 0;
            }
        } catch (ArrayIndexOutOfBoundsException e) {
            return 0;
        }
    }

    // clear all object

    public void clearAllRelationship() {
        mRealm.beginTransaction();
        mRealm.delete(Relationship.class);
        mRealm.commitTransaction();
    }

    public void clearAllMember() {
        mRealm.beginTransaction();
        mRealm.delete(Member.class);
        mRealm.commitTransaction();
    }

    // get all object in database
    public RealmResults<Relationship> getAllRelationship() {
        return mRealm.where(Relationship.class).findAll();
    }

    public RealmResults<Member> getAllMember() {
        return mRealm.where(Member.class).findAll();
    }

    // read data
    public Relationship getRelationship(int id) {
        return mRealm.where(Relationship.class).equalTo(Field.ID, id).findFirst();
    }

    //
    public Relationship getRelationshipByClassCode(String class_code) {
        return mRealm.where(Relationship.class).equalTo(Field.CLASS_CODE, class_code).findFirst();
    }


    public Member getMemberById(int id) {
        return mRealm.where(Member.class).equalTo(Field.ID, id).findFirst();
    }

    public Member getMemberByClassCodeWithYou(String class_code) {
        return mRealm.where(Member.class).equalTo(Field.RELATION_ID_WITH_YOU + "." + Field.CLASS_CODE, class_code).findFirst();
    }

    public Member getMemberByClassCodeWithCreator(String class_code) {
        return mRealm.where(Member.class).equalTo(Field.RELATION_ID_WITH_CREATER + "." + Field.CLASS_CODE, class_code).findFirst();
    }

    public RealmResults<Member> getListMemberInRelationWithYou(int creater_family_tree_id, String class_code) {
        return mRealm.where(Member.class)
                .equalTo(Field.CREATER_FAMILY_TREE_ID + "." + Field.ID, creater_family_tree_id)
                .equalTo(Field.RELATION_ID_WITH_YOU + "." + Field.CLASS_CODE, class_code)
                .findAll();
    }

    public RealmResults<Member> getListMemberOfFather(int father_family_tree_id) {
        return mRealm.where(Member.class)
                .equalTo(Field.FATHER_FAMILY_TREE_ID + "." + Field.ID, father_family_tree_id)
                .findAll();
    }


    public RealmResults<Member> getListMemberOfMother(int mother_family_tree_id) {
        return mRealm.where(Member.class)
                .equalTo(Field.MOTHER_FAMILY_TREE_ID + "." + Field.ID, mother_family_tree_id)
                .findAll();
    }

    public Member getMemberInRelationWithYou(int creater_family_tree_id, String class_code) {
        return mRealm.where(Member.class)
                .equalTo(Field.CREATER_FAMILY_TREE_ID + "." + Field.ID, creater_family_tree_id)
                .equalTo(Field.RELATION_ID_WITH_YOU + "." + Field.CLASS_CODE, class_code)
                .findFirst();
    }

    public Member getMemberInRelationWithCreator(int creater_family_tree_id, String class_code) {
        return mRealm.where(Member.class)
                .equalTo(Field.CREATER_FAMILY_TREE_ID + "." + Field.ID, creater_family_tree_id)
                .equalTo(Field.RELATION_ID_WITH_CREATER + "." + Field.CLASS_CODE, class_code)
                .findFirst();
    }

    public RealmResults<Member> getListMemberInDegreeOfRelationWithYou(int creater_family_tree_id, String class_code1, String class_code2) {
        return mRealm.where(Member.class)
                .equalTo(Field.CREATER_FAMILY_TREE_ID + "." + Field.ID, creater_family_tree_id)
                .equalTo(Field.RELATION_ID_WITH_YOU + "." + Field.CLASS_CODE, class_code1)
                .or()
                .equalTo(Field.CREATER_FAMILY_TREE_ID + "." + Field.ID, creater_family_tree_id)
                .equalTo(Field.RELATION_ID_WITH_YOU + "." + Field.CLASS_CODE, class_code2)
                .findAll();
    }

    public RealmResults<Member> getListMemberInDegreeOfRelationWithCreator(int creater_family_tree_id, String class_code1, String class_code2) {
        return mRealm.where(Member.class)
                .equalTo(Field.CREATER_FAMILY_TREE_ID + "." + Field.ID, creater_family_tree_id)
                .equalTo(Field.RELATION_ID_WITH_CREATER + "." + Field.CLASS_CODE, class_code1)
                .or()
                .equalTo(Field.CREATER_FAMILY_TREE_ID + "." + Field.ID, creater_family_tree_id)
                .equalTo(Field.RELATION_ID_WITH_CREATER + "." + Field.CLASS_CODE, class_code2)
                .findAll();
    }

    public RealmResults<Member> getListMemberByCreatorId(int creater_family_tree_id) {
        return mRealm.where(Member.class)
                .equalTo(Field.CREATER_FAMILY_TREE_ID + "." + Field.ID, creater_family_tree_id)
                .findAll();
    }


    public void updateMember(final Member member) {
        if (member != null) {
            mRealm.executeTransaction(new Realm.Transaction() {
                @Override
                public void execute(Realm realm) {

                    Member memberInDatabase = getMemberById(member.getId());
                    if (memberInDatabase != null) {
                        memberInDatabase.setHaeFlag(member.getHaeFlag());
                        memberInDatabase.setSynchronizeFlag(member.isSynchronizeFlag());
                        memberInDatabase.setFamilyTestFlag(member.isFamilyTestFlag());
                        memberInDatabase.setRelationshipIdWithYou(member.getRelationshipIdWithYou());
                        memberInDatabase.setRelationshipIdWithCreater(member.getRelationshipIdWithCreater());
                        memberInDatabase.setCreaterFamilyTreeId(member.getCreaterFamilyTreeId());
                        memberInDatabase.setFatherFamilyTreeId(member.getFatherFamilyTreeId());
                        memberInDatabase.setMotherFamilyTreeId(member.getMotherFamilyTreeId());
                        memberInDatabase.setGenderCode(member.getGenderCode());
                        memberInDatabase.setCreated(member.getCreated());
                        memberInDatabase.setCreated(member.getModified());
                    }
                }
            });
        }
    }

    public void updateHAEOfMember(int id, final int hae_flag) {
        final Member member = getMemberById(id);
        if (member != null) {
            mRealm.executeTransaction(new Realm.Transaction() {
                @Override
                public void execute(Realm realm) {
                    member.setHaeFlag(hae_flag);
                }
            });
        }
    }

    public void updateFTOfMember(int id, final boolean family_test_flag) {
        final Member member = getMemberById(id);
        if (member != null) {
            mRealm.executeTransaction(new Realm.Transaction() {
                @Override
                public void execute(Realm realm) {
                    member.setFamilyTestFlag(family_test_flag);
                }
            });
        }
    }


    public void deleteMemberById(int id) {
        final Member member = getMemberById(id);
        if (member != null) {
            mRealm.executeTransaction(new Realm.Transaction() {
                @Override
                public void execute(Realm realm) {
                    member.deleteFromRealm();
                }
            });
        }
    }

    public void deleteMemberByCreatorId(Member member) {
        if (member != null) {
            listMember.clear();
            RealmList<Member> listMemberDelete = getAllMemberRelativeByCreatorId(member.getId());
            if (!member.getRelationshipIdWithYou().getClassCode().equals(Constants.RELATION_YOU))
                listMemberDelete.add(member);
            if (listMemberDelete != null && !listMemberDelete.isEmpty()) {
                Log.d(TAG, "listMemberDelete_size: " + listMemberDelete.size());
                for (Member member1 : listMemberDelete) {
                    Log.d(TAG, "member_delete: " + member1.toString());
                    deleteMemberById(member1.getId());
                }

            }

        }
    }


    private RealmList<Member> listMember = new RealmList<>();

    public RealmList<Member> getAllMemberRelativeByCreatorId(int creater_family_tree_id) {
        RealmResults<Member> memberRelatives = getListMemberByCreatorId(creater_family_tree_id);
        listMember.addAll(memberRelatives);
        if (!memberRelatives.isEmpty()) {
            for (Member member : memberRelatives) {
                getAllMemberRelativeByCreatorId(member.getId());
            }
        }

        return listMember;
    }

    public void updateParentForMemberWhenAdd(final Member createrFamilyTreeId, final Member value_update, String class_code1, String class_code2) {
        if (createrFamilyTreeId != null && value_update != null) {
            final Member value_update1 = MemberHelper.newInstance().getMemberById(value_update.getId());
            final RealmResults<Member> listMemberUpdateWhenAdd = getListMemberInDegreeOfRelationWithCreator(createrFamilyTreeId.getId(), class_code1, class_code2);
            if (listMemberUpdateWhenAdd != null && listMemberUpdateWhenAdd.size() > 0 && value_update1 != null) {
                mRealm.executeTransaction(new Realm.Transaction() {
                    @Override
                    public void execute(Realm realm) {
                        for (Member member : listMemberUpdateWhenAdd) {
                            Log.d(TAG, "member_update_w_add: " + member);
                            if (value_update.isMan()) {
                                member.setFatherFamilyTreeId(value_update1);
                            } else {
                                member.setMotherFamilyTreeId(value_update1);
                            }
                            member.setModified(new Date(System.currentTimeMillis()));
                        }
                    }
                });
            }
        }
    }


    public void updateParentForMemberWhenDelete(final Member memberCreator) {
        Log.d(TAG, "updateParentForMemberWhenDelete");
        if (memberCreator != null) {
            final RealmResults<Member> listMemberUpdate = memberCreator.isMan() ? getListMemberOfFather(memberCreator.getId()) : getListMemberOfMother(memberCreator.getId());
            if (listMemberUpdate != null && listMemberUpdate.size() > 0) {
                mRealm.executeTransaction(new Realm.Transaction() {
                    @Override
                    public void execute(Realm realm) {
                        for (Member member : listMemberUpdate) {
                            Log.d(TAG, "member_update: " + member);
                            if (memberCreator.getGenderCode().equals(Constants.MAN)) {
                                member.setFatherFamilyTreeId(null);
                            } else if (memberCreator.getGenderCode().equals(Constants.WOMAN)) {
                                member.setMotherFamilyTreeId(null);
                            }
                            member.setModified(new Date(System.currentTimeMillis()));
                        }
                    }
                });
            }
        }
    }

    public Member getDataFamilyTree() {
        RealmManager.getRealmManager().refresh();
        return getMemberByClassCodeWithYou(Constants.RELATION_YOU);
    }

    public void updateYouWhenChangeGender(final String gender) {
        if (gender != null && !gender.isEmpty()) {
            final Member you = getMemberByClassCodeWithYou(Constants.RELATION_YOU);
            if (you != null) {
                String genderOfYou = you.getGenderCode();
                if (!gender.equals(genderOfYou)) {
                    Log.d(TAG, "Update for you");
                    final String genderOfSpouse;
                    if (Constants.MAN.equals(gender)) {
                        genderOfSpouse = Constants.WOMAN;
                    } else {
                        genderOfSpouse = Constants.MAN;
                    }
                    final Date dateModified = new Date(System.currentTimeMillis());

                    mRealm.executeTransaction(new Realm.Transaction() {
                        @Override
                        public void execute(Realm realm) {
                            you.setGenderCode(gender);
                            you.setModified(dateModified);

                            Member spouse = getMemberByClassCodeWithYou(Constants.RELATION_SPOUSE);
                            if (spouse != null) {
                                spouse.setGenderCode(genderOfSpouse);
                                spouse.setModified(dateModified);
                            }

                            RealmResults<Member> children = getListMemberInDegreeOfRelationWithYou(you.getId(), Constants.RELATION_SON, Constants.RELATION_DAUGHTER);
                            if (children != null && !children.isEmpty()) {
                                for (Member child : children) {
                                    if (Constants.MAN.equals(gender)) {
                                        child.setFatherFamilyTreeId(you);
                                        child.setMotherFamilyTreeId(spouse);
                                    } else {
                                        child.setMotherFamilyTreeId(you);
                                        child.setFatherFamilyTreeId(spouse);
                                    }
                                    child.setModified(dateModified);
                                }
                            }

                        }
                    });


                } else {
                    Log.d(TAG, "Not update, because of the gender not change");
                }
            }

        }
    }


}
