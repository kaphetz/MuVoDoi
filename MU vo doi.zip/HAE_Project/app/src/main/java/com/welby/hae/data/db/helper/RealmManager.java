package com.welby.hae.data.db.helper;

import android.app.Activity;
import android.app.Application;
import android.app.Service;
import android.content.Context;
import android.support.v4.app.Fragment;

import com.welby.hae.R;
import com.welby.hae.data.db.model.Medication;
import com.welby.hae.data.db.model.Part;
import com.welby.hae.data.db.model.PartDetail;
import com.welby.hae.data.db.model.Relationship;
import com.welby.hae.data.db.model.Symptom;
import com.welby.hae.data.db.model.SymptomPartRelation;
import com.welby.hae.utils.Field;
import com.welby.hae.utils.FileUtil;

import java.util.ArrayList;
import java.util.Calendar;

import io.realm.Realm;
import io.realm.RealmQuery;
import io.realm.RealmResults;
import io.realm.Sort;

/**
 * Created by WelbyDev.
 * Filename RealmManager
 */

public class RealmManager {

    private final String TAG = RealmManager.class.getSimpleName();


    private static RealmManager realmManager;
    private final Realm realm;
    private static Context context;

    private static SymptomHelper symptomHelper;

    public RealmManager(Application application) {
        realm = Realm.getDefaultInstance();
    }

    public RealmManager with(Fragment fragment) {
        context = fragment.getContext();
        if (null == realmManager) {
            realmManager = new RealmManager(fragment.getActivity().getApplication());
        }
        return realmManager;
    }

    public static RealmManager with(Activity activity) {
        context = activity;
        if (null == realmManager) {
            realmManager = new RealmManager(activity.getApplication());
        }
        return realmManager;
    }

    public static RealmManager with(Application application) {
        context = application;
        if (realmManager == null) {
            realmManager = new RealmManager(application);
        }
        return realmManager;
    }

    public static RealmManager getRealmManager() {
        return realmManager;
    }

    public Realm getRealm() {
        return realm;
    }

    // refresh the realm instance
    public void refresh() {
        realm.refresh();
    }

    // get all medication
    public RealmResults<Medication> getMediacations() {
        return realm.where(Medication.class).findAll();
    }

    // get all parts
    public RealmResults<Part> getParts() {
        return realm.where(Part.class).findAll();
    }

    // get all partdetais
    public RealmResults<PartDetail> getPartDetails() {
        return realm.where(PartDetail.class).findAll();
    }

    // get all relationships
    public RealmResults<Relationship> getRelationships() {
        return realm.where(Relationship.class).findAll();
    }

    //action
    public void initData() {
        // medications
        ArrayList<Medication> medications = FileUtil.getInstance().readDataFromFile(context, R.raw.mediacation);
        ArrayList<Part> parts = FileUtil.getInstance().readDataFromFile(context, R.raw.part);
        ArrayList<PartDetail> partDetails = FileUtil.getInstance().readDataFromFile(context, R.raw.part_detail);
        ArrayList<Relationship> relationships = FileUtil.getInstance().readDataFromFile(context, R.raw.relationship);

        // medications
        for (Medication medicationData : medications) {
            realm.beginTransaction();
            realm.copyToRealm(medicationData);
            realm.commitTransaction();
        }

        // parts
        for (Part part : parts) {
            realm.beginTransaction();
            realm.copyToRealm(part);
            realm.commitTransaction();
        }

        // partDetails
        for (PartDetail partDetail : partDetails) {
            realm.beginTransaction();
            realm.copyToRealm(partDetail);
            realm.commitTransaction();
        }

        // relationships
        for (Relationship relationship : relationships) {
            realm.beginTransaction();
            realm.copyToRealm(relationship);
            realm.commitTransaction();
        }
    }

    public int getNextId(Class clazz) {
        Number currentMax = realm.where(clazz).max(Field.ID);
        int nextId = 0;
        if (currentMax != null) {
            nextId = currentMax.intValue() + 1;
        }
        return nextId;
    }




    public SymptomHelper getSymptomHelper() {
        if (symptomHelper == null) {
            symptomHelper = new SymptomHelper(realm);
        }
        return symptomHelper;
    }

    /*----------------------CALENDAR START----------------------------*/

    /**
     * get All Symptom records
     * @return
     */
    public RealmResults<Symptom> getAllSymptoms() {
        return realm.where(Symptom.class).findAll();
    }

    /**
     * get All Symptom records with treatment flag (1: あり, 2: なし)
     * @param treatmentFlag : has or hasn't treatment
     * @return
     */
    public RealmResults<Symptom> getAllSymptomWithTreatment(int treatmentFlag) {
        return realm.where(Symptom.class).equalTo(Field.TREATMENT_FLAG, treatmentFlag).findAll();
    }

    /**
     * get All Symptom records in monthSelected
     * @param month : is monthSelected query
     * @param year : is yearSelected query
     * @return
     */
    public RealmResults<Symptom> getAllSymptomInMonth(int month, int year) {
        Calendar queryCalendar = Calendar.getInstance();
        queryCalendar.set(Calendar.DAY_OF_MONTH, 1);
        queryCalendar.set(Calendar.HOUR_OF_DAY, 0);
        queryCalendar.set(Calendar.MINUTE, 0);
        queryCalendar.set(Calendar.SECOND, 0);
        queryCalendar.set(Calendar.MILLISECOND, 0);
        queryCalendar.set(Calendar.YEAR, year);

        RealmQuery<Symptom> query = realm.where(Symptom.class);
        query.beginGroup();
        queryCalendar.set(Calendar.MONTH, month);
        query.greaterThanOrEqualTo(Field.SEIZURE_START_DATE, queryCalendar.getTime());
        queryCalendar.set(Calendar.MONTH, month + 1);
        query.lessThan(Field.SEIZURE_START_DATE, queryCalendar.getTime());
        query.endGroup();

        RealmResults<Symptom> results = query.findAllSorted(Field.SEIZURE_START_DATE, Sort.ASCENDING);
        return results;
    }

    /**
     * get All Symptom records in monthSelected with treatment flag (1: あり, 2: なし)
     * @param month : is monthSelected query
     * @param year : is yearSelected query
     * @param treatmentFlag : has or hasn't treatment
     * @return
     */
    public RealmResults<Symptom> getAllSymptomInMonthWithTreatment(int month, int year, int treatmentFlag) {
        Calendar queryCalendar = Calendar.getInstance();
        queryCalendar.set(Calendar.DAY_OF_MONTH, 1);
        queryCalendar.set(Calendar.HOUR_OF_DAY, 0);
        queryCalendar.set(Calendar.MINUTE, 0);
        queryCalendar.set(Calendar.SECOND, 0);
        queryCalendar.set(Calendar.MILLISECOND, 0);
        queryCalendar.set(Calendar.YEAR, year);

        RealmQuery<Symptom> query = realm.where(Symptom.class).equalTo(Field.TREATMENT_FLAG, treatmentFlag);
        query.beginGroup();
        queryCalendar.set(Calendar.MONTH, month);
        query.greaterThanOrEqualTo(Field.SEIZURE_START_DATE, queryCalendar.getTime());
        queryCalendar.set(Calendar.MONTH, month + 1);
        query.lessThan(Field.SEIZURE_START_DATE, queryCalendar.getTime());
        query.endGroup();

        RealmResults<Symptom> results = query.findAllSorted(Field.SEIZURE_START_DATE, Sort.ASCENDING);
        return results;
    }

    /**
     * get All Symptom records with yearSelected
     * @return
     */
    public RealmResults<Symptom> getAllSymptomInYear(int year) {
        Calendar queryCalendar = Calendar.getInstance();
        queryCalendar.set(Calendar.DAY_OF_MONTH, 1);
        queryCalendar.set(Calendar.HOUR_OF_DAY, 0);
        queryCalendar.set(Calendar.MINUTE, 0);
        queryCalendar.set(Calendar.SECOND, 0);
        queryCalendar.set(Calendar.MILLISECOND, 0);
        queryCalendar.set(Calendar.MONTH, Calendar.JANUARY);

        RealmQuery<Symptom> query = realm.where(Symptom.class);
        query.beginGroup();
        queryCalendar.set(Calendar.YEAR, year);
        query.greaterThanOrEqualTo(Field.SEIZURE_START_DATE, queryCalendar.getTime());
        queryCalendar.set(Calendar.YEAR, year + 1);
        query.lessThan(Field.SEIZURE_START_DATE, queryCalendar.getTime());
        query.endGroup();

        RealmResults<Symptom> results = query.findAllSorted(Field.SEIZURE_START_DATE, Sort.ASCENDING);
        return results;
    }

    public RealmResults<SymptomPartRelation> getAllSymptomPartRelation() {
        return realm.where(SymptomPartRelation.class).findAll();
    }

    public PartDetail getPartDetailFromId(int partDetailId) {
        return realm.where(PartDetail.class).equalTo(Field.ID, partDetailId).findFirst();
    }

    /*----------------------CALENDAR END----------------------------*/
}
