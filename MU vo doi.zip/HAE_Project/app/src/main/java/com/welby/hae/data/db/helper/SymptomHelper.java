package com.welby.hae.data.db.helper;

import com.welby.hae.data.db.model.Part;
import com.welby.hae.data.db.model.PartDetail;
import com.welby.hae.data.db.model.Symptom;
import com.welby.hae.data.db.model.SymptomPartRelation;
import com.welby.hae.data.db.model.SymptomPhoto;
import com.welby.hae.model.SymptomItem;
import com.welby.hae.utils.Field;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.annotation.ParametersAreNonnullByDefault;

import io.realm.Realm;
import io.realm.RealmResults;
import io.realm.Sort;


/**
 * Created by WelbyDev.
 */

public class SymptomHelper {
    private Realm realm;

    SymptomHelper(Realm realm) {
        this.realm = realm;
    }

    @ParametersAreNonnullByDefault
    public void insertRecord(final Symptom symptom) {
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                symptom.setId(getNextId(Symptom.class));
                realm.insertOrUpdate(symptom);
            }
        });
    }

    @ParametersAreNonnullByDefault
    public void updateRecord(final Symptom symptom) {
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                realm.insertOrUpdate(symptom);
            }
        });
    }

    @ParametersAreNonnullByDefault
    public void insertPhoto(final SymptomPhoto photo) {
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                photo.setId(getNextId(SymptomPhoto.class));
                realm.insert(photo);
            }
        });
    }

    /**
     * get seizure count in recent months
     *
     * @param numberOfMonths number of recent months
     */
    public int getSeizureCountInRecentMonths(int numberOfMonths) {
        Calendar from = Calendar.getInstance();
        Calendar to = Calendar.getInstance();
        from.add(Calendar.MONTH, -numberOfMonths);
        return (int) realm.where(Symptom.class)
                .between(Field.SEIZURE_START_DATE
                        , from.getTime()
                        , to.getTime())
                .count();
    }

    /**
     * get last startSeizureDay in recent 3 months
     */
    public Date getLastSeizureDay() {
        Calendar from = Calendar.getInstance();
        Calendar to = Calendar.getInstance();
        from.add(Calendar.MONTH, -3);
        RealmResults<Symptom> symptoms = realm.where(Symptom.class)
                .between(Field.SEIZURE_START_DATE, from.getTime(), to.getTime())
                .findAllSorted(Field.SEIZURE_START_DATE, Sort.DESCENDING);
        if (!symptoms.isEmpty()) {
            return symptoms.get(0).getSeizureStartDate();
        }
        return null;
    }

    public Symptom getSymptomRecord(int id) {
        Symptom symptom = realm.where(Symptom.class).equalTo(Field.ID, id).findFirst();
        if (symptom != null) {
            return realm.copyFromRealm(symptom);
        }
        return null;
    }

    /**
     * get all part details in db
     *
     * @return symptom part detail list
     */
    public List<SymptomItem> getDefaultPartDetails() {
        RealmResults<PartDetail> partDetailList = realm.where(PartDetail.class)
                .findAll();

        ArrayList<SymptomItem> symptomItemList = new ArrayList<>();
        for (PartDetail partDetail : partDetailList) {
            symptomItemList.add(new SymptomItem(partDetail.getId()
                    , partDetail.getPartId()
                    , partDetail.getDetailPartId()
                    , partDetail.getName()
                    , false));
        }

        return symptomItemList;
    }

    /**
     * get all part details with state (check/uncheck)
     *
     * @param symptomId symptom's id
     * @return symptom item list
     */
    public List<SymptomItem> getSymptomPartDetails(int symptomId) {
        RealmResults<PartDetail> partDetailList = realm.where(PartDetail.class)
                .findAll();

        ArrayList<SymptomItem> symptomItemList = new ArrayList<>();
        for (PartDetail partDetail : partDetailList) {
            symptomItemList.add(new SymptomItem(partDetail.getId()
                    , partDetail.getPartId()
                    , partDetail.getDetailPartId()
                    , partDetail.getName()
                    , hasSymptomPartDetail(symptomId, partDetail.getId())));
        }

        return symptomItemList;
    }

    /**
     * check if symptomPartDetailRelation is exist
     * with input symptomId and partDetailId
     *
     * @param symptomId    symptom id
     * @param partDetailId part detail id
     * @return false if symptomPartDetailRelation is not exist
     */
    private boolean hasSymptomPartDetail(int symptomId, int partDetailId) {
        long result = realm.where(SymptomPartRelation.class)
                .equalTo(Field.SYMPTOM_ID, symptomId)
                .equalTo(Field.PART_DETAIL_ID, partDetailId)
                .count();
        return result > 0;
    }

    /**
     * insert symptom part detail relation if it has not been insert before
     *
     * @param symptomId    symptom id
     * @param partDetailId part detail id
     * @return symptomPartRelation
     */
    @ParametersAreNonnullByDefault
    public SymptomPartRelation insertSymptomPartRelation(final int symptomId, final int partDetailId) {
        SymptomPartRelation result = realm.where(SymptomPartRelation.class)
                .equalTo(Field.SYMPTOM_ID, symptomId)
                .equalTo(Field.PART_DETAIL_ID, partDetailId)
                .findFirst();
        if (result == null) {
            final SymptomPartRelation insertItem = new SymptomPartRelation();
            realm.executeTransaction(new Realm.Transaction() {
                @Override
                public void execute(Realm realm) {
                    insertItem.setId(getNextId(SymptomPartRelation.class));
                    insertItem.setSymptomId(symptomId);
                    insertItem.setPartDetailId(partDetailId);
                    insertItem.setCreated(new Date(System.currentTimeMillis()));
                    realm.insertOrUpdate(insertItem);
                }
            });
            return insertItem;
        } else {
            return result;
        }
    }

    /**
     * delete all symptom and symptomPartRelation
     *
     * @param id symptom record id
     */
    @ParametersAreNonnullByDefault
    public void removeSymptomRecord(final int id) {
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                Symptom symptom = realm.where(Symptom.class).equalTo(Field.ID, id).findFirst();
                if (symptom != null) {
                    symptom.deleteFromRealm();
                }
                RealmResults<SymptomPartRelation> sprs = realm
                        .where(SymptomPartRelation.class)
                        .equalTo(Field.SYMPTOM_ID, id)
                        .findAll();
                if (sprs != null) {
                    sprs.deleteAllFromRealm();
                }
            }
        });
    }

    /**
     * remove symptomPartRelation which contains input symptomId and partDetailId
     */
    public void removeSymptomPartRelation(final int symptomId, final int partDetailId) {
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                SymptomPartRelation spr = realm.where(SymptomPartRelation.class)
                        .equalTo(Field.SYMPTOM_ID, symptomId)
                        .equalTo(Field.PART_DETAIL_ID, partDetailId)
                        .findFirst();
                if (spr != null) {
                    spr.deleteFromRealm();
                }
            }
        });
    }

    public List<Symptom> getJustCreatedRecords() {
        Calendar from = Calendar.getInstance();
        from.set(Calendar.HOUR_OF_DAY, 12);
        from.set(Calendar.MINUTE, 0);
        from.set(Calendar.SECOND, 0);
        from.set(Calendar.MILLISECOND, 0);
        from.add(Calendar.HOUR_OF_DAY, -24);

        Calendar to = Calendar.getInstance();
        to.set(Calendar.HOUR_OF_DAY, 12);
        to.set(Calendar.MINUTE, 0);
        to.set(Calendar.SECOND, 0);
        to.set(Calendar.MILLISECOND, 0);

        return realm.where(Symptom.class)
                .between(Field.CREATED, from.getTime(), to.getTime())
                .findAll();
    }

    public Part getPart(int id) {
        return realm.where(Part.class).equalTo(Field.ID, id).findFirst();
    }

    private int getNextId(Class clazz) {
        Number currentMax = realm.where(clazz).max(Field.ID);
        int nextId = 0;
        if (currentMax != null) {
            nextId = currentMax.intValue() + 1;
        }
        return nextId;
    }
}
