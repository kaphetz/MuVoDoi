package com.welby.hae.data.db.model;

import android.util.Pair;

import com.welby.hae.data.db.Constants;
import com.welby.hae.data.db.helper.MemberHelper;

import java.util.Date;

import io.realm.RealmObject;
import io.realm.RealmResults;
import io.realm.annotations.Ignore;
import io.realm.annotations.PrimaryKey;

/**
 * Created by Welby Dev on 10/16/2017.
 * File name: Member
 */

public class Member extends RealmObject {
    public static final int INT_TRUE_VALUE = 1;
    public static final int INT_FALSE_VALUE = 0;

    @PrimaryKey
    private int id;
    private int hae_flag;
    private boolean synchronize_flag;
    private boolean family_test_flag;
    private Relationship relationship_id_with_you;
    private Relationship relationship_id_with_creater;
    private Member creater_family_tree_id;
    private Member father_family_tree_id;
    private Member mother_family_tree_id;
    private String gender_code;
    private Date created;
    private Date modified;

    @Ignore
    private int generation;


    public Member() {
    }

    public Member(int id, int hae_flag, boolean synchronize_flag, boolean family_test_flag, Relationship relationship_id_with_you,
                  Relationship relationship_id_with_creater, Member creater_family_tree_id, Member father_family_tree_id, Member mother_family_tree_id,
                  String gender_code, Date created, Date modified) {
        this.id = id;
        this.hae_flag = hae_flag;
        this.synchronize_flag = synchronize_flag;
        this.family_test_flag = family_test_flag;
        this.relationship_id_with_you = relationship_id_with_you;
        this.relationship_id_with_creater = relationship_id_with_creater;
        this.creater_family_tree_id = creater_family_tree_id;
        this.father_family_tree_id = father_family_tree_id;
        this.mother_family_tree_id = mother_family_tree_id;
        this.gender_code = gender_code;
        this.created = created;
        this.modified = modified;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getHaeFlag() {
        return hae_flag;
    }

    public boolean isHAE() {
        return INT_TRUE_VALUE == hae_flag;
    }

    public boolean isFT() {
        return family_test_flag;
    }

    public void setHaeFlag(int hae_flag) {
        this.hae_flag = hae_flag;
    }

    public boolean isSynchronizeFlag() {
        return synchronize_flag;
    }

    public void setSynchronizeFlag(boolean synchronize_flag) {
        this.synchronize_flag = synchronize_flag;
    }

    public boolean isFamilyTestFlag() {
        return family_test_flag;
    }

    public void setFamilyTestFlag(boolean family_test_flag) {
        this.family_test_flag = family_test_flag;
    }

    public Relationship getRelationshipIdWithYou() {
        return relationship_id_with_you;
    }

    public void setRelationshipIdWithYou(Relationship relationship_id_with_you) {
        this.relationship_id_with_you = relationship_id_with_you;
    }

    public Relationship getRelationshipIdWithCreater() {
        return relationship_id_with_creater;
    }

    public void setRelationshipIdWithCreater(Relationship relationship_id_with_creater) {
        this.relationship_id_with_creater = relationship_id_with_creater;
    }

    public Member getCreaterFamilyTreeId() {
        return creater_family_tree_id;
    }

    public void setCreaterFamilyTreeId(Member creater_family_tree_id) {
        this.creater_family_tree_id = creater_family_tree_id;
    }

    public Member getFatherFamilyTreeId() {
        return father_family_tree_id;
    }

    public void setFatherFamilyTreeId(Member father_family_tree_id) {
        this.father_family_tree_id = father_family_tree_id;
    }

    public Member getMotherFamilyTreeId() {
        return mother_family_tree_id;
    }

    public void setMotherFamilyTreeId(Member mother_family_tree_id) {
        this.mother_family_tree_id = mother_family_tree_id;
    }

    public String getGenderCode() {
        return gender_code;
    }

    public boolean isMan() {
        return Constants.MAN.equals(gender_code);
    }

    public void setGenderCode(String gender_code) {
        this.gender_code = gender_code;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Date getModified() {
        return modified;
    }

    public void setModified(Date modified) {
        this.modified = modified;
    }

    public Member getSpouse() {
        return MemberHelper.newInstance().getMemberInRelationWithCreator(id, Constants.RELATION_SPOUSE);
    }

    public RealmResults<Member> getSibling() {
        return MemberHelper.newInstance().getListMemberInDegreeOfRelationWithCreator(id, Constants.RELATION_BROTHER, Constants.RELATION_SISTER);
    }

    public RealmResults<Member> getChildren() {
        return MemberHelper.newInstance().getListMemberInDegreeOfRelationWithCreator(id, Constants.RELATION_SON, Constants.RELATION_DAUGHTER);
    }

    public int getGeneration() {
        return generation;
    }

    public void setGeneration(int generation) {
        this.generation = generation;
    }

    public boolean hasSpouse() {
        return null != getSpouse();
    }

    public boolean hasFather() {
        return null != father_family_tree_id;
    }

    public boolean hasMother() {
        return null != mother_family_tree_id;
    }

    @Override
    public String toString() {
        StringBuilder str = new StringBuilder();
        str.append(id + " - ");
        if (relationship_id_with_you != null)
            str.append(relationship_id_with_you.getClassCode() + " - ");
        if (relationship_id_with_creater != null)
            str.append(relationship_id_with_creater.getClassCode());
        str.append(" - g: " + gender_code);

        if (creater_family_tree_id != null)
            str.append(" - c: " + creater_family_tree_id.getId());
        if (father_family_tree_id != null) {
            str.append(" - fa: " + father_family_tree_id.getId());
        }

        if (mother_family_tree_id != null) {
            str.append(" - mo: " + mother_family_tree_id.getId());
        }

        if (created != null) {
            str.append(" - cd: " + created.toString());
        }

        if (modified != null) {
            str.append(" - md: " + modified.toString());
        }


        return str.toString();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Pair) {
            Object oj = ((Pair) obj).first;
            if (oj instanceof Member) {
                return ((Member) oj).getId() == id;
            }
        } else if (obj instanceof Member) {
            return ((Member) obj).getId() == id;
        }
        return false;
    }
}
