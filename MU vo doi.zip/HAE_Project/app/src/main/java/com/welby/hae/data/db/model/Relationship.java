package com.welby.hae.data.db.model;

import java.util.Date;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

/**
 * Created by WelbyDev.
 */

public class Relationship extends RealmObject {
    public static final int CREATE_PERMISSION_FLAG_TRUE = 1;

    @PrimaryKey
    private int id;
    private String name;
    private int degree_of_relationship;
    private int create_permission_flag;
    private String class_code;
    private Date created;
    private Date modified;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getDegreeOfRelationship() {
        return degree_of_relationship;
    }

    public void setDegreeOfRelationship(int degree_of_relationship) {
        this.degree_of_relationship = degree_of_relationship;
    }

    public int getCreatePermissionFlag() {
        return create_permission_flag;
    }

    public boolean canAddMember() {
        return CREATE_PERMISSION_FLAG_TRUE == create_permission_flag;
    }

    public void setCreatePermissionFlag(int create_permission_flag) {
        this.create_permission_flag = create_permission_flag;
    }

    public String getClassCode() {
        return class_code;
    }

    public void setClassCode(String class_code) {
        this.class_code = class_code;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Date getModified() {
        return modified;
    }

    public void setModified(Date modified) {
        this.modified = modified;
    }


    @Override
    public String toString() {
        return id + " - " + class_code;
    }
}
