package com.welby.hae.data.db.model;

import java.util.Date;

import io.realm.RealmList;
import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

/**
 * Created by WelbyDev.
 */

public class Symptom extends RealmObject {
    @PrimaryKey
    private int id;
    private Date seizure_start_date;
    private Date seizure_end_date;
    private int pain_level = 5;
    private int treatment_flag = 1;
    private String memo;
    private int synchronize_flag;
    private Date created;
    private Date modified;

    private RealmList<SymptomPhoto> symptom_photos;
    private RealmList<SymptomPartRelation> symptom_part_relations;
    private Medication medication;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getSeizureStartDate() {
        return seizure_start_date;
    }

    public void setSeizureStartDate(Date seizureStartDate) {
        this.seizure_start_date = seizureStartDate;
    }

    public Date getSeizureEndDate() {
        return seizure_end_date;
    }

    public void setSeizureEndDate(Date seizureEndDate) {
        this.seizure_end_date = seizureEndDate;
    }

    public int getPainLevel() {
        return pain_level;
    }

    public void setPainLevel(int painLevel) {
        this.pain_level = painLevel;
    }

    public int getTreatmentFlag() {
        return treatment_flag;
    }

    public void setTreatmentFlag(int treatmentFlag) {
        this.treatment_flag = treatmentFlag;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public Medication getMedication() {
        return medication;
    }

    public void setMedication(Medication medication) {
        this.medication = medication;
    }

    public int getSynchronizeFlag() {
        return synchronize_flag;
    }

    public void setSynchronizeFlag(int synchronizeFlag) {
        this.synchronize_flag = synchronizeFlag;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Date getModified() {
        return modified;
    }

    public void setModified(Date modified) {
        this.modified = modified;
    }

    public RealmList<SymptomPhoto> getSymptomPhotos() {
        if(symptom_photos == null){
            symptom_photos = new RealmList<>();
        }
        return symptom_photos;
    }

    public void setSymptomPhotos(RealmList<SymptomPhoto> symptomPhotos) {
        this.symptom_photos = symptomPhotos;
    }

    public RealmList<SymptomPartRelation> getSymptomPartRelations() {
        if(symptom_part_relations == null){
            symptom_part_relations = new RealmList<>();
        }
        return symptom_part_relations;
    }

    public void setSymptomPartRelations(RealmList<SymptomPartRelation> symptomPartRelations) {
        this.symptom_part_relations = symptomPartRelations;
    }
}
