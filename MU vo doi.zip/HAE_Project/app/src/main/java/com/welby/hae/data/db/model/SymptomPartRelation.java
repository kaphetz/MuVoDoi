package com.welby.hae.data.db.model;

import java.util.Date;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

/**
 * Created by WelbyDev.
 */

public class SymptomPartRelation extends RealmObject {
    @PrimaryKey
    private int id;
    private int symptom_id;
    private int part_detail_id;
    private int synchronize_flag;
    private Date created;
    private Date modified;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getSymptomId() {
        return symptom_id;
    }

    public void setSymptomId(int symptomId) {
        this.symptom_id = symptomId;
    }

    public int getPartDetailId() {
        return part_detail_id;
    }

    public void setPartDetailId(int partDetailId) {
        this.part_detail_id = partDetailId;
    }

    public int getSynchronizeFlag() {
        return synchronize_flag;
    }

    public void setSynchronizeFlag(int synchronizeFlag) {
        this.synchronize_flag = synchronizeFlag;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Date getModified() {
        return modified;
    }

    public void setModified(Date modified) {
        this.modified = modified;
    }
}
