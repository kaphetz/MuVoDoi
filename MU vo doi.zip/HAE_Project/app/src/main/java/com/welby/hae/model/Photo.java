package com.welby.hae.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by WelbyDev.
 */

public class Photo implements Parcelable {
    private String path;
    private long createdTime;

    private Photo(Parcel in) {
        path = in.readString();
        createdTime = in.readLong();
    }

    public Photo(String path) {
        this.path = path;
        createdTime = System.currentTimeMillis();
    }

    public Photo(String path, long createdTime) {
        this.path = path;
        this.createdTime = createdTime;
    }

    public static final Creator<Photo> CREATOR = new Creator<Photo>() {
        @Override
        public Photo createFromParcel(Parcel in) {
            return new Photo(in);
        }

        @Override
        public Photo[] newArray(int size) {
            return new Photo[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(path);
        dest.writeLong(createdTime);
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public long getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(long createdTime) {
        this.createdTime = createdTime;
    }
}
