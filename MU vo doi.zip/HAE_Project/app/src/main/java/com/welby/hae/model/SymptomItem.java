package com.welby.hae.model;

/**
 * Created by WelbyDev.
 * <p>
 * this class is used for mapping db -> view
 */

public class SymptomItem {
    private int detailId;
    private int partId;
    private int detailPartId;
    private String name;
    private boolean isChosen;

    public SymptomItem(String name) {
        this.name = name;
        this.isChosen = false;
    }

    public SymptomItem(String name, boolean isChosen) {
        this.name = name;
        this.isChosen = isChosen;
    }

    public SymptomItem(int detailId, String name) {
        this.detailId = detailId;
        this.name = name;
        this.isChosen = false;
    }

    public SymptomItem(int detailId, int partId, int detailPartId, String name, boolean isChosen) {
        this.detailId = detailId;
        this.partId = partId;
        this.detailPartId = detailPartId;
        this.name = name;
        this.isChosen = isChosen;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isChosen() {
        return isChosen;
    }

    public void setChosen(boolean chosen) {
        isChosen = chosen;
    }

    public int getDetailId() {
        return detailId;
    }

    public void setDetailId(int detailId) {
        this.detailId = detailId;
    }

    public int getPartId() {
        return partId;
    }

    public void setPartId(int partId) {
        this.partId = partId;
    }

    public int getDetailPartId() {
        return detailPartId;
    }

    public void setDetailPartId(int detailPartId) {
        this.detailPartId = detailPartId;
    }
}
