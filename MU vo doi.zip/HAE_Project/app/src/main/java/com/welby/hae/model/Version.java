package com.welby.hae.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Welby Dev on 10/16/2017.
 */

public class Version {

    @SerializedName("required_version")
    private String required_version;

    @SerializedName("update_url")
    private String update_url;

    @SerializedName("update_message")
    private String update_message;


    public Version(String required_version, String update_url, String update_message) {
        this.required_version = required_version;
        this.update_url = update_url;
        this.update_message = update_message;
    }

    public String getRequired_version() {
        return required_version;
    }

    public void setRequired_version(String required_version) {
        this.required_version = required_version;
    }

    public String getUpdate_url() {
        return update_url;
    }

    public void setUpdate_url(String update_url) {
        this.update_url = update_url;
    }

    public String getUpdate_message() {
        return update_message;
    }

    public void setUpdate_message(String update_message) {
        this.update_message = update_message;
    }

    @Override
    public String toString() {
        return required_version + " - " + update_url + " - " + update_message;
    }
}
