package com.welby.hae.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Welby Dev on 10/16/2017.
 */

public class VersionApp {

    @SerializedName("ios")
    private Version ios;

    @SerializedName("android")
    private Version android;

    public VersionApp(Version ios, Version android) {
        this.ios = ios;
        this.android = android;
    }

    public Version getIos() {
        return ios;
    }

    public void setIos(Version ios) {
        this.ios = ios;
    }

    public Version getAndroid() {
        return android;
    }

    public void setAndroid(Version android) {
        this.android = android;
    }

    @Override
    public String toString() {
        return ios.toString() + "\n" + android.toString();
    }
}
