package com.welby.hae.rest;

import com.welby.hae.model.VersionApp;

import retrofit2.Call;
import retrofit2.http.GET;

/**
 * Created by Welby Dev on 10/16/2017.
 */

public interface ApiInterface {

    @GET("version.json")
    Call<VersionApp> getVersionApp();

}
