package com.welby.hae.ui.base;

import android.support.v7.app.AppCompatActivity;

import com.welby.hae.utils.Define;

/**
 * Created by WelbyDev.
 * Filename BaseActivity
 */

public abstract class BaseActivity extends AppCompatActivity {
    //this variable is used to discern which activity just has closed (handle in onResume method of MainActivity)
    public static String lastVisibleActivity = Define.STR_EMPTY;

    public abstract void initView();

    public abstract void initData();

    public static void setLastVisibleActivity(String activityName){
        lastVisibleActivity = activityName;
    }
}
