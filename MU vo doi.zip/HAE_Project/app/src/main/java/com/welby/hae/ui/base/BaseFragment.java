package com.welby.hae.ui.base;

import android.support.v4.app.Fragment;
import android.view.View;

import com.welby.hae.utils.Define;

/**
 * Created by WelbyDev.
 * Filename BaseFragment
 */

public abstract class BaseFragment extends Fragment {

    public static String lastVisibleFragment = Define.STR_EMPTY;

    public abstract void initView(View view);

    public abstract void initData();

    public static void setLastVisibleFragment(String fragmentName){
        lastVisibleFragment = fragmentName;
    }
}
