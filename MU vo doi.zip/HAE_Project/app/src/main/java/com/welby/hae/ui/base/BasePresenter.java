package com.welby.hae.ui.base;

/**
 * Created by WelbyDev.
 * Filename BasePresenter
 */

public abstract class BasePresenter {

}
