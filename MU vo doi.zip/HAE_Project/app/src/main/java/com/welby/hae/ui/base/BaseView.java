package com.welby.hae.ui.base;

/**
 * Created by WelbyDev.
 * Filename BaseView
 */

public interface BaseView {

}
