package com.welby.hae.ui.calendar;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.welby.hae.HAEApplication;
import com.welby.hae.R;
import com.welby.hae.adapter.FragmentSliderAdapter;
import com.welby.hae.data.db.helper.RealmManager;
import com.welby.hae.data.db.model.Symptom;
import com.welby.hae.ui.base.BaseFragment;
import com.welby.hae.ui.calendar.graph.CalendarGraphFragment;
import com.welby.hae.ui.calendar.list.CalendarListFragment;
import com.welby.hae.ui.calendar.month.CalendarMonthFragment;
import com.welby.hae.ui.custom.NonSwipeableViewPager;
import com.welby.hae.utils.RLog;

import java.util.Calendar;
import java.util.List;

/**
 * Created by WelbyDev.
 */

public class CalendarFragment extends BaseFragment implements CalendarView, View.OnClickListener, CalendarGraphFragment.GraphClickListener {

    public static final int TAB_GRAPH = 0;
    public static final int TAB_CALENDAR = 1;
    public static final int TAB_LIST = 2;

    private NonSwipeableViewPager viewPager;
    private FragmentSliderAdapter adapter;
    private int tabSelected;
    private Calendar calendar;
    private LinearLayout tabGraph;
    private LinearLayout tabCalendar;
    private LinearLayout tabList;

    private CalendarPresenter presenter;
    private List<Symptom> symptomList;

    private CalendarGraphFragment graphFragment;
    private CalendarMonthFragment monthFragment;
    private CalendarListFragment listFragment;

    ViewPager.OnPageChangeListener pageChangeListener = new ViewPager.OnPageChangeListener() {
        @Override
        public void onPageScrollStateChanged(int arg0) { }

        @Override
        public void onPageScrolled(int arg0, float arg1, int arg2) { }

        @Override
        public void onPageSelected(int position) {
            switch (position) {
                case TAB_GRAPH:
                    HAEApplication.getInstance().trackScreenView(getString(R.string.screen_confirm_graph));
                    break;
                case TAB_CALENDAR:
                    HAEApplication.getInstance().trackScreenView(getString(R.string.screen_confirm_calender));
                    break;
                case TAB_LIST:
                    HAEApplication.getInstance().trackScreenView(getString(R.string.screen_confirm_list));
                    break;
                default:
                    break;
            }
        }
    };

    public static CalendarFragment newInstance(int tabSelected, Calendar calendar) {
        CalendarFragment fragment = new CalendarFragment();
        fragment.tabSelected = tabSelected;
        fragment.calendar = calendar;
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return LayoutInflater.from(getActivity()).inflate(R.layout.fragment_calendar, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initData();
    }

    @Override
    public void initView(View view) {
        viewPager = view.findViewById(R.id.contact_viewpager);
        tabGraph = view.findViewById(R.id.calendar_tab_graph);
        tabCalendar = view.findViewById(R.id.calendar_tab_month);
        tabList = view.findViewById(R.id.calendar_tab_list);

        setOnClick();
    }

    private void setOnClick() {
        tabGraph.setOnClickListener(this);
        tabCalendar.setOnClickListener(this);
        tabList.setOnClickListener(this);
    }

    @Override
    public void initData() {
        symptomList = RealmManager.getRealmManager().getAllSymptoms();
        graphFragment = new CalendarGraphFragment().newInstance(symptomList);
        monthFragment = new CalendarMonthFragment().newInstance(symptomList, calendar);
        listFragment = new CalendarListFragment().newInstance(calendar);
        graphFragment.setGraphClickListener(this);
        setupViewPager(viewPager);
        presenter = new CalendarPresenter(this);
        presenter.changeTab(tabSelected);
    }

    private void setupViewPager(NonSwipeableViewPager viewPager) {
        adapter = new FragmentSliderAdapter(getChildFragmentManager());
        adapter.addFragment(graphFragment, getString(R.string.calendar_tab_graph));
        adapter.addFragment(monthFragment, getString(R.string.calendar_tab_month));
        adapter.addFragment(listFragment, getString(R.string.calendar_tab_list));
        viewPager.destroyDrawingCache();
        viewPager.setOffscreenPageLimit(3);
        viewPager.setPagingEnabled(false);
        viewPager.setAdapter(adapter);

        if (tabSelected == TAB_GRAPH) {
            pageChangeListener.onPageSelected(tabSelected);
        }
        viewPager.addOnPageChangeListener(pageChangeListener);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.calendar_tab_graph:
                presenter.changeTab(TAB_GRAPH);
                break;
            case R.id.calendar_tab_month:
                presenter.changeTab(TAB_CALENDAR);
                break;
            case R.id.calendar_tab_list:
                presenter.changeTab(TAB_LIST);
                break;
            default:
                break;
        }
    }

    @Override
    public void selectedTab(int tabPosition) {
        viewPager.setCurrentItem(tabPosition);
        switch (tabPosition) {
            case TAB_GRAPH:
                setSelectedTab(tabGraph, true);
                setSelectedTab(tabCalendar, false);
                setSelectedTab(tabList, false);
                HAEApplication.getInstance().trackEvent(getString(R.string.event_graph_tab_tap));
                break;
            case TAB_CALENDAR:
                setSelectedTab(tabGraph, false);
                setSelectedTab(tabCalendar, true);
                setSelectedTab(tabList, false);
                HAEApplication.getInstance().trackEvent(getString(R.string.event_calender_tab_tap));
                break;
            case TAB_LIST:
                setSelectedTab(tabGraph, false);
                setSelectedTab(tabCalendar, false);
                setSelectedTab(tabList, true);
                HAEApplication.getInstance().trackEvent(getString(R.string.event_list_tab_tap));
                break;
            default:
                break;
        }
    }

    private void setSelectedTab(LinearLayout selectedTab, boolean isSelected) {
        if (isSelected) {
            selectedTab.setClickable(false);
            selectedTab.setSelected(true);
        } else {
            selectedTab.setClickable(true);
            selectedTab.setSelected(false);
        }
    }

    @Override
    public void OnGraphClick() {
        presenter.changeTab(TAB_LIST);
        HAEApplication.getInstance().trackEvent(getString(R.string.event_category), getString(R.string.event_action), getString(R.string.event_graph_tap));
    }
}
