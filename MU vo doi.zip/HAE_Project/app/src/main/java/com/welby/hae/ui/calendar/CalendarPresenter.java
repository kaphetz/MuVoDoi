package com.welby.hae.ui.calendar;

import com.welby.hae.ui.base.BasePresenter;

/**
 * Created by WelbyDev.
 */

class CalendarPresenter extends BasePresenter {
    private CalendarView calendarView;

    CalendarPresenter(CalendarView calendarView) {
        this.calendarView = calendarView;
    }

    void changeTab(int tabPosition) {
        calendarView.selectedTab(tabPosition);
    }
}
