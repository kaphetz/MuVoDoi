package com.welby.hae.ui.calendar;

import com.welby.hae.ui.base.BaseView;

/**
 * Created by WelbyDev.
 */

interface CalendarView extends BaseView {
    void selectedTab(int tabPosition);
}
