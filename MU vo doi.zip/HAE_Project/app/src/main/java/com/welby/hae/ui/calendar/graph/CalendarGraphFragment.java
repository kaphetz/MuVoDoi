package com.welby.hae.ui.calendar.graph;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import com.github.mikephil.charting.charts.Chart;
import com.github.mikephil.charting.charts.CombinedChart;
import com.github.mikephil.charting.charts.HorizontalBarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.LimitLine;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.BubbleData;
import com.github.mikephil.charting.data.BubbleDataSet;
import com.github.mikephil.charting.data.BubbleEntry;
import com.github.mikephil.charting.data.CombinedData;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;
import com.github.mikephil.charting.interfaces.datasets.IBubbleDataSet;
import com.github.mikephil.charting.utils.Utils;
import com.welby.hae.HAEApplication;
import com.welby.hae.R;
import com.welby.hae.data.db.model.Symptom;
import com.welby.hae.ui.base.BaseFragment;
import com.welby.hae.utils.RLog;
import com.welby.hae.utils.graph.GraphYAxisValueFormatter;
import com.welby.hae.utils.graph.PartGraphYAxisValueFormatter;
import com.welby.hae.utils.graph.PieGraphValueFormatter;
import com.welby.hae.utils.graph.StatisticYFormater;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by WelbyDev.
 */

public class CalendarGraphFragment extends BaseFragment implements CalendarGraphView, View.OnClickListener {
    private static final int TAB_3_MONTH = 3;
    private static final int TAB_6_MONTH = 6;
    private static final int TAB_1_YEAR = 12;
    private static final int STATISTIC_LABEL_COUNT = 13; // 12 month with charactor 月
    private static final int PART_JUMP = 5;
    private static final float GRAPH_LABEL_SIZE = 15; // unit : dp
    private static final float GRAPH_BUBBLE_TEXT_SIZE = 10f;
    private CombinedChart statisticChart;
    protected HorizontalBarChart partChart;
    private PieChart pieChart;
    private Button tv3Month;
    private Button tv6Month;
    private Button tv1Year;
    private TextView avgSymptomTime;
    private TextView timeUnitTitle;
    private TextView monthUnitTitle;
    private SeekBar averageProgress;
    private LinearLayout averageProgressLayout;

    private Context context;

    private CalendarGraphPresenter presenter;

    private GraphClickListener graphClickListener;
    public interface GraphClickListener {
        void OnGraphClick();
    }

    public void setGraphClickListener(GraphClickListener graphClickListener) {
        this.graphClickListener = graphClickListener;
    }

    public CalendarGraphFragment newInstance(List<Symptom> symptomList) {
        CalendarGraphFragment fragment = new CalendarGraphFragment();
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return LayoutInflater.from(getActivity()).inflate(R.layout.fragment_calendar_graph, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initData();
    }

    @Override
    public void initView(View view) {
        statisticChart = view.findViewById(R.id.graph_statistic_chart);
        partChart = view.findViewById(R.id.graph_part_chart);
        pieChart = view.findViewById(R.id.graph_pie_chart);
        tv3Month = view.findViewById(R.id.graph_3_month);
        tv6Month = view.findViewById(R.id.graph_6_month);
        tv1Year = view.findViewById(R.id.graph_1_year);
        averageProgress = view.findViewById(R.id.graph_average_seekbar);
        averageProgressLayout = view.findViewById(R.id.graph_average_seekbar_layout);
        avgSymptomTime = view.findViewById(R.id.graph_time_count);
        timeUnitTitle = view.findViewById(R.id.graph_unit_time);
        monthUnitTitle = view.findViewById(R.id.graph_unit_month);

        setOnClick();
    }

    @Override
    public void initData() {
        context = getContext();
        presenter = new CalendarGraphPresenter(context, this);
        presenter.setStatisticChartData(TAB_1_YEAR);
        presenter.setPartChartData(getContext());
        presenter.setPieChartData(getContext());
        presenter.setAverageProgressData();
    }

    private void setOnClick() {
        tv3Month.setOnClickListener(this);
        tv6Month.setOnClickListener(this);
        tv1Year.setOnClickListener(this);
        statisticChart.setOnClickListener(this);
        partChart.setOnClickListener(this);
        pieChart.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                if (motionEvent.getAction() == MotionEvent.ACTION_UP && null != graphClickListener) {
                    graphClickListener.OnGraphClick();
                }
                return false;
            }
        });
        averageProgressLayout.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.graph_3_month:
                changeTab(TAB_3_MONTH);
                HAEApplication.getInstance().trackEvent(getString(R.string.event_3month_tap));
                break;
            case R.id.graph_6_month:
                changeTab(TAB_6_MONTH);
                HAEApplication.getInstance().trackEvent(getString(R.string.event_6month_tap));
                break;
            case R.id.graph_1_year:
                changeTab(TAB_1_YEAR);
                HAEApplication.getInstance().trackEvent(getString(R.string.event_1year_tap));
                break;
            case R.id.graph_statistic_chart:
            case R.id.graph_part_chart:
            case R.id.graph_average_seekbar_layout:
                if (null != graphClickListener) {
                    graphClickListener.OnGraphClick();
                }
                break;
            default:
                break;
        }
    }

    private void changeTab(int tabPosition) {
        presenter.setStatisticChartData(tabPosition);
        presenter.setPartChartData(getContext());
        presenter.setPieChartData(getContext());
        presenter.setAverageProgressData();
    }

    private void changeStatisticChart(int monthCount) {
        switch (monthCount) {
            case TAB_3_MONTH:
                setSelectedButton(tv3Month, true);
                setSelectedButton(tv6Month, false);
                setSelectedButton(tv1Year, false);
                break;
            case TAB_6_MONTH:
                setSelectedButton(tv3Month, false);
                setSelectedButton(tv6Month, true);
                setSelectedButton(tv1Year, false);
                break;
            case TAB_1_YEAR:
                setSelectedButton(tv3Month, false);
                setSelectedButton(tv6Month, false);
                setSelectedButton(tv1Year, true);
                break;
            default:
                break;
        }
    }

    private void setSelectedButton(Button selectedButton, boolean isSelected) {
        if (isSelected) {
            selectedButton.setTypeface(null, Typeface.BOLD);
            selectedButton.setClickable(false);
            selectedButton.setSelected(true);
        } else {
            selectedButton.setTypeface(null, Typeface.NORMAL);
            selectedButton.setClickable(true);
            selectedButton.setSelected(false);
        }
    }

    @Override
    public void displayStatisticChart(List<BarEntry> yValues, List<BubbleEntry> yLabelValues, String[] labels,
                                      int monthCount, float maxValue, boolean isNoData) {
        BarDataSet dataSet;
        final BubbleDataSet bubbleDataSet;
        float increment = maxValue / 2;
        float lineSpace = maxValue / 10;

        YAxis yLabels = statisticChart.getAxisLeft();
        yLabels.setValueFormatter(new GraphYAxisValueFormatter(context));
        yLabels.setAxisMinimum(0f);
        yLabels.setAxisMaximum(maxValue + lineSpace * 0.99f);
        yLabels.setGranularityEnabled(true);
        yLabels.setGranularity(lineSpace);
        yLabels.setDrawGridLines(true);
        yLabels.enableGridDashedLine(10f, 10f, 1f);
        yLabels.setDrawAxisLine(false);
        yLabels.setDrawLimitLinesBehindData(true);
        yLabels.setLabelCount((int) maxValue);
        yLabels.setTextSize(GRAPH_LABEL_SIZE);
        yLabels.setGridColor(ContextCompat.getColor(context, R.color.graph_x_color));

        XAxis xLabels = statisticChart.getXAxis();
        xLabels.setPosition(XAxis.XAxisPosition.BOTTOM);
        xLabels.setValueFormatter(new IndexAxisValueFormatter(labels));
        xLabels.setDrawGridLines(false);
        xLabels.setLabelCount(STATISTIC_LABEL_COUNT);
        xLabels.setTextColor(ContextCompat.getColor(context, R.color.graph_text_color));
        xLabels.setTextSize(GRAPH_LABEL_SIZE);
        xLabels.setTypeface(Typeface.DEFAULT_BOLD);

        if (statisticChart.getData() != null &&
                statisticChart.getData().getDataSetCount() > 0) {
            dataSet = (BarDataSet) statisticChart.getData().getDataSetByIndex(0);
            bubbleDataSet = (BubbleDataSet) statisticChart.getData().getDataSetByIndex(1);
            if (!isNoData) {
                dataSet.setValues(yValues);
                bubbleDataSet.setValues(yLabelValues);
                monthUnitTitle.setVisibility(View.VISIBLE);
                statisticChart.getData().notifyDataChanged();
                statisticChart.notifyDataSetChanged();
            } else {
                statisticChart.clear();
                monthUnitTitle.setVisibility(View.GONE);
            }
        } else {
            dataSet = new BarDataSet(yValues, null);
            dataSet.setDrawIcons(false);
            dataSet.setColors(getColors());
            dataSet.setStackLabels(getResources().getStringArray(R.array.graph_statistic));

            ArrayList<IBarDataSet> dataSets = new ArrayList<>();
            dataSets.add(dataSet);

            BarData barData = new BarData(dataSets);
            barData.setValueTextColor(Color.TRANSPARENT);

            bubbleDataSet = new BubbleDataSet(yLabelValues, null);
            bubbleDataSet.setDrawIcons(false);
            bubbleDataSet.setColor(ContextCompat.getColor(context, R.color.graph_x_color));
            bubbleDataSet.setFormSize(0);
            bubbleDataSet.setNormalizeSizeEnabled(false);
            bubbleDataSet.setValueTextSize(GRAPH_BUBBLE_TEXT_SIZE);
            bubbleDataSet.setValueTextColor(ContextCompat.getColor(context, R.color.graph_text_color));
            bubbleDataSet.setValueFormatter(new StatisticYFormater(context));

            ArrayList<IBubbleDataSet> bubbleDataSets = new ArrayList<>();
            bubbleDataSets.add(bubbleDataSet);

            BubbleData bubbleData = new BubbleData(bubbleDataSets);

            CombinedData data = new CombinedData();
            data.setData(barData);
            data.setData(bubbleData);

            if (!isNoData) {
                monthUnitTitle.setVisibility(View.VISIBLE);
                statisticChart.setData(data);
            } else {
                monthUnitTitle.setVisibility(View.GONE);
            }
        }

        statisticChart.getDescription().setEnabled(false);
        statisticChart.setScaleEnabled(false);
        statisticChart.setDrawGridBackground(false);
        statisticChart.getAxisRight().setEnabled(false);
        statisticChart.setHighlightPerTapEnabled(false);
        statisticChart.setHighlightPerDragEnabled(false);
        statisticChart.setNoDataText(getString(R.string.calendar_graph_emtpy));
        Paint paint = statisticChart.getPaint(Chart.PAINT_INFO);
        paint.setTextSize(Utils.convertDpToPixel(GRAPH_LABEL_SIZE));
        paint.setColor(ContextCompat.getColor(context, R.color.graph_legend_color));
        statisticChart.setExtraOffsets(0, 0, 0, 5); // graph padding content

        statisticChart.getAxisLeft().removeAllLimitLines();
        for(int i = 0; i <= yLabelValues.size(); i++) {
            LimitLine llRange = new LimitLine(i * increment, "");
            llRange.setLineColor(ContextCompat.getColor(context, R.color.graph_x_color));
            if (i == 1) {
                llRange.setLineWidth(1f);
            } else {
                llRange.setLineWidth(2f);
            }
            statisticChart.getAxisLeft().addLimitLine(llRange);
        }

        Legend chartLegend = statisticChart.getLegend();
        chartLegend.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
        chartLegend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.RIGHT);
        chartLegend.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        chartLegend.setFormSize(14f);
        chartLegend.setFormToTextSpace(8f);
        chartLegend.setXEntrySpace(6f);
        chartLegend.setTextSize(GRAPH_LABEL_SIZE);
        chartLegend.setTextColor(ContextCompat.getColor(context, R.color.graph_legend_color));
        statisticChart.invalidate();

        changeStatisticChart(monthCount);
    }

    @Override
    public void displayStatisticAverage(String avgValue) {
        if (avgSymptomTime != null) {
            avgSymptomTime.setText(avgValue);
        }
    }

    @Override
    public void displayPartChart(List<BarEntry> yValues, String[] partsLabel, float maxValue, boolean isNoData) {
        BarDataSet dataSet;
        BarData data;

        partChart.setDrawBarShadow(false);
        partChart.setScaleEnabled(false);
        partChart.getDescription().setEnabled(false);
        partChart.setDrawGridBackground(false);
        partChart.setFitBars(true);
        partChart.setHighlightPerTapEnabled(false);
        partChart.setHighlightPerDragEnabled(false);
        partChart.setNoDataText(getString(R.string.calendar_graph_emtpy));
        Paint paint = partChart.getPaint(Chart.PAINT_INFO);
        paint.setTextSize(Utils.convertDpToPixel(GRAPH_LABEL_SIZE));
        paint.setColor(ContextCompat.getColor(context, R.color.graph_legend_color));

        float increment = 5;
        float metricLine = 0;

        for(int i = 0; i <= calculatedMaxValue(maxValue); i++) {
            LimitLine llRange = new LimitLine(metricLine, "");
            llRange.setLineColor(ContextCompat.getColor(context, R.color.graph_x_color));
            if (i == 0) {
                llRange.setLineWidth(2f);
            } else {
                llRange.setLineWidth(1f);
            }
            partChart.getAxisLeft().addLimitLine(llRange);
            metricLine = metricLine + increment;
        }

        Legend l = partChart.getLegend();
        l.setEnabled(false);

        XAxis xLabels = partChart.getXAxis();
        xLabels.setPosition(XAxis.XAxisPosition.BOTTOM);
        xLabels.setDrawGridLines(false);
        xLabels.setValueFormatter(new IndexAxisValueFormatter(partsLabel));
        xLabels.setLabelCount(partsLabel.length);
        xLabels.setTextColor(ContextCompat.getColor(context, R.color.graph_text_color));
        xLabels.setTextSize(GRAPH_LABEL_SIZE);
        timeUnitTitle.setTextSize(Utils.convertPixelsToDp(xLabels.getTextSize()));
        xLabels.setTypeface(Typeface.DEFAULT_BOLD);

        YAxis yLabels = partChart.getAxisLeft();
        yLabels.setDrawAxisLine(true);
        yLabels.setDrawGridLines(true);
        yLabels.setValueFormatter(new PartGraphYAxisValueFormatter(context));
        yLabels.setAxisMinimum(0f);
        yLabels.setGranularityEnabled(true);
        yLabels.setGranularity(1f);
        yLabels.setAxisMaximum(calculatedMaxValue(maxValue));
        yLabels.setDrawAxisLine(false);
        yLabels.enableGridDashedLine(10f, 10f, 1f);
        yLabels.setDrawLimitLinesBehindData(true);
        yLabels.setLabelCount((int) calculatedMaxValue(maxValue));
        yLabels.setTextColor(ContextCompat.getColor(context, R.color.graph_text_color));
        yLabels.setTextSize(GRAPH_LABEL_SIZE);
        yLabels.setGridColor(ContextCompat.getColor(context, R.color.graph_x_color));

        YAxis yr = partChart.getAxisRight();
        yr.setEnabled(false);

        if (partChart.getData() != null &&
                partChart.getData().getDataSetCount() > 0) {
            data = partChart.getData();
            data.setBarWidth(0.85f * yValues.size() / 7);
            dataSet = (BarDataSet) data.getDataSetByIndex(0);
            if (!isNoData) {
                dataSet.setValues(yValues);
                partChart.getData().notifyDataChanged();
                partChart.notifyDataSetChanged();
                timeUnitTitle.setVisibility(View.VISIBLE);
            } else {
                partChart.clear();
                timeUnitTitle.setVisibility(View.GONE);
            }
        } else {
            dataSet = new BarDataSet(yValues, null);

            dataSet.setDrawIcons(false);
            dataSet.setColor(getColors()[0]);

            ArrayList<IBarDataSet> dataSets = new ArrayList<>();
            dataSets.add(dataSet);

            data = new BarData(dataSets);
            data.setValueTextColor(Color.TRANSPARENT);
            data.setBarWidth(0.85f * yValues.size() / 7); // 0.85f is default size, 7 is max bar count in graph
            if (!isNoData) {
                timeUnitTitle.setVisibility(View.VISIBLE);
                partChart.setData(data);
            } else {
                timeUnitTitle.setVisibility(View.GONE);
            }
        }

        // set margin for label
        RelativeLayout.LayoutParams labelParam = (RelativeLayout.LayoutParams) timeUnitTitle.getLayoutParams();
        if (xLabels.getLongestLabel().length() == 3) {
            labelParam.leftMargin = (int) Utils.convertDpToPixel(20);
        } else if (xLabels.getLongestLabel().length() == 2) {
            labelParam.leftMargin = (int) Utils.convertDpToPixel(10);
        }
        timeUnitTitle.setLayoutParams(labelParam);

        partChart.invalidate();
    }

    @Override
    public void displayPieChart(List<PieEntry> entries, String[] partsLabel, boolean isNoData) {
        PieDataSet dataSet = new PieDataSet(entries, null);
        dataSet.setColors(getColors());

        PieData data = new PieData(dataSet);
        data.setValueFormatter(new PieGraphValueFormatter());
        data.setValueTextColor(Color.WHITE);
        if (!isNoData) {
            pieChart.setData(data);
        } else {
            pieChart.clear();
        }

        pieChart.getDescription().setEnabled(false);
        pieChart.setDrawHoleEnabled(false);
        pieChart.setHoleColor(Color.WHITE);
        pieChart.setRotationAngle(-90);
        pieChart.setHighlightPerTapEnabled(false);
        pieChart.setUsePercentValues(false);
        pieChart.setRotationEnabled(false);
        pieChart.setDrawCenterText(false);
        pieChart.setNoDataText(getString(R.string.calendar_graph_emtpy));
        pieChart.setEntryLabelTypeface(Typeface.DEFAULT_BOLD);
        pieChart.setEntryLabelTextSize(GRAPH_LABEL_SIZE);
        Paint paint = pieChart.getPaint(Chart.PAINT_INFO);
        paint.setTextSize(Utils.convertDpToPixel(GRAPH_LABEL_SIZE));
        paint.setColor(ContextCompat.getColor(context, R.color.graph_legend_color));

        // undo all highlights
        pieChart.highlightValues(null);
        Legend l = pieChart.getLegend();
        l.setEnabled(false);

        pieChart.invalidate();
    }

    @Override
    public void displayAverageProgress(final int averagePercent) {
        RLog.d("averagePercent : " + averagePercent);
        averageProgress.post(new Runnable() {
            @Override
            public void run() {
                averageProgress.setProgress(averagePercent);
                averageProgress.setEnabled(false);
            }
        });
    }

    private int[] getColors() {
        int[] colors = new int[2];
        colors[0] = ContextCompat.getColor(context, R.color.graph_color_dark);
        colors[1] = ContextCompat.getColor(context, R.color.graph_color_light);
        return colors;
    }

    /**
     * calculate max value for Y chart (round up)
     * @param value : real max value
     * @return : max value for Y chart
     */
    private float calculatedMaxValue(float value) {
        return (float) (PART_JUMP * Math.ceil(value / PART_JUMP));
    }
}
