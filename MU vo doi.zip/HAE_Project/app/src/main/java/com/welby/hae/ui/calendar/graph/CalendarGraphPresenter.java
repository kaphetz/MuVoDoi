package com.welby.hae.ui.calendar.graph;

import android.content.Context;

import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.BubbleEntry;
import com.github.mikephil.charting.data.PieEntry;
import com.welby.hae.R;
import com.welby.hae.data.db.helper.RealmManager;
import com.welby.hae.data.db.model.PartDetail;
import com.welby.hae.data.db.model.Symptom;
import com.welby.hae.data.db.model.SymptomPartRelation;
import com.welby.hae.ui.base.BasePresenter;
import com.welby.hae.utils.Define;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Created by WelbyDev.
 */

class CalendarGraphPresenter extends BasePresenter {
    private static int PART_SIZE = 7;
    private static int MONTH_OF_YEAR = 12;
    private static int THROAT_ID = 7;
    private static float BUBBLE_SIZE = 1.4f;
    private static final int STATISTIC_JUMP = 10;
    private Context context;
    private CalendarGraphView calendarView;
    private List<Symptom> symptomList;

    CalendarGraphPresenter(Context context, CalendarGraphView calendarView) {
        this.context = context;
        this.calendarView = calendarView;
    }

    void setStatisticChartData(int monthCount) {
        float maxValue = 0;
        String avgValue;
        boolean isNoData = false;
        List<Symptom> symptomListTreatment;
        List<Symptom> symptomListTreatmentNone;
        Calendar calendar = Calendar.getInstance();
        int thisMonth = calendar.get(Calendar.MONTH);
        int thisYear = calendar.get(Calendar.YEAR);
        int startMonth = thisMonth - monthCount + 1;

        float startBar = 1;
        int index = 0;
        int jumpSpace = 12 / monthCount;

        ArrayList<BarEntry> values = new ArrayList<>();
        ArrayList<BarEntry> yValues = new ArrayList<>();
        String[] labels = new String[monthCount];
        String[] yLabels = new String[16];
        symptomList = new ArrayList<>();

        if (startMonth <= 0) {
            for (int month = startMonth; month < 0; month++) { // last yearSelected
                int queryMonth = month + MONTH_OF_YEAR;
                int lastYear = thisYear - 1;
                symptomListTreatment =  RealmManager.getRealmManager().getAllSymptomInMonthWithTreatment(queryMonth , lastYear, 1);
                symptomListTreatmentNone =  RealmManager.getRealmManager().getAllSymptomInMonthWithTreatment(queryMonth , lastYear, 0);
                symptomList.addAll(symptomListTreatment);
                symptomList.addAll(symptomListTreatmentNone);
                int symptomCount = symptomListTreatment.size() + symptomListTreatmentNone.size();
                if (symptomCount > maxValue) {
                    maxValue = symptomCount;
                }
                values.add(new BarEntry(
                        month,
                        new float[]{symptomListTreatment.size(), symptomListTreatmentNone.size()},
                        null));
            }

            for (int month = 0; month <= thisMonth; month++) {
                symptomListTreatment =  RealmManager.getRealmManager().getAllSymptomInMonthWithTreatment(month , thisYear, 1);
                symptomListTreatmentNone =  RealmManager.getRealmManager().getAllSymptomInMonthWithTreatment(month , thisYear, 0);
                symptomList.addAll(symptomListTreatment);
                symptomList.addAll(symptomListTreatmentNone);
                int symptomCount = symptomListTreatment.size() + symptomListTreatmentNone.size();
                if (symptomCount > maxValue) {
                    maxValue = symptomCount;
                }
                values.add(new BarEntry(
                        month,
                        new float[]{symptomListTreatment.size(), symptomListTreatmentNone.size()},
                        null));
            }
        } else {
            for (int month = startMonth; month <= thisMonth; month++) {
                symptomListTreatment =  RealmManager.getRealmManager().getAllSymptomInMonthWithTreatment(month , thisYear, 1);
                symptomListTreatmentNone =  RealmManager.getRealmManager().getAllSymptomInMonthWithTreatment(month , thisYear, 0);
                symptomList.addAll(symptomListTreatment);
                symptomList.addAll(symptomListTreatmentNone);
                int symptomCount = symptomListTreatment.size() + symptomListTreatmentNone.size();
                if (symptomCount > maxValue) {
                    maxValue = symptomCount;
                }
                values.add(new BarEntry(
                        month,
                        new float[]{symptomListTreatment.size(), symptomListTreatmentNone.size()},
                        null));
            }
        }

        // init label values
        for (int i = 0; i < values.size(); i++) {
            float value = values.get(i).getX();
            if (value < 0f) {
                value += 13;
            } else {
                value += 1;
            }
            labels[i] = String.valueOf((int) value);
        }

        // add empty data
        for (int i = 0; i < 3; i++, index++) {
            yValues.add(new BarEntry(
                    index,
                    new float[]{0, 0},
                    null));
            yLabels[index] = "";
        }

        for (int i = 1, j = 0; i < 13; i++, index++) {
            if (i % jumpSpace != 0) {
                yValues.add(new BarEntry(
                        index,
                        new float[]{0, 0},
                        null));
                yLabels[index] = "";
            } else {
                yValues.add(new BarEntry(
                        index,
                        values.get(j).getYVals(),
                        null));
                yLabels[index] = labels[j];
                j++;
            }
        }

        // add empty data
        yValues.add(new BarEntry(
                index,
                new float[]{0, 0},
                null));
        yLabels[index] = "";

        if (symptomList.size() == 0) {
            isNoData = true;
        }

        // caculate average value
        DecimalFormat decimalFormat;
        decimalFormat = new DecimalFormat("#0.##");
        avgValue = decimalFormat.format((float) symptomList.size() / monthCount);

        // caculate value for Y Axis
        List<BubbleEntry> yLabelData = generateYLabel(startBar, calculatedStatisticMaxValue(maxValue));

        calendarView.displayStatisticChart(yValues, yLabelData, yLabels, monthCount, calculatedStatisticMaxValue(maxValue), isNoData);
        calendarView.displayStatisticAverage(avgValue);
    }

    private List<BubbleEntry> generateYLabel(float startBar, float maxValue) {
        ArrayList<BubbleEntry> yLabelVals = new ArrayList<>();

        yLabelVals.add(new BubbleEntry(startBar, 0, 0));
        yLabelVals.add(new BubbleEntry(startBar, calculatedStatisticMaxValue(maxValue) / 2, BUBBLE_SIZE));
        yLabelVals.add(new BubbleEntry(startBar, calculatedStatisticMaxValue(maxValue), BUBBLE_SIZE));

        return yLabelVals;
    }

    void setPartChartData(Context context) {
        float maxValue = 0;
        boolean isNoData = false;
        String[] partsLabel;
        ArrayList<BarEntry> yValues = new ArrayList<>();
        partsLabel = context.getResources().getStringArray(R.array.graph_part_category);

        List<SymptomPartRelation> symptomPartRelationList = new ArrayList<>();
        for (Symptom symptom : symptomList) {
            symptomPartRelationList.addAll(symptom.getSymptomPartRelations());
        }
        float[] partVals = convertPartDetailToGroup(symptomPartRelationList);
        List<String> listPart =  new ArrayList<>();
        Collections.addAll(listPart, partsLabel);

        for (int i = 0; i < partVals.length / 2; i++) {
            float temp = partVals[i];
            partVals[i] = partVals[partVals.length - i - 1];
            partVals[partVals.length - i - 1] = temp;
        }

        for (int i = 0, j = 0; i < partVals.length; i++) {
            if (partVals[i] > maxValue) {
                maxValue = partVals[i];
            }
            if (partVals[i] == 0) {
                listPart.remove(partsLabel[i]);
            } else {
                yValues.add(new BarEntry(j, partVals[i], null));
                j++;
            }
        }
        Collections.reverse(listPart);
        partsLabel = listPart.toArray(new String[listPart.size()]);

        if (symptomPartRelationList.isEmpty()) {
            isNoData = true;
        }
        calendarView.displayPartChart(yValues, partsLabel, maxValue, isNoData);
    }

    private float[] convertPartDetailToGroup(List<SymptomPartRelation> symptomPartRelationList) {
        float[] partVals = new float[PART_SIZE];
        int partId = 0;
        int symptomId = 0;
        for (SymptomPartRelation symptomPartRelation : symptomPartRelationList) {
            int partDetailId = symptomPartRelation.getPartDetailId();
            PartDetail partDetail = RealmManager.getRealmManager().getPartDetailFromId(partDetailId);
            if (partId == partDetail.getPartId() && symptomId == symptomPartRelation.getSymptomId() && partDetailId != THROAT_ID) {
                continue;
            }
            if (partDetailId == THROAT_ID) {
                partVals[1]++;
            } else {
                partId = partDetail.getPartId();
                symptomId = symptomPartRelation.getSymptomId();
                switch (partId) {
                    case Define.BodyPart.FACE:
                        partVals[0]++;
                        break;
                    case Define.BodyPart.BODY:
                    case Define.BodyPart.BODY_BACK:
                        partVals[2]++;
                        break;
                    case Define.BodyPart.LEFT_ARM:
                    case Define.BodyPart.RIGHT_ARM:
                        partVals[3]++;
                        break;
                    case Define.BodyPart.LEFT_FINGER:
                    case Define.BodyPart.RIGHT_FINGER:
                        partVals[4]++;
                        break;
                    case Define.BodyPart.LEFT_TOE:
                    case Define.BodyPart.RIGHT_TOE:
                        partVals[5]++;
                        break;
                    case Define.BodyPart.LEFT_LEG:
                    case Define.BodyPart.LEFT_LEG_BACK:
                    case Define.BodyPart.RIGHT_LEG:
                    case Define.BodyPart.RIGHT_LEG_BACK:
                        partVals[6]++;
                        break;
                    default:
                        break;
                }
            }
        }

        return partVals;
    }

    void setPieChartData(Context context) {
        boolean isNoData = false;
        String[] chartLabels = context.getResources().getStringArray(R.array.graph_pie);
        int allSymptomCount = symptomList.size();
        int allSymptomHasTreatmentCount = 0;
        
        for (Symptom symptom : symptomList) {
            if (symptom.getTreatmentFlag() == 1) {
                allSymptomHasTreatmentCount++;
            }
        }
        
        float ariPercent = (float) allSymptomHasTreatmentCount / allSymptomCount * 100;
        ArrayList<PieEntry> entries = new ArrayList<>();
        if (ariPercent != 0) {
            entries.add(new PieEntry(ariPercent, chartLabels[0], null));
        } else {
            entries.add(new PieEntry(0, "", null));
        }
        if (100 - ariPercent != 0) {
            entries.add(new PieEntry(100 - ariPercent, chartLabels[1], null));
        } else {
            entries.add(new PieEntry(0, "", null));
        }

        if (allSymptomCount == 0) {
            isNoData = true;
        }
        calendarView.displayPieChart(entries, chartLabels, isNoData);
    }

    void setAverageProgressData() {
        int averagePercent = 0;
        int sumPain = 0;
        for (Symptom symptom : symptomList) {
            sumPain += symptom.getPainLevel();
        }

        if (!symptomList.isEmpty()) {
            averagePercent = Math.round(sumPain * 100f/ symptomList.size());
        }

        calendarView.displayAverageProgress(averagePercent);
    }

    /**
     * calculate max value for Y chart
     * @param value
     * @return
     */
    private float calculatedStatisticMaxValue(float value) {
        return (float) (STATISTIC_JUMP * Math.ceil(value / STATISTIC_JUMP));
    }
}
