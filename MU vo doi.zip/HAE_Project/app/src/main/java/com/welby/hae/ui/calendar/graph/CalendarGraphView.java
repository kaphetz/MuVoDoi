package com.welby.hae.ui.calendar.graph;

import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.BubbleEntry;
import com.github.mikephil.charting.data.PieEntry;
import com.welby.hae.ui.base.BaseView;

import java.util.List;

/**
 * Created by WelbyDev.
 */

interface CalendarGraphView extends BaseView {
    void displayStatisticChart(List<BarEntry> yValues, List<BubbleEntry> yLabelData, String[] yLabels, int monthCount, float maxValue, boolean isNoData);
    void displayStatisticAverage(String avgValue);
    void displayPartChart(List<BarEntry> yValues, String[] partsLabel, float maxValue, boolean isNoData);
    void displayPieChart(List<PieEntry> entries, String[] partsLabel, boolean isNoData);
    void displayAverageProgress(int averagePercent);
}
