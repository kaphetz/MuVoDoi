package com.welby.hae.ui.calendar.list;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.welby.hae.R;
import com.welby.hae.adapter.NoteListPagerAdapter;
import com.welby.hae.data.db.model.Symptom;
import com.welby.hae.ui.base.BaseFragment;
import com.welby.hae.ui.custom.NonSwipeableViewPager;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import static com.welby.hae.adapter.NoteListPagerAdapter.LOOPS_COUNT;

/**
 * Created by WelbyDev.
 */

public class CalendarListFragment extends BaseFragment implements View.OnClickListener, CalendarListView {
    private NonSwipeableViewPager noteViewPager;
    private NoteListPagerAdapter adapter;

    private TextView listTitle;
    private int currentPosition = LOOPS_COUNT / 2;
    private Calendar calendar;

    private Button prevYearBtn, nextYearBtn;

    private CalendarListPresenter presenter;

    public CalendarListFragment newInstance(Calendar calendar) {
        CalendarListFragment fragment = new CalendarListFragment();
        fragment.calendar = calendar;
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return LayoutInflater.from(getActivity()).inflate(R.layout.fragment_calendar_list, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initData();
    }

    @Override
    public void initView(View view) {
        noteViewPager = view.findViewById(R.id.year_note_viewpager);
        listTitle = view.findViewById(R.id.calendar_month_year_textview);
        prevYearBtn = view.findViewById(R.id.calendar_left_arrow);
        nextYearBtn = view.findViewById(R.id.calendar_right_arrow);
        prevYearBtn.setOnClickListener(this);
        nextYearBtn.setOnClickListener(this);
    }

    @Override
    public void initData() {
        presenter = new CalendarListPresenter(this);
        presenter.setListData(calendar.get(Calendar.YEAR));
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.calendar_left_arrow:
                changeYear(false);
                currentPosition--;
                noteViewPager.setCurrentItem(currentPosition);
                break;
            case R.id.calendar_right_arrow:
                changeYear(true);
                currentPosition++;
                noteViewPager.setCurrentItem(currentPosition);
                break;
            default:
                break;
        }
    }

    private void changeYear(boolean isNext) {
        if (isNext) {
            calendar.add(Calendar.YEAR, 1);
        } else {
            calendar.add(Calendar.YEAR, -1);
        }
        presenter.setListData(calendar.get(Calendar.YEAR));
        listTitle.setText(getString(R.string.calendar_list_title, calendar.get(Calendar.YEAR)));
    }

    @Override
    public void displayList(List<Symptom> symptomList) {
        if (symptomList == null) {
            symptomList = new ArrayList<>();
        }
        adapter = new NoteListPagerAdapter(getFragmentManager(), symptomList);
        noteViewPager.setAdapter(adapter);
        noteViewPager.setPagingEnabled(false);
        noteViewPager.setCurrentItem(currentPosition, false);
        listTitle.setText(getString(R.string.calendar_list_title, calendar.get(Calendar.YEAR)));
        noteViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                if (position == currentPosition) {
                    return;
                }
                if (position > currentPosition) {
                    changeYear(true);
                } else {
                    changeYear(false);
                }
                currentPosition = position;
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }
}
