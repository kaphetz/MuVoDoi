package com.welby.hae.ui.calendar.list;

import com.welby.hae.data.db.helper.RealmManager;
import com.welby.hae.data.db.model.Symptom;
import com.welby.hae.ui.base.BasePresenter;

import java.util.List;

/**
 * Created by WelbyDev.
 */

class CalendarListPresenter extends BasePresenter {
    private CalendarListView calendarView;

    CalendarListPresenter(CalendarListView calendarView) {
        this.calendarView = calendarView;
    }

    void setListData(int yearSelected) {
        List<Symptom> symptomList = RealmManager.getRealmManager().getAllSymptomInYear(yearSelected);
        calendarView.displayList(symptomList);
    }
}
