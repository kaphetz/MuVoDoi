package com.welby.hae.ui.calendar.list;

import com.welby.hae.data.db.model.Symptom;
import com.welby.hae.ui.base.BaseView;

import java.util.List;

/**
 * Created by WelbyDev.
 */

interface CalendarListView extends BaseView {
    void displayList(List<Symptom> symptomList);
}
