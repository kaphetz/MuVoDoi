package com.welby.hae.ui.calendar.list.content;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.welby.hae.R;
import com.welby.hae.adapter.NoteListAdapter;
import com.welby.hae.data.db.model.Symptom;
import com.welby.hae.ui.base.BaseFragment;
import com.welby.hae.ui.calendar.CalendarFragment;
import com.welby.hae.ui.custom.RecyclerViewDevider;
import com.welby.hae.ui.main.MainActivity;
import com.welby.hae.utils.Define;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by WelbyDev.
 */

public class NoteListFragment extends BaseFragment implements NoteListView {
    private RecyclerView noteView;
    private NoteListAdapter noteAdapter;
    private RecyclerView.LayoutManager layoutManager;
    private List<Symptom> symptomList;

    private NoteListPresenter presenter;

    public static NoteListFragment newInstance(List<Symptom> symptomList) {
        NoteListFragment fragment = new NoteListFragment();
        fragment.symptomList = symptomList;
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return LayoutInflater.from(getActivity()).inflate(R.layout.fragment_note_list, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initData();
    }

    @Override
    public void initView(View view) {
        noteView = view.findViewById(R.id.year_note_list);
    }

    @Override
    public void initData() {
        presenter = new NoteListPresenter(this);
        presenter.setDataList();
    }

    @Override
    public void displayNoteList() {
        noteView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getActivity());
        noteView.setLayoutManager(layoutManager);
        noteView.addItemDecoration(new RecyclerViewDevider(getActivity(), LinearLayoutManager.VERTICAL));
        if (symptomList == null) {
            symptomList = new ArrayList<>();
        }
        noteAdapter = new NoteListAdapter(getContext(), symptomList, false);
        noteAdapter.setOnItemClickListener(new NoteListAdapter.OnItemClickListener() {
            @Override
            public void onClick(Symptom symptom) {
                if (getParentFragment().getActivity() instanceof MainActivity) {
                    Bundle data = new Bundle();
                    data.putInt(Define.ExtrasKey.SYMPTOM_ID, symptom.getId());
                    data.putInt(Define.ExtrasKey.CALLER_FLAG, CalendarFragment.TAB_LIST);
                    ((MainActivity) getParentFragment().getActivity()).navigateToReview(data);
                }
            }
        });
        noteView.setAdapter(noteAdapter);
    }
}
