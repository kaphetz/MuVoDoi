package com.welby.hae.ui.calendar.list.content;

import com.welby.hae.ui.base.BasePresenter;

/**
 * Created by WelbyDev.
 */

class NoteListPresenter extends BasePresenter {
    private NoteListView noteListView;

    NoteListPresenter(NoteListView noteListView) {
        this.noteListView = noteListView;
    }

    void setDataList() {
        noteListView.displayNoteList();
    }
}