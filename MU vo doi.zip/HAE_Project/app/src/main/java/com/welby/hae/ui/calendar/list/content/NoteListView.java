package com.welby.hae.ui.calendar.list.content;

import com.welby.hae.ui.base.BaseView;

/**
 * Created by WelbyDev.
 */

interface NoteListView extends BaseView {
    void displayNoteList();
}
