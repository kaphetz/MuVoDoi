package com.welby.hae.ui.calendar.month;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.roomorama.caldroid.CaldroidFragment;
import com.roomorama.caldroid.CaldroidListener;
import com.welby.hae.HAEApplication;
import com.welby.hae.R;
import com.welby.hae.adapter.NoteListAdapter;
import com.welby.hae.data.db.model.Symptom;
import com.welby.hae.ui.base.BaseFragment;
import com.welby.hae.ui.calendar.CalendarFragment;
import com.welby.hae.ui.custom.RecyclerViewDevider;
import com.welby.hae.ui.main.MainActivity;
import com.welby.hae.utils.Define;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Created by WelbyDev.
 */

public class CalendarMonthFragment extends BaseFragment implements CalendarMonthView {
    private CaldroidFragment caldroidFragment;
    private RecyclerView noteView;
    private NoteListAdapter noteAdapter;
    private RecyclerView.LayoutManager layoutManager;
    private Context context;
    private CalendarMonthPresenter presenter;
    private List<Symptom> symptomList;
    private List<Symptom> symptomMonthList;
    private NestedScrollView calendarLayout;
    private Calendar calendar;
    private View dividerTop;

    public CalendarMonthFragment newInstance(List<Symptom> symptomList, Calendar calendar) {
        CalendarMonthFragment fragment = new CalendarMonthFragment();
        fragment.symptomList = symptomList;
        fragment.calendar = calendar;
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return LayoutInflater.from(getActivity()).inflate(R.layout.fragment_calendar_month, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initData();
    }

    @Override
    public void initView(View view) {
        noteView = view.findViewById(R.id.note_list);
        calendarLayout = view.findViewById(R.id.calendar_month_layout);
        dividerTop = view.findViewById(R.id.calendar_divider_top);
    }

    @Override
    public void initData() {
        context = getContext();
        caldroidFragment = new CaldroidFragment();
        Bundle args = new Bundle();
        args.putInt(CaldroidFragment.MONTH, calendar.get(Calendar.MONTH) + 1);
        args.putInt(CaldroidFragment.YEAR, calendar.get(Calendar.YEAR));
        args.putBoolean(CaldroidFragment.ENABLE_SWIPE, true);
        caldroidFragment.setArguments(args);

        presenter = new CalendarMonthPresenter(this);
        presenter.setDataForDates(symptomList);
    }

    @Override
    public void displayCalendar() {
        // Attach to the activity
        FragmentTransaction t = getActivity().getSupportFragmentManager().beginTransaction();
        t.replace(R.id.calendar_month_view, caldroidFragment);
        t.commit();

        // Setup listener
        final CaldroidListener listener = new CaldroidListener() {

            @Override
            public void onSelectDate(Date date, View view) {
                presenter.dateOnClick(symptomMonthList, date);
            }

            @Override
            public void onChangeMonth(int month, int year) {
                presenter.setDataForList(month, year);
            }

            @Override
            public void onLongClickDate(Date date, View view) {
                // nothing
            }

            @Override
            public void onCaldroidViewCreated() {
                presenter.setDataForList(calendar.get(Calendar.MONTH) + 1, calendar.get(Calendar.YEAR));
                caldroidFragment.moveToDate(calendar.getTime());
            }

        };

        caldroidFragment.setCaldroidListener(listener);
    }

    @Override
    public void setSelectedDate(Date date, int hasTreatment) {
        if (caldroidFragment != null) {
            caldroidFragment.setSelectedDate(date, hasTreatment);
        }
    }

    @Override
    public void displayList(List<Symptom> symptomList) {
        this.symptomMonthList = symptomList;
        noteView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getActivity());
        noteView.setNestedScrollingEnabled(false);
        noteView.setLayoutManager(layoutManager);
        noteView.addItemDecoration(new RecyclerViewDevider(context, LinearLayoutManager.VERTICAL));

        if (symptomList == null) {
            symptomList = new ArrayList<>();
        }

        if (symptomList.isEmpty()) {
            dividerTop.setVisibility(View.INVISIBLE);
        } else {
            dividerTop.setVisibility(View.VISIBLE);
        }

        noteAdapter = new NoteListAdapter(context, symptomList, true);
        noteAdapter.setOnItemClickListener(new NoteListAdapter.OnItemClickListener() {
            @Override
            public void onClick(Symptom symptom) {
                if (getParentFragment().getActivity() instanceof MainActivity) {
                    Bundle data = new Bundle();
                    data.putInt(Define.ExtrasKey.SYMPTOM_ID, symptom.getId());
                    data.putInt(Define.ExtrasKey.CALLER_FLAG, CalendarFragment.TAB_CALENDAR);
                    ((MainActivity) getParentFragment().getActivity()).navigateToReview(data);
                    HAEApplication.getInstance().trackEvent(context.getString(R.string.event_calender_list_tap));
                }
            }
        });
        noteView.setAdapter(noteAdapter);
    }

    @Override
    public void clickedDate(Date date, int position) {
        caldroidFragment.setClickedDate(date);
        caldroidFragment.refreshView();
        if (position >= 0) {
            float y = noteView.getChildAt(position).getBottom();
            calendarLayout.smoothScrollTo(0, (int) y);
        }
        HAEApplication.getInstance().trackEvent(context.getString(R.string.event_calender_day_tap));
    }
}
