package com.welby.hae.ui.calendar.month;

import com.welby.hae.data.db.helper.RealmManager;
import com.welby.hae.data.db.model.Symptom;
import com.welby.hae.ui.base.BasePresenter;
import com.welby.hae.utils.StringUtil;

import java.util.Date;
import java.util.List;

/**
 * Created by WelbyDev.
 */

class CalendarMonthPresenter extends BasePresenter {
    private CalendarMonthView calendarView;

    CalendarMonthPresenter(CalendarMonthView calendarView) {
        this.calendarView = calendarView;
    }

    void setDataForDates(List<Symptom> symptomList) {
        calendarView.displayCalendar();
        for (Symptom symptom : symptomList) {
            calendarView.setSelectedDate(symptom.getSeizureStartDate(), symptom.getTreatmentFlag());
        }
    }

    void setDataForList(int month, int year) {
        List<Symptom> symptomList = RealmManager.getRealmManager().getAllSymptomInMonth(month - 1, year);
        calendarView.displayList(symptomList);
    }

    void dateOnClick(List<Symptom> symptomList, Date date) {
        int position = -1;
        for (int i = 0; i < symptomList.size(); i++) {
            if (StringUtil.convertDateToString(date, StringUtil.DATE_FORMAT_1)
                    .equals(StringUtil.convertDateToString(symptomList.get(i).getSeizureStartDate(), StringUtil.DATE_FORMAT_1))) {
                position = i;
                break;
            }
        }
        calendarView.clickedDate(date, position);
    }
}
