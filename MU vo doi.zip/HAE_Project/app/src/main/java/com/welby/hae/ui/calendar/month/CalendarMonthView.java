package com.welby.hae.ui.calendar.month;

import com.welby.hae.data.db.model.Symptom;
import com.welby.hae.ui.base.BaseView;

import java.util.Date;
import java.util.List;

/**
 * Created by WelbyDev.
 */

interface CalendarMonthView extends BaseView {
    void displayCalendar();
    void setSelectedDate(Date date, int hasTreatment);
    void displayList(List<Symptom> symptomList);
    void clickedDate(Date date, int position);
}
