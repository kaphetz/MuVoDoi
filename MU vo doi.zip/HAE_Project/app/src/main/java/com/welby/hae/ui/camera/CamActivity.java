package com.welby.hae.ui.camera;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.welby.hae.HAEApplication;
import com.welby.hae.R;
import com.welby.hae.model.Photo;
import com.welby.hae.ui.base.BaseActivity;
import com.welby.hae.ui.custom.ClickHandler;
import com.welby.hae.ui.main.MainActivity;
import com.welby.hae.ui.symptomrecord.SymptomRecordActivity;
import com.welby.hae.utils.Define;

import io.fotoapparat.view.CameraView;

/**
 * Created by WelbyDev.
 */

public class CamActivity extends BaseActivity implements CamView, View.OnClickListener {
    private static final int PERMISSIONS_REQUEST_CODE = 100;

    private String[] permissionsRequired = new String[]{
            Manifest.permission.CAMERA,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE};

    private ImageView ivExit;
    private ImageView ivSwitchCamera;
    private ImageView ivCapture;
    private TextView tvSave;
    private TextView tvReShoot;
    private View layoutActionFinish;
    private CameraView camera;

    private CamPresenter presenter;
    private ClickHandler clickHandler;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLastVisibleActivity(CamActivity.class.getName());
        initView();
        initData();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (checkPermissions()) {
            presenter.startCam();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        //hide the status bar
        if (getWindow() != null) {
            View decorView = getWindow().getDecorView();
            int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
            decorView.setSystemUiVisibility(uiOptions);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (checkPermissions()) {
            presenter.stopCam();
        }
    }

    @Override
    public void initView() {
        setContentView(R.layout.activity_camera);
        camera = findViewById(R.id.camera_view);
        ivExit = findViewById(R.id.iv_exit);
        ivSwitchCamera = findViewById(R.id.iv_switch_camera);
        ivCapture = findViewById(R.id.iv_capture);
        tvSave = findViewById(R.id.tv_save);
        tvReShoot = findViewById(R.id.tv_re_shoot);

        layoutActionFinish = findViewById(R.id.layout_action_finish);

        ivExit.setOnClickListener(this);
        ivCapture.setOnClickListener(this);
        tvSave.setOnClickListener(this);
        tvReShoot.setOnClickListener(this);
        ivSwitchCamera.setOnClickListener(this);
    }

    /**
     * init data if permission was granted
     */
    @Override
    public void initData() {
        if (!checkPermissions()) {
            ActivityCompat.requestPermissions(this,
                    permissionsRequired,
                    PERMISSIONS_REQUEST_CODE);
            return;
        }

        presenter = new CamPresenter(this, this, camera);
        clickHandler = new ClickHandler(Define.CLICK_DELAY);
    }

    @Override
    public void onClick(View view) {
        if (!clickHandler.isClickable(view.getId())) {
            return;
        }
        switch (view.getId()) {
            case R.id.iv_exit:
                finish();
                break;
            case R.id.iv_capture:
                layoutActionFinish.setVisibility(View.VISIBLE);
                ivCapture.setVisibility(View.INVISIBLE);
                ivSwitchCamera.setVisibility(View.INVISIBLE);
                presenter.capture();
                HAEApplication.getInstance().trackEvent(getString(R.string.event_record_camera_shot));
                break;
            case R.id.tv_save:
                presenter.save(this);
                HAEApplication.getInstance().trackEvent(getString(R.string.event_record_camera_save));
                break;
            case R.id.tv_re_shoot:
                presenter.reShoot();
                HAEApplication.getInstance().trackEvent(getString(R.string.event_record_camera_reshoot));
                break;
            case R.id.iv_switch_camera:
                presenter.switchCamera(this, camera);
                break;
            default:
                break;
        }
    }

    /**
     * when photo is saved
     *
     * @param photo pass to SymptomRecordActivity
     */
    @Override
    public void saveSuccessfully(Photo photo) {
        String callerFlag = getIntent().getStringExtra(Define.ExtrasKey.CALLER_FLAG); //the origin activity which start CamActivity

        Intent intent;
        if (MainActivity.class.getName().equals(callerFlag)) {
            intent = new Intent(this, SymptomRecordActivity.class);
        } else {
            intent = new Intent();
        }

        Bundle data = new Bundle();
        data.putParcelable(Define.ExtrasKey.PHOTO, photo);
        intent.putExtras(data);

        if (MainActivity.class.getName().equals(callerFlag)) {
            startActivity(intent);
        } else {
            setResult(RESULT_OK, intent);
        }

        finish();
    }

    /**
     * when photo is captured
     * flip captured photo if isFrontCam
     */
    @Override
    public void setCapturedPhoto(boolean isFrontCam) {
        camera.setScaleX(isFrontCam ? -1 : 1);
    }

    @Override
    public void reShoot() {
        camera.setScaleX(1);
        ivCapture.setVisibility(View.VISIBLE);
        ivSwitchCamera.setVisibility(View.VISIBLE);
        layoutActionFinish.setVisibility(View.GONE);
    }

    @Override
    public void showPermissionsRequiredAlert(String message) {
        new AlertDialog.Builder(this, R.style.PermissionAlertDialogStyle)
                .setMessage(message)
                .setNegativeButton(R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        finish();
                    }
                })
                .create()
                .show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults.length > 2
                && grantResults[0] == PackageManager.PERMISSION_GRANTED
                && grantResults[1] == PackageManager.PERMISSION_GRANTED
                && grantResults[2] == PackageManager.PERMISSION_GRANTED) { //all permissions was granted
            if (requestCode == PERMISSIONS_REQUEST_CODE) {
                initData();
                presenter.startCam();
            }
        } else {
            StringBuilder message = new StringBuilder(getString(R.string.pd_permission_denied));
            if (grantResults[0] == PackageManager.PERMISSION_DENIED) {
                message.append(Define.STR_RETURN).append(getString(R.string.pd_permission_camera));
            }
            if (grantResults[1] == PackageManager.PERMISSION_DENIED || grantResults[2] == PackageManager.PERMISSION_DENIED) {
                message.append(Define.STR_RETURN).append(getString(R.string.pd_permission_storage));
            }
            showPermissionsRequiredAlert(message.toString());
        }

    }

    /**
     * check access camera permissions.
     *
     * @return false if permission denied
     */
    private boolean checkPermissions() {
        return ContextCompat.checkSelfPermission(this, permissionsRequired[0]) == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, permissionsRequired[1]) == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, permissionsRequired[2]) == PackageManager.PERMISSION_GRANTED;
    }

}
