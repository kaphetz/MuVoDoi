package com.welby.hae.ui.camera;

import android.content.Context;
import android.os.Handler;
import android.support.v7.app.AlertDialog;

import com.welby.hae.R;
import com.welby.hae.model.Photo;
import com.welby.hae.ui.base.BasePresenter;
import com.welby.hae.utils.Define;
import com.welby.hae.utils.FileUtil;

import java.io.File;
import java.io.IOException;
import java.util.Collection;

import io.fotoapparat.Fotoapparat;
import io.fotoapparat.parameter.LensPosition;
import io.fotoapparat.parameter.ScaleType;
import io.fotoapparat.parameter.selector.SelectorFunction;
import io.fotoapparat.photo.BitmapPhoto;
import io.fotoapparat.result.PendingResult;
import io.fotoapparat.result.PhotoResult;
import io.fotoapparat.view.CameraView;

import static io.fotoapparat.parameter.selector.FocusModeSelectors.autoFocus;
import static io.fotoapparat.parameter.selector.FocusModeSelectors.continuousFocus;
import static io.fotoapparat.parameter.selector.FocusModeSelectors.fixed;
import static io.fotoapparat.parameter.selector.LensPositionSelectors.back;
import static io.fotoapparat.parameter.selector.LensPositionSelectors.front;
import static io.fotoapparat.parameter.selector.Selectors.firstAvailable;
import static io.fotoapparat.parameter.selector.SizeSelectors.biggestSize;

/**
 * Created by WelbyDev.
 */

class CamPresenter extends BasePresenter {
    private static final long SAVED_SUCCESSFULLY_DIALOG_DISPLAY_TIME = 500; //in Millis
    private CamView camView;
    private Fotoapparat fotoapparat;
    private Photo photoResult;
    private boolean isCamFront = false;
    private CamScreenState screenState = CamScreenState.INITIALIZE;
    private Handler handler;
    private boolean allowSave;

    /**
     * INITIALIZE: cam is stopped
     * RECORDING: cam is recording
     * PREVIEWING: cam is stopped and preview captured photo is showing
     */
    private enum CamScreenState {
        INITIALIZE, RECORDING, PREVIEWING
    }

    /**
     * init presenter
     * config Fotoapparat
     */
    CamPresenter(CamView camView, Context context, CameraView camera) {
        this.camView = camView;
        fotoapparat = Fotoapparat
                .with(context)
                .into(camera)           // view which will draw the camera preview
                .previewScaleType(ScaleType.CENTER_CROP)  // make the preview fill the view
                .photoSize(biggestSize())   // return the biggest photo possible
                .lensPosition(back())       // back camera
                .focusMode(firstAvailable(  // (optional) use the first focus mode which is supported by device
                        continuousFocus(),
                        autoFocus(),        // in case if continuous focus is not available on device, auto focus will be used
                        fixed()             // if even auto focus is not available - fixed focus mode will be used
                ))
                .build();
        handler = new Handler();
    }

    void startCam() {
        if (screenState == CamScreenState.INITIALIZE) {
            fotoapparat.start();
            screenState = CamScreenState.RECORDING;
        }
    }

    void stopCam() {
        if (screenState == CamScreenState.RECORDING) {
            fotoapparat.stop();
            screenState = CamScreenState.INITIALIZE;
        }
    }

    void capture() {
        photoResult = FileUtil.getTempPhotoFile();
        fotoapparat.takePicture()
                .saveToFile(new File(photoResult.getPath()));
        stopCam();
        screenState = CamScreenState.PREVIEWING;
        camView.setCapturedPhoto(isCamFront);

        allowSave = false;
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                allowSave = true;
            }
        }, Define.CLICK_DELAY);
    }

    /**
     * show save photo successfully dialog in SAVED_SUCCESSFULLY_DIALOG_DISPLAY_TIME millisecond
     */
    void save(Context context) {
        if (!allowSave) {
            return;
        }
        final AlertDialog dialog = new AlertDialog.Builder(context, R.style.CamAlertDialogStyle)
                .setMessage(context.getString(R.string.cam_photo_saved))
                .create();
        dialog.show();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                dialog.dismiss();
                camView.saveSuccessfully(photoResult);
            }
        }, SAVED_SUCCESSFULLY_DIALOG_DISPLAY_TIME);
    }

    void reShoot() {
        screenState = CamScreenState.INITIALIZE;
        startCam();
        camView.reShoot();
    }

    void switchCamera(Context context, CameraView cameraView) {
        stopCam();
        fotoapparat = Fotoapparat
                .with(context)
                .into(cameraView)           // view which will draw the camera preview
                .previewScaleType(ScaleType.CENTER_CROP)  // make the preview fill the view
                .photoSize(biggestSize())   // return the biggest photo possible
                .lensPosition(isLensCamera())       // which camera
                .focusMode(firstAvailable(  // (optional) use the first focus mode which is supported by device
                        continuousFocus(),
                        autoFocus(),        // in case if continuous focus is not available on device, auto focus will be used
                        fixed()             // if even auto focus is not available - fixed focus mode will be used
                ))
                .build();
        reShoot();
    }

    private SelectorFunction<Collection<LensPosition>, LensPosition> isLensCamera() {
        if (isCamFront) {
            isCamFront = false;
            return back();
        } else {
            isCamFront = true;
            return front();
        }
    }
}
