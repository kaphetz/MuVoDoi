package com.welby.hae.ui.camera;

import com.welby.hae.model.Photo;
import com.welby.hae.ui.base.BaseView;

/**
 * Created by WelbyDev.
 */

public interface CamView extends BaseView {
    void saveSuccessfully(Photo photo);

    void setCapturedPhoto(boolean isFrontCam);

    void reShoot();

    void showPermissionsRequiredAlert(String message);
}
