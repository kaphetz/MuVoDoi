package com.welby.hae.ui.cameraroll;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.welby.hae.R;
import com.welby.hae.adapter.CameraRollAdapter;
import com.welby.hae.model.Photo;
import com.welby.hae.ui.base.BaseActivity;
import com.welby.hae.ui.custom.CameraRollDivider;
import com.welby.hae.utils.Define;

import java.util.ArrayList;

/**
 * Created by WelbyDev.
 */

public class CameraRollActivity extends BaseActivity implements CameraRollView, View.OnClickListener {
    private static final int CAMERA_ROLL_COLUMN_COUNT = 3;
    private static final int ACCESS_STORAGE_REQUEST_CODE = 100;

    private RecyclerView rvCamRoll;
    private TextView tvPickedCount;

    private String[] permissionsRequired = new String[]{
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE};
    private int numberOfSelectedPhotos;

    private CameraRollPresenter presenter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setLastVisibleActivity(CameraRollActivity.class.getName());
        initView();
        initData();
    }

    @Override
    public void initView() {
        setContentView(R.layout.activity_camera_roll);
        ImageView ivClose = findViewById(R.id.iv_close);
        Button btnSave = findViewById(R.id.btn_save);
        tvPickedCount = findViewById(R.id.tv_picked_count);
        rvCamRoll = findViewById(R.id.rv_camera_roll);

        ivClose.setOnClickListener(this);
        btnSave.setOnClickListener(this);
    }

    /**
     * init data if permissions allowed
     * else open request permissions dialog
     */
    @Override
    public void initData() {
        numberOfSelectedPhotos = getIntent().getIntExtra(Define.ExtrasKey.NUMBER_OF_SELECTED_PHOTOS, 0);
        setPhotoPickedCount(0);

        if (!checkPermissions()) {
            ActivityCompat.requestPermissions(this,
                    permissionsRequired,
                    ACCESS_STORAGE_REQUEST_CODE);
            return;
        }

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int screenWidth = displayMetrics.widthPixels;

        presenter = new CameraRollPresenter(this);
        presenter.setCamRollAdapter(this, screenWidth / CAMERA_ROLL_COLUMN_COUNT, Define.MAX_PHOTOS - numberOfSelectedPhotos);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.iv_close:
                presenter.exit();
                break;
            case R.id.btn_save:
                presenter.save();
                break;
            default:
                break;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (requestCode == ACCESS_STORAGE_REQUEST_CODE) {
                initData();
            }
        } else {
            showPermissionsRequiredAlert(getString(R.string.pd_permission_denied)
                    + Define.STR_RETURN
                    + getString(R.string.pd_permission_storage));
        }

    }

    /**
     * set adapter to camera roll recycler view
     *
     * @param adapter camera roll adapter
     */
    @Override
    public void setCamRollAdapter(CameraRollAdapter adapter) {
        rvCamRoll.setLayoutManager(new GridLayoutManager(this, CAMERA_ROLL_COLUMN_COUNT));
        rvCamRoll.addItemDecoration(new CameraRollDivider(getResources().getDimensionPixelSize(R.dimen.cr_item_padding)));
        rvCamRoll.setHasFixedSize(true);
        rvCamRoll.setAdapter(adapter);
    }

    /**
     * display number of picked photos (on the top right screen)
     *
     * @param numberOfAddedPhotos photos has just been added
     */
    @Override
    public void setPhotoPickedCount(int numberOfAddedPhotos) {
        tvPickedCount.setText(getResources().getString(R.string.cr_number_of_pics, numberOfSelectedPhotos + numberOfAddedPhotos));
    }

    @Override
    public void showPermissionsRequiredAlert(String message) {
        new AlertDialog.Builder(this, R.style.PermissionAlertDialogStyle)
                .setMessage(message)
                .setNegativeButton(R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        finish();
                    }
                })
                .setCancelable(false)
                .create()
                .show();
    }

    /**
     * return photoPaths to SymptomRecordActivity
     *
     * @param photoList compressed and saved photo paths
     */
    @Override
    public void save(ArrayList<Photo> photoList) {
        Intent intent = new Intent();
        Bundle data = new Bundle();
        data.putParcelableArrayList(Define.ExtrasKey.PHOTO_LIST, photoList);
        intent.putExtras(data);
        setResult(RESULT_OK, intent);
        finish();
    }

    @Override
    public void exit() {
        finish();
    }

    /**
     * check storage access permissions.
     *
     * @return false if permission denied
     */
    private boolean checkPermissions() {
        return ContextCompat.checkSelfPermission(this, permissionsRequired[0]) == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, permissionsRequired[1]) == PackageManager.PERMISSION_GRANTED;
    }

}
