package com.welby.hae.ui.cameraroll;

import android.content.Context;

import com.welby.hae.adapter.CameraRollAdapter;
import com.welby.hae.model.Photo;
import com.welby.hae.ui.base.BasePresenter;
import com.welby.hae.utils.FileUtil;
import com.welby.hae.utils.Utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Created by WelbyDev.
 */

public class CameraRollPresenter extends BasePresenter {
    private CameraRollView camRollView;
    private ArrayList<Photo> photoList;
    private CameraRollAdapter camRollAdapter;

    public CameraRollPresenter(CameraRollView camRollView) {
        this.camRollView = camRollView;
    }

    public void setCamRollAdapter(Context context, int cellSize, int numberOfSelectablePhotos) {
        photoList = Utils.getCameraPhotos(context);
        camRollAdapter = new CameraRollAdapter(photoList, cellSize, numberOfSelectablePhotos, new ArrayList<Integer>());
        camRollAdapter.setOnItemClickListener(new CameraRollAdapter.CameraRollListener() {
            @Override
            public void onItemClick(int position) {
                camRollAdapter.setItemSelected(position);
                camRollView.setPhotoPickedCount(camRollAdapter.getNumberOfPickedPhotos());
            }
        });
        camRollView.setCamRollAdapter(camRollAdapter);
    }

    public void save() {
        camRollView.save(camRollAdapter.getPickedPhotos());
    }

    public void exit() {
        camRollView.exit();
    }
}
