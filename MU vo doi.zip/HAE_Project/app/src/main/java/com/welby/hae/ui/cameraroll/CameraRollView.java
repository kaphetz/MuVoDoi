package com.welby.hae.ui.cameraroll;

import com.welby.hae.adapter.CameraRollAdapter;
import com.welby.hae.model.Photo;
import com.welby.hae.ui.base.BaseView;

import java.util.ArrayList;

/**
 * Created by WelbyDev.
 */

public interface CameraRollView extends BaseView {
    void setCamRollAdapter(CameraRollAdapter adapter);

    void setPhotoPickedCount(int numberOfAddedPhotos);

    void showPermissionsRequiredAlert(String message);

    void save(ArrayList<Photo> photoList);

    void exit();
}
