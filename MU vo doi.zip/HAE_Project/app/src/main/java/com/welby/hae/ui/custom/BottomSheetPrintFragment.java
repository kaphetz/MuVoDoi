package com.welby.hae.ui.custom;

import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomSheetDialogFragment;
import android.support.design.widget.CoordinatorLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.welby.hae.R;

/**
 * Created by Welby Dev on 10/10/2017.
 * File name: BottomSheetPrintFragment
 */

public class BottomSheetPrintFragment extends BottomSheetDialogFragment implements View.OnClickListener {

    private final String TAG = BottomSheetPrintFragment.class.getSimpleName();

    Button btnSaveImages, btnCancel;

    public BottomSheetPrintFragment() {}

    public interface BottomSheetPrintFragmentListener {
        void onSaveImages();
    }

    BottomSheetPrintFragmentListener listener;

   /* @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        View view = inflater.inflate(R.layout.bottom_sheet_print, container, false);

        return view;
    }*/

    @Override
    public void setupDialog(Dialog dialog, int style) {
        super.setupDialog(dialog, style);

        View contentView = View.inflate(getContext(), R.layout.bottom_sheet_print, null);
        dialog.setContentView(contentView);

        /*CoordinatorLayout.LayoutParams params = (CoordinatorLayout.LayoutParams) ((View) contentView.getParent())
                .getLayoutParams();
        CoordinatorLayout.Behavior behavior = params.getBehavior();*/
        ((View) contentView.getParent()).setBackgroundColor(getResources().getColor(android.R.color.transparent));

        initView(contentView);
        btnSaveImages.setOnClickListener(this);
        btnCancel.setOnClickListener(this);

    }

    /*@Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);





    }*/

    private void initView(View view) {
        btnSaveImages = (Button) view.findViewById(R.id.btn_saveImages);
        btnCancel = (Button) view.findViewById(R.id.btn_cancel);
    }



    @Override
    public void onDismiss(DialogInterface dialog) {
        super.onDismiss(dialog);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_saveImages:
                listener = (BottomSheetPrintFragmentListener) getActivity();
                listener.onSaveImages();
                dismiss();
                break;
            case R.id.btn_cancel:
                dismiss();
                break;
        }
    }
}
