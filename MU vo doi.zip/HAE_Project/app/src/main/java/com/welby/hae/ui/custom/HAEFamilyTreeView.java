package com.welby.hae.ui.custom;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Pair;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;
import com.welby.hae.R;
import com.welby.hae.data.db.model.Member;
import com.welby.hae.utils.Utils;

import java.util.LinkedList;

import io.realm.RealmResults;

/**
 * Custom family TreeView for HAE
 */
public class HAEFamilyTreeView extends ViewGroup {
    public static final String TAG = "HAEFamilyTreeView";

    public interface OnCalculateListener {
        void onCalculatedViewSize(float ratio, Point focusPoint);
    }

    public OnCalculateListener mOnCalculateListener;

    private enum Part {
        I(1),
        II(-1);

        int value;

        Part(int i) {
            value = i;
        }

        public int getValue() {
            return value;
        }
    }

    private enum ChildType {
        WOMAN,
        MAN
    }

    public static final int ME_GENERATION = 0;

    private Paint mPaint;

    public int mLineWColor;
    public int mLineWidthPX;
    public int mLineUpHigh;

    public float viewSizeRatio;
    public int itemWidth;
    public int itemHeight;
    public int itemHeightAndSpace;
    public int itemWidthAndSpace;

    private int mWidthMeasureSpec;
    private int mHeightMeasureSpec;

    private Point centerPoint;
    private Rect mItemRect;

    private int screenWidth;
    private int screenHeight;

    RequestManager glide;
    private LayoutInflater layoutInflater;

    // max view width
    private int mMaxWidthPX;
    // max view height
    private int mMaxHeightPX;

    // MinX to calculate view x
    private int minX;

    // For calculate x to beauty view position
    private int maxMeAndSibling;

    private RealmResults<Member> memberList;

    private LinkedList<MemberLine> memberLines;
    private LinkedList<Pair<Member, Point>> memberPointQueue;
    private LinkedList<Pair<Member, View>> memberViewQueue;

    // ME object
    private Member me;

    private OnFamilyTreeActionListener mOnMemberActionListener;

    public HAEFamilyTreeView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    public HAEFamilyTreeView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    public void init(Context context, AttributeSet attrs) {
        // START - Get typed value
        final TypedArray ta = getContext().getTheme()
                .obtainStyledAttributes(attrs, R.styleable.HAEFamilyTreeView, 0, 0);
        mLineWidthPX = ta.getDimensionPixelSize(R.styleable.HAEFamilyTreeView_line_size, 0);
        itemWidth = ta.getDimensionPixelSize(R.styleable.HAEFamilyTreeView_item_width, 0);
        itemHeight = ta.getDimensionPixelSize(R.styleable.HAEFamilyTreeView_item_height, 0);
        mLineWColor = ta.getColor(R.styleable.HAEFamilyTreeView_line_color, 0);
        viewSizeRatio = ta.getFloat(R.styleable.HAEFamilyTreeView_view_size_ratio, 1);

        mWidthMeasureSpec = MeasureSpec.makeMeasureSpec(itemWidth, MeasureSpec.EXACTLY);
        mHeightMeasureSpec = MeasureSpec.makeMeasureSpec(itemHeight, MeasureSpec.EXACTLY);

        itemHeightAndSpace = (int) (itemHeight * 1.4f);
        itemWidthAndSpace = (int) (itemWidth * 1.3f);

        mLineUpHigh = itemHeight / 5;
        // END - Get typed value


        layoutInflater = LayoutInflater.from(context);
        glide = Glide.with(context);

        setWillNotDraw(false);


        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mPaint.reset();
        mPaint.setColor(mLineWColor);
        mPaint.setStrokeWidth(mLineWidthPX);
        mPaint.setStyle(Paint.Style.STROKE);

        getScreenSize();
    }

    /**
     * Set current member
     *
     * @param currentMember "ME"
     * @param focusMember   Member to be focused on
     */
    public void setCurrentMember(Member currentMember, Member focusMember) {
        recycleAllView();
        initWidthAndHeight();
        // Move to left-top 0.5 item size for lazy calculate item coordinate
        centerPoint = new Point(mMaxWidthPX / 2 - itemWidth / 2, mMaxHeightPX / 2 - itemHeight / 2);
        // find child view rect
        mItemRect = new Rect(centerPoint.x, centerPoint.y, centerPoint.x, centerPoint.y);

        initData(currentMember);
        initView();

        findChildViewBound();
        // Add padding for nice draw
        addPaddingForItemRange();
        // normalize react to square again
        normalizeItemRect();

        moveAllMemberViewToLeftTop();
        moveAllMemberLineToLeftTop();

        invalidate();

        if (null != mOnCalculateListener) {
            // Take care
            Point focusMemberPoint = memberPointQueue.get(memberPointQueue.indexOf(focusMember)).second;
            Point actualFocusPoint = new Point(focusMemberPoint.x + itemWidth / 2, focusMemberPoint.y + itemHeight / 2);

            mOnCalculateListener.onCalculatedViewSize((float)mItemRect.width() / (float)screenWidth, actualFocusPoint);
        }
    }

    private void normalizeItemRect() {
        int boundWidth = mItemRect.width();
        int boundHeight = mItemRect.height();

        if (boundWidth < boundHeight) {
            mItemRect.top -= screenWidth / 2f;
            mItemRect.bottom += screenWidth / 2f;

            int expectedW = (int) (mItemRect.height() * viewSizeRatio);
            int diff = expectedW - mItemRect.width();
            mItemRect.left -= diff / 2;
            mItemRect.right += diff / 2;
        } else {
            mItemRect.left -= screenWidth / 2f;
            mItemRect.right += screenWidth / 2f;

            int expectedH = (int) (mItemRect.width() / viewSizeRatio);
            int diff = expectedH - mItemRect.height();
            mItemRect.top -= diff / 2;
            mItemRect.bottom += diff / 2;
        }
    }


    private void addPaddingForItemRange() {
        mItemRect.left -= screenWidth / 2f;
        mItemRect.top -= screenWidth / 2f;
        mItemRect.right += screenWidth / 2f;
        mItemRect.bottom += screenWidth / 2f;
    }

    /**
     * Because we have to crop view ---> must move all item to top-left of cropped-view
     */
    private void moveAllMemberViewToLeftTop() {
        int leftTranslate = mItemRect.left;
        int topTranslate = mItemRect.top;

        for (Pair<Member, Point> pair : memberPointQueue) {
            Point point = pair.second;
            translatePointBy(point, leftTranslate, topTranslate);
        }
    }

    /**
     * Because we have to crop view ---> must move all line to top-left of cropped-view
     */
    private void moveAllMemberLineToLeftTop() {
        int leftTranslate = mItemRect.left;
        int topTranslate = mItemRect.top;
        for (MemberLine memberLine : memberLines) {
            memberLine.translateBy(leftTranslate, topTranslate);
        }
    }

    /**
     * Translate view by left-top
     *
     * @param point Point to be translated
     * @param left  Left translate
     * @param top   Top translate
     */
    public void translatePointBy(Point point, int left, int top) {
        point.x -= left;
        point.y -= top;
    }

    /**
     * Find all view bound
     */
    private void findChildViewBound() {
        for (Pair<Member, Point> pair : memberPointQueue) {
            Point point = pair.second;
            if (mItemRect.left > point.x) {
                mItemRect.left = point.x;
            }

            if (mItemRect.top > point.y) {
                mItemRect.top = point.y;
            }

            if (mItemRect.bottom < point.y) {
                mItemRect.bottom = point.y;
            }

            if (mItemRect.right < point.x) {
                mItemRect.right = point.x;
            }
        }

        mItemRect.right += itemWidth;
        mItemRect.bottom += itemHeight;
    }

    public void recycleAllView() {
        this.removeAllViews();
    }

    /**
     * convert passed data to queue
     */
    public void initData(Member currentMember) {
        // clear old list by recreate new
        this.memberPointQueue = new LinkedList<>();
        this.memberViewQueue = new LinkedList<>();
        this.memberLines = new LinkedList<>();

        this.me = currentMember;
        this.me.setGeneration(ME_GENERATION);
    }

    private void getScreenSize() {
        WindowManager wm = (WindowManager) getContext().getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        Point point = new Point();
        display.getSize(point);
        int resource = getContext().getResources().getIdentifier("status_bar_height", "dimen", "android");
        int statusBarHeight = 0;
        if (resource > 0) {
            statusBarHeight = getContext().getResources().getDimensionPixelSize(resource);
        }

        screenWidth = point.x;
        screenHeight = point.y - statusBarHeight;
    }

    private void initWidthAndHeight() {

        int tempW = memberList.size() * (itemWidth + itemWidthAndSpace);
        int tempH = memberList.size() * (itemHeight + itemWidthAndSpace);
        mMaxWidthPX = screenWidth > tempW ? screenWidth : tempW;
        mMaxHeightPX = screenHeight > tempH ? screenHeight : tempH;
    }

    /**
     * Initialize view based on members
     * All part of family tree will be drawn on 4 part like below
     * III  |  IV
     * -----------
     * II   |   I
     * <p>
     * I for me' part
     * II for sibling part
     * III for mother family
     * IV for father family
     */
    private void initView() {
        // ===========[START] traversal list and add to ==========
        minX = centerPoint.x;

        //=====[START] Add my family===
        // This part will draw on part I
        addMembersTypeIAndII(Part.I, me);
        //=====[END] Add my family===

        //=====[START] Add sibling family===
        // This part will draw on part II
        // Move center point to me

        // If member has only one child. re-calculate minx
        if (null != me.getChildren() && 1 == me.getChildren().size()) {
            minX = centerPoint.x - itemWidthAndSpace - itemWidth;
        } else {
            minX = centerPoint.x - itemWidthAndSpace;
        }
        RealmResults<Member> sibling = me.getSibling();
        for (Member fm : sibling) {
            fm.setGeneration(ME_GENERATION);
            addMembersTypeIAndII(Part.II, fm);
        }
        //=====[END] Add sibling family===

        //=====[START] Add parent family===
        //This part will draw on part III

        Point mePoint = memberPointQueue.get(memberPointQueue.indexOf(me)).second;

        // Move center point to my x
        centerPoint.x = mePoint.x;
        minX = mePoint.x + itemWidth / 2;
        if (me.hasMother()) {
            maxMeAndSibling = 0;
            Member mother = me.getMotherFamilyTreeId();
            if (null != mother) {
                mother.setGeneration(this.me.getGeneration() - 1);
                addMembersTypeIII(ChildType.WOMAN, mother);
            }
        }

        // This part will draw on part IV
        // Move center point to my x
        centerPoint.x = mePoint.x;
        minX = mePoint.x - itemWidth / 2;
        if (me.hasFather()) {
            maxMeAndSibling = 0;
            Member father = me.getFatherFamilyTreeId();
            if (null != father) {
                father.setGeneration(this.me.getGeneration() - 1);
                addMembersTypeIV(ChildType.MAN, father);
            }
        }

        //=====[END] Add parent family===

        // Draw line between member in my family
        // me and sibling
        int meStartX = memberPointQueue.get(memberPointQueue.indexOf(me)).second.x + itemWidth / 2;
        int meStartY = memberPointQueue.get(memberPointQueue.indexOf(me)).second.y;
        {
            int startX = meStartX;
            int startY = meStartY;
            for (Member fm : sibling) {
                int fmEndX = memberPointQueue.get(memberPointQueue.indexOf(fm)).second.x + itemWidth / 2;
                int fmEndY = memberPointQueue.get(memberPointQueue.indexOf(fm)).second.y;
                memberLines.add(new MemberLine(startX, startY, fmEndX, fmEndY, LineType.SIBLING));
                startX = fmEndX;
                startY = fmEndY;
            }
        }

        // me and parent
        if (me.hasMother() || me.hasFather()) {
            Point motherPoint = null;
            if (me.hasMother()) {
                centerPoint.x = meStartX;
                minX = centerPoint.x;
                Member mother = me.getMotherFamilyTreeId();
                if (null != mother) {
                    motherPoint = memberPointQueue.get(memberPointQueue.indexOf(mother)).second;
                }
            }

            Point fatherPoint = null;
            if (me.hasFather()) {
                centerPoint.x = meStartX;
                minX = centerPoint.x;
                Member father = me.getFatherFamilyTreeId();
                if (null != father) {
                    fatherPoint = memberPointQueue.get(memberPointQueue.indexOf(father)).second;
                }
            }

            if (null != fatherPoint && me.hasFather() && null != motherPoint && me.hasMother()) {
                // draw between parent
                memberLines.add(new MemberLine(motherPoint.x + itemWidth, motherPoint.y + itemHeight / 2, fatherPoint.x, motherPoint.y + itemHeight / 2, LineType.PARENT));
                // Add line parent to children
                memberLines.add(new MemberLine(meStartX, meStartY, meStartX, motherPoint.y + itemHeight / 2, LineType.CHILD));
            } else if (null != fatherPoint && me.hasFather()) {
                memberLines.add(new MemberLine(meStartX, meStartY, fatherPoint.x + itemWidth / 2, fatherPoint.y + itemHeight, LineType.MOTHER_OR_FATHER_WITH_CHILD));
            } else if (null != motherPoint && me.hasMother()) {
                memberLines.add(new MemberLine(meStartX, meStartY, motherPoint.x + itemWidth / 2, motherPoint.y + itemHeight, LineType.MOTHER_OR_FATHER_WITH_CHILD));
            }

        }


    }

    /**
     * III  |  IV
     * -----------
     * II   |   I
     * <p>
     * Add family member for I & II
     *
     * @param part   family part
     * @param member member to be added and get family
     */
    private void addMembersTypeIAndII(Part part, Member member) {
        RealmResults<Member> children = member.getChildren();
        for (Member child : children) {
            child.setGeneration(member.getGeneration() + 1);
            addMembersTypeIAndII(part, child);
        }

        // check to add to stack and create view
        // If has not child
        if (children.isEmpty()) {
            int memberX = minX;
            int memberY = centerPoint.y + member.getGeneration() * itemHeightAndSpace;
            memberPointQueue.add(new Pair<>(member, new Point(memberX, memberY)));
            memberViewQueue.add(new Pair<>(member, createFamilyView(member)));
            minX += part.getValue() * itemWidthAndSpace;

            // draw spouse
            Member spouse = member.getSpouse();
            if (member.hasSpouse()) {
                spouse.setGeneration(member.getGeneration());

                int spouseX = memberX + itemWidthAndSpace;
                memberPointQueue.add(new Pair<>(spouse, new Point(spouseX, memberY)));
                memberViewQueue.add(new Pair<>(spouse, createFamilyView(spouse)));

                // Member to spouse
                // 0.5 for move line to center of item
                int lineY = (int) (memberY + 0.5 * itemHeight);
                memberLines.add(new MemberLine(memberX + itemWidth, lineY, spouseX, lineY, LineType.PARENT));
            }
        } else {
            // else, has children, calculate position
            int childMinX = 0, childMaxX = 0;
            int childY = 0;
            int index;
            Point lastMemberPoint = null;
            for (Member child : children) {
                if ((index = memberPointQueue.indexOf(child)) >= 0) {
                    Pair<Member, Point> pointTextViewPair = memberPointQueue.get(index);
                    childY = pointTextViewPair.second.y;
                    Point point = pointTextViewPair.second;
                    if (0 == childMinX || childMinX < point.x) {
                        childMinX = point.x;
                    }

                    if (0 == childMaxX || childMaxX > point.x) {
                        childMaxX = point.x;
                    }

                    // Draw line between child
                    if (null == lastMemberPoint) {
                        lastMemberPoint = pointTextViewPair.second;
                    } else {
                        Point memberPoint = pointTextViewPair.second;
                        // Draw between first and member
                        memberLines.add(new MemberLine(lastMemberPoint.x + itemWidth / 2, lastMemberPoint.y, memberPoint.x + itemWidth / 2, memberPoint.y, LineType.SIBLING));
                        lastMemberPoint = memberPoint;
                    }
                }
            }

            int childCenterX = (childMinX + childMaxX) / 2;
            int memberY;
            // Has spouse
            Member spouse = member.getSpouse();
            if (member.hasSpouse()) {
                spouse.setGeneration(member.getGeneration());
                int memberX = childCenterX - itemWidthAndSpace / 2;
                memberY = centerPoint.y + member.getGeneration() * itemHeightAndSpace;
                memberPointQueue.add(new Pair<>(member, new Point(memberX, memberY)));
                memberViewQueue.add(new Pair<>(member, createFamilyView(member)));

                int spouseX = childCenterX + itemWidthAndSpace / 2;
                memberPointQueue.add(new Pair<>(spouse, new Point(spouseX, memberY)));
                memberViewQueue.add(new Pair<>(spouse, createFamilyView(spouse)));

                // Member to spouse
                // 0.5 for move line to center of item
                int lineY = (int) (centerPoint.y + member.getGeneration() * itemHeightAndSpace + 0.5 * itemHeight);
                memberLines.add(new MemberLine(memberX + itemWidth, lineY, spouseX, lineY, LineType.PARENT));

                /*
                 * This case, member has child
                 * draw line from parent to line between children
                 */
                if (children.size() == 1) {
                    memberLines.add(new MemberLine(childCenterX + itemWidth / 2, memberY + itemHeight / 2, childCenterX + itemWidth / 2, childY, LineType.CHILD));
                } else {
                    memberLines.add(new MemberLine(childCenterX + itemWidth / 2, memberY + itemHeight / 2, childCenterX + itemWidth / 2, childY - mLineUpHigh, LineType.CHILD));
                }
            } else {
                memberY = centerPoint.y + member.getGeneration() * itemHeightAndSpace;
                memberPointQueue.add(new Pair<>(member, new Point((childMinX + childMaxX) / 2, memberY)));
                memberViewQueue.add(new Pair<>(member, createFamilyView(member)));

                /*
                 * This case, member has child
                 * draw line from parent to line between children
                 */
                if (children.size() == 1) {
                    memberLines.add(new MemberLine(childCenterX + itemWidth / 2, memberY + itemHeight, childCenterX + itemWidth / 2, childY, LineType.CHILD));
                } else {
                    memberLines.add(new MemberLine(childCenterX + itemWidth / 2, memberY + itemHeight, childCenterX + itemWidth / 2, childY - mLineUpHigh, LineType.CHILD));
                }
            }

        }
    }

    /**
     * III  |  IV
     * -----------
     * II   |   I
     * <p>
     * Add family member for  IV
     * For part IV:
     * - Draw mother family at left, from top-right to left for each level from top to bottom
     * - Draw father family at righ, from top-left to right for each level from top to bottom
     *
     * @param childType child type
     * @param member    member to be added and get family
     */
    private void addMembersTypeIV(ChildType childType, Member member) {
        // get sibling
        RealmResults<Member> sibling = member.getSibling();
        int siblingSize = sibling.size();
        int siblingAndMeSize = sibling.size() + 1;

        if (maxMeAndSibling < siblingAndMeSize && childType == ChildType.WOMAN) {
            maxMeAndSibling = siblingAndMeSize;
        }

        int motherX = -1;
        if (member.hasMother()) {
            Member mother = member.getMotherFamilyTreeId();
            mother.setGeneration(member.getGeneration() - 1);
            addMembersTypeIV(ChildType.WOMAN, mother);
            int motherIndex;
            if ((motherIndex = memberPointQueue.indexOf(mother)) >= 0) {
                motherX = memberPointQueue.get(motherIndex).second.x;
            }
        }

        int fatherX = -1;
        if (member.hasFather()) {
            maxMeAndSibling = 0;
            Member father = member.getFatherFamilyTreeId();
            father.setGeneration(member.getGeneration() - 1);
            addMembersTypeIV(ChildType.MAN, father);
            int fatherIndex;
            if ((fatherIndex = memberPointQueue.indexOf(father)) >= 0) {
                fatherX = memberPointQueue.get(fatherIndex).second.x;
            }
        }

        // Parent line
        if (member.hasMother() && member.hasFather()) {
            // -0.5 for move line to center of item
            int lineY = (int) (centerPoint.y + (member.getGeneration() - 1) * itemHeightAndSpace + 0.5 * itemHeight);
            memberLines.add(new MemberLine(motherX + itemWidth, lineY, fatherX, lineY, LineType.PARENT));
        }

        int memberX;
        if (member.hasMother() && member.hasFather()) {
            memberX = (fatherX + motherX) / 2;
        } else if (member.hasMother()) {
            memberX = motherX;
        } else if (member.hasFather()) {
            memberX = fatherX;
        } else {
            if (ChildType.WOMAN == childType) {
                memberX = minX + maxMeAndSibling * itemWidthAndSpace;
            } else {
                memberX = minX + itemWidthAndSpace;
            }
        }
        if (memberX > minX) {
            minX = memberX;
        }

        memberPointQueue.add(new Pair<>(member, new Point(memberX, centerPoint.y + member.getGeneration() * itemHeightAndSpace)));
        memberViewQueue.add(new Pair<>(member, createFamilyView(member)));

        // add child to parent bottom line
        if (member.hasMother() || member.hasFather()) {
            int x = memberX + itemWidth / 2;
            // from center of parent
            float xx = member.hasMother() && member.hasFather() ? 0.5f : 1;
            int parentBottom = (int) (centerPoint.y + (member.getGeneration() - 1) * itemHeightAndSpace + xx * itemHeight);
            // to top of member
            int meTop = centerPoint.y + member.getGeneration() * itemHeightAndSpace;
            memberLines.add(new MemberLine(x, parentBottom, x, meTop, LineType.CHILD));
        }

        // [START] Add parent sibling
        // add member to sibling line
        int startMemberLineX = memberX + itemWidth / 2;
        // to top of member
        int startMemberLineY = centerPoint.y + member.getGeneration() * itemHeightAndSpace;
        Point lastPoint = new Point(startMemberLineX, startMemberLineY);
        for (int i = 0; i < siblingSize; i++) {
            Member sbl = sibling.get(i);
            sbl.setGeneration(member.getGeneration());
            int sblX;
            if (ChildType.WOMAN == childType) {
                sblX = memberX - (i + 1) * itemWidthAndSpace;
            } else {
                // add 2 because before sibling is father
                sblX = memberX + (i + 1) * itemWidthAndSpace;
                minX = sblX;
            }
            memberPointQueue.add(new Pair<>(sbl, new Point(sblX, centerPoint.y + sbl.getGeneration() * itemHeightAndSpace)));
            memberViewQueue.add(new Pair<>(sbl, createFamilyView(sbl)));

            memberLines.add(new MemberLine(lastPoint.x, lastPoint.y, sblX + itemWidth / 2, lastPoint.y, LineType.SIBLING));
            lastPoint.x = sblX + itemWidth / 2;
        }
        // [END] Add parent sibling
    }

    /**
     * III  |  IV
     * -----------
     * II   |   I
     * <p>
     * Add family member for III
     * For part III:
     * - Draw father family at left, from top-right to left for each level from top to bottom
     * - Draw mother family at right, from top-left to right for each level from top to bottom
     *
     * @param childType child type
     * @param member    member to be added and get family
     */
    private void addMembersTypeIII(ChildType childType, Member member) {
        // get sibling
        RealmResults<Member> sibling = member.getSibling();
        int siblingSize = sibling.size();
        int siblingAndMeSize = sibling.size() + 1;

        if (maxMeAndSibling < siblingAndMeSize && childType == ChildType.MAN) {
            maxMeAndSibling = siblingAndMeSize;
        }

        int fatherX = -1;
        if (member.hasFather()) {
            Member father = member.getFatherFamilyTreeId();
            father.setGeneration(member.getGeneration() - 1);
            addMembersTypeIII(ChildType.MAN, father);
            int fatherIndex;
            if ((fatherIndex = memberPointQueue.indexOf(father)) >= 0) {
                fatherX = memberPointQueue.get(fatherIndex).second.x;
            }
        }
        int motherX = -1;
        if (member.hasMother()) {
            maxMeAndSibling = 0;
            Member mother = member.getMotherFamilyTreeId();
            mother.setGeneration(member.getGeneration() - 1);
            addMembersTypeIII(ChildType.WOMAN, mother);
            int motherIndex;
            if ((motherIndex = memberPointQueue.indexOf(mother)) >= 0) {
                motherX = memberPointQueue.get(motherIndex).second.x;
            }
        }

        // Parent line
        if (member.hasMother() && member.hasFather()) {
            // -0.5 for move line to center of item
            int lineY = (int) (centerPoint.y + (member.getGeneration() - 1) * itemHeightAndSpace + 0.5 * itemHeight);
            memberLines.add(new MemberLine(motherX + itemWidth, lineY, fatherX, lineY, LineType.PARENT));
        }

        int memberX;
        if (member.hasMother() && member.hasFather()) {
            memberX = (fatherX + motherX) / 2;
        } else if (member.hasMother()) {
            memberX = motherX;
        } else if (member.hasFather()) {
            memberX = fatherX;
        } else {
            if (ChildType.MAN == childType) {
                memberX = minX - maxMeAndSibling * itemWidthAndSpace;
            } else {
                memberX = minX - itemWidthAndSpace;
            }
        }
        if (memberX < minX) {
            minX = memberX;
        }

        memberPointQueue.add(new Pair<>(member, new Point(memberX, centerPoint.y + member.getGeneration() * itemHeightAndSpace)));
        memberViewQueue.add(new Pair<>(member, createFamilyView(member)));

        // add child to parent bottom line
        if (member.hasMother() || member.hasFather()) {
            int x = memberX + itemWidth / 2;
            // from center of parent
            float xx = member.hasMother() && member.hasFather() ? 0.5f : 1;
            int parentBottom = (int) (centerPoint.y + (member.getGeneration() - 1) * itemHeightAndSpace + xx * itemHeight);
            // to top of member
            int meTop = centerPoint.y + member.getGeneration() * itemHeightAndSpace;
            memberLines.add(new MemberLine(x, parentBottom, x, meTop, LineType.CHILD));
        }

        // [START] Add parent sibling
        // add member to sibling line
        int startMemberLineX = memberX + itemWidth / 2;
        // to top of member
        int startMemberLineY = centerPoint.y + member.getGeneration() * itemHeightAndSpace;
        Point lastPoint = new Point(startMemberLineX, startMemberLineY);
        for (int i = 0; i < siblingSize; i++) {
            Member sbl = sibling.get(i);
            sbl.setGeneration(member.getGeneration());
            int sblX;
            if (ChildType.MAN == childType) {
                sblX = memberX + (i + 1) * itemWidthAndSpace;
            } else {
                // add 2 because before sibling is father
                sblX = memberX - (i + 1) * itemWidthAndSpace;
                minX = sblX;
            }
            memberPointQueue.add(new Pair<>(sbl, new Point(sblX, centerPoint.y + sbl.getGeneration() * itemHeightAndSpace)));
            memberViewQueue.add(new Pair<>(sbl, createFamilyView(sbl)));

            memberLines.add(new MemberLine(lastPoint.x, lastPoint.y, sblX + itemWidth / 2, lastPoint.y, LineType.SIBLING));
            lastPoint.x = sblX + itemWidth / 2;
        }
        // [END] Add parent sibling
    }

    /**
     * Create member view
     *
     * @param family Member
     * @return Member's view
     */
    private View createFamilyView(final Member family) {
        View familyView = layoutInflater.inflate(R.layout.item_family_view, this, false);
        familyView.getLayoutParams().width = itemWidth;
        familyView.getLayoutParams().height = itemHeight;
        familyView.setTag(family);

        ImageView ivAvatar = familyView.findViewById(R.id.iv_avatar);
        ivAvatar.setImageResource(Utils.getImageResourceMember(getContext(), family));

        TextView tvCall = familyView.findViewById(R.id.tv_relation);
        tvCall.setText(family.getRelationshipIdWithYou().getName());


        ImageButton ibAdd = familyView.findViewById(R.id.ib_add);
        ibAdd.setVisibility(family.getRelationshipIdWithYou().canAddMember() ? VISIBLE : INVISIBLE);

        ImageView ivHAE = familyView.findViewById(R.id.selected_hae);
        ivHAE.setImageResource(family.isHAE() ? R.drawable.ic_hae_enable : R.drawable.ic_hae_disable);
        ivHAE.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mOnMemberActionListener != null) {
                    int newHae = Member.INT_TRUE_VALUE == family.getHaeFlag() ? Member.INT_FALSE_VALUE : Member.INT_TRUE_VALUE;
                    mOnMemberActionListener.onHAE(family.getId(), newHae);
                    ((ImageView)view).setImageResource(family.isHAE() ? R.drawable.ic_hae_enable : R.drawable.ic_hae_disable);
                }
            }
        });

        ImageView ivFT = familyView.findViewById(R.id.selected_ft);
        ivFT.setImageResource(family.isFT() ? R.drawable.ic_ft_enable : R.drawable.ic_ft_disable);
        ivFT.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mOnMemberActionListener != null) {
                    boolean newFT = !family.isFT();
                    mOnMemberActionListener.onFT(family.getId(), newFT);
                    ((ImageView)view).setImageResource(family.isFT() ? R.drawable.ic_ft_enable : R.drawable.ic_ft_disable);
                }
            }
        });

        // Remove button delete (x) on me
        if (this.me.equals(family)) {
            familyView.findViewById(R.id.ib_delete).setVisibility(GONE);
        }

        // listener
        ibAdd.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mOnMemberActionListener != null) {
                    mOnMemberActionListener.onAddMember(family);
                }
            }
        });

        familyView.findViewById(R.id.ib_delete).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mOnMemberActionListener != null) {
                    mOnMemberActionListener.onDeleteMember(family);
                }
            }
        });

        this.addView(familyView);
        return familyView;
    }

    private void setChildViewFrame(View childView, int left, int top, int width, int height) {
        childView.layout(left, top, left + width, top + height);
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        if (null == memberPointQueue) {
            return;
        }
        for (Pair<Member, Point> pair : memberPointQueue) {
            Point point = pair.second;

            View view = memberViewQueue.get(memberViewQueue.indexOf(pair.first)).second;
            setChildViewFrame(view, point.x, point.y, itemWidth, itemHeight);
        }
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        final int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            final View childView = getChildAt(i);
            childView.measure(mWidthMeasureSpec, mHeightMeasureSpec);
        }
        if (null != mItemRect) {
            int width = mItemRect.width();
            int height = mItemRect.height();
            setMeasuredDimension(width, height);
        } else {
            setMeasuredDimension(widthMeasureSpec, heightMeasureSpec);
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (null != memberLines) {
            for (MemberLine memberLine : memberLines) {
                canvas.drawPath(memberLine.getPath(), mPaint);
            }
        }
    }

    private class MemberLine {
        int startX;
        int startY;

        int endX;
        int endY;

        LineType type;


        MemberLine(int startX, int startY, int endX, int endY, LineType type) {
            this.startX = startX;
            this.startY = startY;
            this.endX = endX;
            this.endY = endY;
            this.type = type;
        }

        Path getPath() {
            Path path = new Path();
            switch (type) {
                case PARENT:
                    path.moveTo(startX, startY);
                    path.lineTo(endX, endY);
                    break;
                case CHILD:
                    path.moveTo(startX, startY);
                    path.lineTo(endX, endY);
                    break;
                case SIBLING:
                    path.moveTo(startX, startY);
                    path.lineTo(startX, startY - mLineUpHigh);
                    path.lineTo(endX, endY - mLineUpHigh);
                    path.lineTo(endX, endY);
                    break;
                case MOTHER_OR_FATHER_WITH_CHILD:
                    // Line start from child to parent
                    path.moveTo(startX, startY);
                    path.lineTo(startX, startY - mLineUpHigh);
                    path.lineTo(endX, startY - mLineUpHigh);
                    path.lineTo(endX, endY);
                    break;
                default:
                    path.moveTo(startX, startY);
                    path.lineTo(endX, endY);
                    break;
            }

            return path;
        }

        void translateBy(int left, int top) {
            startX -= left;
            startY -= top;
            endX -= left;
            endY -= top;
        }

        public String toString() {
            return "StartX: " + startX + " EndX: " + endX + "StartY: " + startY + " EndY: " + endY + " Type: " + type.name();
        }
    }

    private enum LineType {
        PARENT,
        SIBLING,
        CHILD,
        MOTHER_OR_FATHER_WITH_CHILD
    }

    public void setMemberList(RealmResults<Member> memberList) {
        this.memberList = memberList;
    }

    public void setOnFamilyTreeActionListener(OnFamilyTreeActionListener listener) {
        this.mOnMemberActionListener = listener;
    }

    public void setOnCalculateListener(OnCalculateListener onCalculateListener) {
        mOnCalculateListener = onCalculateListener;
    }
}
