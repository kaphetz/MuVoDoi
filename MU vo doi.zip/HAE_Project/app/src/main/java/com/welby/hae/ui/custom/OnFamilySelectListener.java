package com.welby.hae.ui.custom;


import com.welby.hae.data.db.model.Member;

/**
 * Created by Welby Dev on 10/9/2017.
 */

public interface OnFamilySelectListener {
    void onFamilySelect(Member member);
}
