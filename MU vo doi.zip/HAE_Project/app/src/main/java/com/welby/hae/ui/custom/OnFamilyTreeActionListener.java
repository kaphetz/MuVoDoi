package com.welby.hae.ui.custom;

import com.welby.hae.data.db.model.Member;

/**
 * Created by Welby Dev on 10/16/2017.
 */

public interface OnFamilyTreeActionListener {
    void onAddMember(Member member);
    void onDeleteMember(Member member);
    void onHAE(int id, int hae_flag);
    void onFT(int id, boolean family_test_flag);
}
