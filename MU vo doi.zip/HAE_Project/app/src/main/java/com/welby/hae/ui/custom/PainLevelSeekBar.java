package com.welby.hae.ui.custom;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.AppCompatSeekBar;
import android.util.AttributeSet;

import com.welby.hae.R;

/**
 * Created by WelbyDev.
 */

public class PainLevelSeekBar extends AppCompatSeekBar {
    private static final int DIVIDER_PADDING = 15;
    private static final int DEFAULT_LABEL_SIZE = -1;

    private Drawable thumb;
    private Paint textPaint;
    private Rect textBounds = new Rect();

    private int labelColor;
    private int labelSize;
    private boolean visibleThumb;
    private boolean visibleLabel;

    public PainLevelSeekBar(Context context) {
        super(context);
        textPaint = new Paint();
    }

    public PainLevelSeekBar(Context context, AttributeSet attrs) {
        super(context, attrs);

        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.PainLevelSeekBar);
        this.labelSize = typedArray.getDimensionPixelSize(R.styleable.PainLevelSeekBar_label_size, DEFAULT_LABEL_SIZE);
        this.labelColor = typedArray.getColor(R.styleable.PainLevelSeekBar_label_color, ContextCompat.getColor(context, R.color.sr_default_text));
        this.visibleLabel = typedArray.getBoolean(R.styleable.PainLevelSeekBar_visible_label, true);
        this.visibleThumb = typedArray.getBoolean(R.styleable.PainLevelSeekBar_visible_thumb, true);
        int padding = typedArray.getInteger(R.styleable.PainLevelSeekBar_padding, 0);
        typedArray.recycle();

        setBackground(null);
        setThumb(null);
        setProgressDrawable(ContextCompat.getDrawable(context, R.drawable.seekbar_pain_level_rounded));
        thumb = ContextCompat.getDrawable(context, R.drawable.ic_thumb);
        setPadding(thumb.getIntrinsicWidth() / 2, (int) (padding * getResources().getDisplayMetrics().scaledDensity)
                , thumb.getIntrinsicWidth() / 2, (int) (padding * getResources().getDisplayMetrics().scaledDensity));
        textPaint = new Paint();

    }

    public PainLevelSeekBar(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        textPaint = new Paint();
    }

    @Override
    protected synchronized void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (visibleLabel) {
            //config text
            textPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
            textPaint.setColor(labelColor);

            if (labelSize == DEFAULT_LABEL_SIZE) {
                labelSize = getHeight() - (getHeight() - getProgressDrawable().getBounds().height());
            }

            textPaint.setTextSize(labelSize / 2);

            float labelY = getHeight() - getProgressDrawable().getBounds().height() - (getHeight() - getProgressDrawable().getBounds().height()) / 2 - DIVIDER_PADDING;

            //draw min label
            textPaint.getTextBounds(String.valueOf(0), 0, String.valueOf(0).length(), textBounds);
            canvas.drawText(String.valueOf(0), getPaddingStart(), labelY, textPaint);

            //draw max label
            textPaint.getTextBounds(String.valueOf(10), 0, String.valueOf(10).length(), textBounds);
            canvas.drawText(String.valueOf(10), getWidth() - getPaddingEnd() - textBounds.width() * 3 / 2, labelY, textPaint);
        }

        //draw thumb
        if (visibleThumb) {
            float progressRight = getProgress() * 1f / getMax() * (getWidth() - getPaddingStart() - getPaddingEnd());

            float thumbLeft = progressRight;
            float thumbRight = progressRight + thumb.getIntrinsicWidth();
            float thumbTop = getProgressDrawable().getBounds().height() + (getHeight() - getProgressDrawable().getBounds().height()) / 2 + DIVIDER_PADDING;
            float thumbBottom = thumbTop + thumb.getIntrinsicHeight() + DIVIDER_PADDING;

            if (thumbLeft < 0) {
                thumbLeft = 0;
                thumbRight = thumbRight + thumb.getIntrinsicWidth() / 2;
            }

            if (thumbRight > getWidth()) {
                thumbLeft = getWidth() - thumb.getIntrinsicWidth();
                thumbRight = getWidth();
            }

            thumb.setBounds((int) thumbLeft, (int) thumbTop, (int) thumbRight, (int) thumbBottom);
            thumb.draw(canvas);
        }
    }
}
