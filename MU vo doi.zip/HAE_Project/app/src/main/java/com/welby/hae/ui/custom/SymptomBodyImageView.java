package com.welby.hae.ui.custom;

import android.content.Context;
import android.content.res.TypedArray;
import android.support.v7.widget.AppCompatImageView;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import com.welby.hae.R;

/**
 * Created by WelbyDev.
 */

public class SymptomBodyImageView extends AppCompatImageView {
    private int width;
    private int height;
    private float percentWidth;
    private float percentHeight;

    public SymptomBodyImageView(Context context) {
        super(context);
        init(context);
    }

    public SymptomBodyImageView(Context context, AttributeSet attrs) {
        super(context, attrs);

        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.SymptomBodyImageView);
        this.percentWidth = typedArray.getInt(R.styleable.SymptomBodyImageView_width_percent, 0) / 100f;
        this.percentHeight = typedArray.getInt(R.styleable.SymptomBodyImageView_height_percent, 0) / 100f;
        typedArray.recycle();

        init(context);
    }

    public SymptomBodyImageView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        setMeasuredDimension(width, height);
    }

    private void init(Context context) {
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics metrics = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(metrics);

        width = (int) (metrics.widthPixels * percentWidth);
        height = (int) (metrics.widthPixels * percentHeight * 26 / 15);
    }
}
