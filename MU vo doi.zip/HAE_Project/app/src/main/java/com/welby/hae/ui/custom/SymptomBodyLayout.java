package com.welby.hae.ui.custom;

import android.annotation.TargetApi;
import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.widget.FrameLayout;

/**
 * Created by WelbyDev.
 */

public class SymptomBodyLayout extends FrameLayout {

    public SymptomBodyLayout(Context context) {
        super(context);
    }

    public SymptomBodyLayout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public SymptomBodyLayout(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @TargetApi(21)
    public SymptomBodyLayout(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int width = getMeasuredWidth();
        int height = (int) (getMeasuredWidth() * 2600 * 1.0f / 1500);
        setMeasuredDimension(width, height);

    }
}
