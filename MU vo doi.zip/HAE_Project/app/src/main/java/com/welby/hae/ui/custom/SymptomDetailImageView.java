package com.welby.hae.ui.custom;

import android.content.Context;
import android.content.res.TypedArray;
import android.support.v7.widget.AppCompatImageView;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import com.welby.hae.R;

/**
 * Created by WelbyDev.
 */

public class SymptomDetailImageView extends AppCompatImageView {

    public SymptomDetailImageView(Context context) {
        super(context);
    }

    public SymptomDetailImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public SymptomDetailImageView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        setMeasuredDimension(getMeasuredWidth(), getMeasuredWidth() * 575 / 640);
    }
}
