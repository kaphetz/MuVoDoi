package com.welby.hae.ui.custom;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Point;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.welby.hae.R;
import com.welby.hae.utils.TextUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by WelbyDev.
 */

public class SymptomRecordShowCase extends FrameLayout {
    private static final int DEFAULT_PADDING = 18;
    private static final int DEFAULT_MARGIN = 72;
    private List<Item> itemList = new ArrayList<>();
    private int width;
    private int height;
    private ShowCaseListener listener;

    private FrameLayout layoutGuildClose;
    private FrameLayout layoutShowMore;

    public interface ShowCaseListener {
        void onClose();

        void onNext();
    }

    public SymptomRecordShowCase(Context context, int width, int height, List<Item> itemList) {
        super(context);
        this.width = width;
        this.height = height;
        this.itemList = itemList;
        init(context);
    }

    public SymptomRecordShowCase(Context context) {
        super(context);
        init(context);
    }

    public SymptomRecordShowCase(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public SymptomRecordShowCase(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    @TargetApi(21)
    public SymptomRecordShowCase(Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init(context);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        setMeasuredDimension(width, height);

    }

    private void init(Context context) {
        setBackgroundColor(ContextCompat.getColor(context, R.color.srg_background));

        int statusBarHeight = 0;
        int statusBarHeightResourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (statusBarHeightResourceId > 0) {
            statusBarHeight = getResources().getDimensionPixelSize(statusBarHeightResourceId);
        }
        int toolbarHeight = getResources().getDimensionPixelSize(R.dimen.sr_toolbar_height);

        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);

        DisplayMetrics metrics = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(metrics);

        for (Item item : itemList) {
            if (item.target != null) {
                TextView bubbleText = (TextView) LayoutInflater.from(context).inflate(R.layout.bubble_text, null);
                if (item.cursorLeft) {
                    bubbleText.setBackground(ContextCompat.getDrawable(context, R.drawable.bg_bubble_right));
                } else {
                    bubbleText.setBackground(ContextCompat.getDrawable(context, R.drawable.bg_bubble_left));
                }
                bubbleText.setText(TextUtil.fromHtml(item.text));
                bubbleText.measure(0, 0);
                LayoutParams params = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
                int[] locations = new int[2];
                item.target.getLocationOnScreen(locations);
                params.leftMargin = metrics.widthPixels / 2 - bubbleText.getMeasuredWidth() / 2;
                if (params.leftMargin < 0) {
                    params.leftMargin = DEFAULT_MARGIN;
                }
                params.topMargin = locations[1] - bubbleText.getMeasuredHeight() - statusBarHeight - DEFAULT_PADDING - toolbarHeight;
                addView(bubbleText, params);
            } else {
                TextView bubbleText = (TextView) LayoutInflater.from(context).inflate(R.layout.bubble_text, null);
                if (item.cursorLeft) {
                    bubbleText.setBackground(ContextCompat.getDrawable(context, R.drawable.bg_bubble_right));
                } else {
                    bubbleText.setBackground(ContextCompat.getDrawable(context, R.drawable.bg_bubble_left));
                }
                bubbleText.setText(TextUtil.fromHtml(item.text));
                bubbleText.measure(0, 0);
                LayoutParams params = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
                params.leftMargin = item.point.x - bubbleText.getWidth() / 2;
                params.topMargin = item.point.y - bubbleText.getHeight() - statusBarHeight - DEFAULT_PADDING - toolbarHeight;
                addView(bubbleText, params);
            }
        }
        showMoreButton(context);
    }

    public void showCloseButton(Context context) {
        layoutGuildClose = new FrameLayout(context);
        LayoutParams params = new LayoutParams(150, 150);
        params.leftMargin = DEFAULT_MARGIN;
        params.topMargin = DEFAULT_MARGIN;
        layoutGuildClose.layout(0, 0, 0, 0);
        layoutGuildClose.setLayoutParams(params);
        ImageView ivGuildClose = new ImageView(context);
        ivGuildClose.setImageResource(R.drawable.ic_guide_close);
        layoutGuildClose.addView(ivGuildClose);
        addView(layoutGuildClose);

        ivGuildClose.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                removeAllViews();
                if (getParent() != null) {
                    ((ViewGroup) getParent()).removeView(SymptomRecordShowCase.this);
                }
                if (listener != null) {
                    listener.onClose();
                }
            }
        });
    }

    public void showMoreButton(Context context) {
        int statusBarHeight = 0;
        int statusBarHeightResourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (statusBarHeightResourceId > 0) {
            statusBarHeight = getResources().getDimensionPixelSize(statusBarHeightResourceId);
        }
        int toolbarHeight = getResources().getDimensionPixelSize(R.dimen.sr_toolbar_height);

        layoutShowMore = new FrameLayout(context);
        LayoutParams params = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        layoutShowMore.layout(0, 0, 0, 0);
        layoutShowMore.setLayoutParams(params);
        ImageView ivShowMore = new ImageView(context);
        ivShowMore.setScaleType(ImageView.ScaleType.FIT_START);
        ivShowMore.setImageResource(R.drawable.ic_guide_more);
        layoutShowMore.addView(ivShowMore);

        layoutShowMore.measure(0, 0);

        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);

        DisplayMetrics metrics = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(metrics);

        params.leftMargin = (metrics.widthPixels - layoutShowMore.getMeasuredWidth()) / 2;
        params.topMargin = metrics.heightPixels - layoutShowMore.getMeasuredHeight() - statusBarHeight - DEFAULT_MARGIN - toolbarHeight;

        addView(layoutShowMore, params);

        ivShowMore.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (listener != null) {
                    listener.onNext();
                }
            }
        });
    }

    public void hideCloseButton() {
        if (layoutGuildClose != null) {
            removeView(layoutGuildClose);
        }
    }

    public void hideMoreButton() {
        if (layoutShowMore != null) {
            removeView(layoutShowMore);
        }
    }

    public void setShowCaseListener(ShowCaseListener listener) {
        this.listener = listener;
    }

    public static class Item {
        private String text;
        private View target;
        private boolean cursorLeft;
        private Point point;

        public Item(String text, View target) {
            this.text = text;
            this.target = target;
        }

        public Item(String text, Point point) {
            this.text = text;
            this.point = point;
        }

        public Item(String text, View target, boolean cursorLeft) {
            this.text = text;
            this.target = target;
            this.cursorLeft = cursorLeft;
        }

        public Item(String text, Point point, boolean cursorLeft) {
            this.text = text;
            this.point = point;
            this.cursorLeft = cursorLeft;
        }
    }
}
