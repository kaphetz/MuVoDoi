package com.welby.hae.ui.dialog;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.welby.hae.R;
import com.welby.hae.utils.Define;

/**
 * Created by WelbyDev.
 */

public class AppAlertDialog extends DialogFragment implements View.OnClickListener {
    private FragmentManager fragmentManager;

    private ImageView ivClose;
    private Button btnConfirm;
    private Button btnCancel;
    private TextView tvMessage;

    private String confirmText;
    private String cancelText;
    private String message;
    private boolean visibleCloseButton;
    private boolean visibleCancelButton;
    private boolean dismissOnClick;
    private boolean cancelable;
    private boolean isSaveImageDialog;
    private OnActionListener listener;

    public interface OnActionListener {
        void onConfirm();

        void onCancel();
    }

    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null && dialog.getWindow() != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            dialog.getWindow().setStatusBarColor(ContextCompat.getColor(getContext(), R.color.srg_status_bar));
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(isSaveImageDialog ? R.layout.dialog_save_image_alert : R.layout.dialog_app_alert, container, false);
        initView(view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initData();
    }

    private void initView(View view) {
        ivClose = view.findViewById(R.id.iv_close);
        btnConfirm = view.findViewById(R.id.btn_confirm);
        btnCancel = view.findViewById(R.id.btn_cancel);
        tvMessage = view.findViewById(R.id.tv_message);

        ivClose.setOnClickListener(this);
        btnConfirm.setOnClickListener(this);
        btnCancel.setOnClickListener(this);
        tvMessage.setOnClickListener(this);

        setCancelable(cancelable);
    }

    private void initData() {
        if (!TextUtils.isEmpty(message)) {
            tvMessage.setText(message);
        }

        if (!TextUtils.isEmpty(confirmText)) {
            btnConfirm.setText(confirmText);
        }

        if (!TextUtils.isEmpty(cancelText)) {
            btnCancel.setText(cancelText);
        }

        if (visibleCloseButton) {
            ivClose.setVisibility(View.VISIBLE);
        }

        if (visibleCancelButton) {
            btnCancel.setVisibility(View.VISIBLE);
        }
    }


    /**
     * just only display an instance of this dialog
     */
    public void show() {
        Fragment fragment = fragmentManager.findFragmentByTag(this.getClass().getName());
        if (fragment == null) {
            fragmentManager.beginTransaction().add(this, this.getClass().getName()).commitAllowingStateLoss();
        }
    }

    /**
     * remove fragment from fm when dismiss
     */
    @Override
    public void dismiss() {
        Fragment fragment = fragmentManager.findFragmentByTag(this.getClass().getName());
        if (fragment != null) {
            fragmentManager.beginTransaction().remove(fragment).commitAllowingStateLoss();
        }
        super.dismiss();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_confirm:
                if (listener != null) {
                    listener.onConfirm();
                }
                if (dismissOnClick) {
                    dismiss();
                }
                break;
            case R.id.iv_close:
                if (dismissOnClick) {
                    dismiss();
                }
                break;
            case R.id.btn_cancel:
                if (listener != null) {
                    listener.onCancel();
                }
                if (dismissOnClick) {
                    dismiss();
                }
                break;
            default:
                break;
        }
    }

    public static class Builder {
        private FragmentManager fragmentManager;
        private String message = Define.STR_EMPTY;
        private String confirmText = Define.STR_EMPTY;
        private String cancelText = Define.STR_EMPTY;
        private boolean visibleCloseButton;
        private boolean visibleCancelButton;
        private boolean dismissOnClick = true;
        private boolean cancelable;
        private boolean isSaveImageDialog;
        private OnActionListener listener;

        public Builder(FragmentManager fragmentManager) {
            this.fragmentManager = fragmentManager;
        }

        public Builder message(String message) {
            this.message = message;
            return this;
        }

        public Builder confirmText(String confirmText) {
            this.confirmText = confirmText;
            return this;
        }

        public Builder cancelText(String cancelText) {
            this.cancelText = cancelText;
            return this;
        }

        public Builder dismissOnClick(boolean dismissOnClick) {
            this.dismissOnClick = dismissOnClick;
            return this;
        }

        public Builder cancelable(boolean cancelable) {
            this.cancelable = cancelable;
            return this;
        }

        public Builder isSaveImageDialog(boolean isSaveImageDialog) {
            this.isSaveImageDialog = isSaveImageDialog;
            return this;
        }

        public Builder visibleCloseButton(boolean visibleCloseButton) {
            this.visibleCloseButton = visibleCloseButton;
            return this;
        }

        public Builder visibleCancelButton(boolean visibleCancelButton) {
            this.visibleCancelButton = visibleCancelButton;
            return this;
        }

        public Builder setOnActionListener(OnActionListener listener) {
            this.listener = listener;
            return this;
        }

        public AppAlertDialog build() {
            AppAlertDialog dialog = new AppAlertDialog();
            dialog.fragmentManager = this.fragmentManager;
            dialog.message = this.message;
            dialog.confirmText = this.confirmText;
            dialog.cancelText = this.cancelText;
            dialog.listener = this.listener;
            dialog.visibleCloseButton = this.visibleCloseButton;
            dialog.visibleCancelButton = this.visibleCancelButton;
            dialog.dismissOnClick = this.dismissOnClick;
            dialog.cancelable = this.cancelable;
            dialog.isSaveImageDialog = this.isSaveImageDialog;
            return dialog;
        }
    }
}
