package com.welby.hae.ui.dialog;

import android.app.Dialog;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TableRow;
import android.widget.TextView;

import com.welby.hae.R;
import com.welby.hae.adapter.SpinnerAdapter;
import com.welby.hae.data.db.Constants;
import com.welby.hae.data.db.model.Member;
import com.welby.hae.data.db.model.Relationship;

/**
 * Created by Welby Dev on 10/10/2017.
 * File name: DialogCreateFamilyTree
 */

public class DialogCreateFamilyTree extends DialogFragment implements AdapterView.OnItemSelectedListener, CompoundButton.OnCheckedChangeListener {
    private final String TAG = DialogCreateFamilyTree.class.getSimpleName();

    public static final String HAS_FATHER = "has_father";
    public static final String HAS_MOTHER = "has_mother";
    public static final String NUMBER_BOTHER = "number_bother";
    public static final String NUMBER_SISTER = "number_sister";
    public static final String NUMBER_SON = "number_son";
    public static final String NUMBER_DAUGHTER = "number_daughter";


    private static Member mMember;

    TextView tvTitle;
    TableRow trParent, trSibling, trChildren;
    CheckBox cbFather, cbMother;
    Spinner spNumberBrother, spNumberSister, spNumberSon, spNumberDaughter;
    SpinnerAdapter brotherAdapter, sisterAdapter, sonAdapter, daughterAdapter;
    Button btnConfirm;
    ImageButton btnClose;

    private boolean hasFather, hasMother;
    private int numberBrother, numberSister, numberSon, numberDaughter;
    private String title;


    public interface DialogCreateFamilyTreeListener {
        void onCreateData(Bundle data);
    }

    DialogCreateFamilyTreeListener listener;

    public DialogCreateFamilyTree() {
    }

    public static DialogCreateFamilyTree newInstance(Member Member) {
        DialogCreateFamilyTree dialogCreateFamilyTree = new DialogCreateFamilyTree();
        mMember = Member;
        return dialogCreateFamilyTree;
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.dialog_create_family_tree_member, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initView(view);
        setCancelable(false);

        if (mMember != null) {
            Log.d(TAG, "member: " + mMember.toString());
            Relationship relationship = mMember.getRelationshipIdWithYou();
            if (relationship != null) {
                switch (relationship.getClassCode()) {
                    case Constants.RELATION_GRAND_MOTHER:
                    case Constants.RELATION_MOTHER:
                        title = String.format(getString(R.string.select_from_member), getString(R.string.mother));
                        tvTitle.setText(title);
                        trChildren.setVisibility(View.GONE);
                        break;
                    case Constants.RELATION_GRAND_FATHER:
                    case Constants.RELATION_FATHER:
                        title = String.format(getString(R.string.select_from_member), getString(R.string.father));
                        tvTitle.setText(title);
                        trChildren.setVisibility(View.GONE);
                        break;

                    case Constants.RELATION_SISTER:
                        title = String.format(getString(R.string.select_from_member), getString(R.string.sister));
                        tvTitle.setText(title);
                        trParent.setVisibility(View.GONE);
                        trSibling.setVisibility(View.GONE);
                        break;
                    case Constants.RELATION_BROTHER:
                        title = String.format(getString(R.string.select_from_member), getString(R.string.brother));
                        tvTitle.setText(title);
                        trParent.setVisibility(View.GONE);
                        trSibling.setVisibility(View.GONE);
                        break;
                    case Constants.RELATION_NIECE:
                    case Constants.RELATION_DAUGHTER:
                        title = String.format(getString(R.string.select_from_member), getString(R.string.children));
                        tvTitle.setText(title);
                        trParent.setVisibility(View.GONE);
                        trSibling.setVisibility(View.GONE);
                        break;
                    case Constants.RELATION_NEPHEW:
                    case Constants.RELATION_SON:
                        title = String.format(getString(R.string.select_from_member), getString(R.string.children));
                        tvTitle.setText(title);
                        trParent.setVisibility(View.GONE);
                        trSibling.setVisibility(View.GONE);
                        break;

                }
            }

        }

        initData();

        handleEvent();

    }


    private void initView(View view) {
        tvTitle = view.findViewById(R.id.tv_title);
        trParent = view.findViewById(R.id.tr_parent);
        trSibling = view.findViewById(R.id.tr_sibling);
        trChildren = view.findViewById(R.id.tr_children);
        btnConfirm = view.findViewById(R.id.btn_confirm);
        btnClose = view.findViewById(R.id.btn_close);
        spNumberBrother = view.findViewById(R.id.sp_numberBrother);
        spNumberSister = view.findViewById(R.id.sp_numberSister);
        spNumberSon = view.findViewById(R.id.sp_numberSon);
        spNumberDaughter = view.findViewById(R.id.sp_numberDaughter);
        cbFather = view.findViewById(R.id.cb_father);
        cbMother = view.findViewById(R.id.cb_mother);

    }

    private void initData() {
        brotherAdapter = new SpinnerAdapter(getContext(), R.layout.spinner_item, getResources().getStringArray(R.array.number_people));
        sisterAdapter = new SpinnerAdapter(getContext(), R.layout.spinner_item, getResources().getStringArray(R.array.number_people));
        sonAdapter = new SpinnerAdapter(getContext(), R.layout.spinner_item, getResources().getStringArray(R.array.number_people));
        daughterAdapter = new SpinnerAdapter(getContext(), R.layout.spinner_item, getResources().getStringArray(R.array.number_people));

        spNumberBrother.setAdapter(brotherAdapter);
        spNumberBrother.setOnItemSelectedListener(this);

        spNumberSister.setAdapter(sisterAdapter);
        spNumberSister.setOnItemSelectedListener(this);

        spNumberSon.setAdapter(sonAdapter);
        spNumberSon.setOnItemSelectedListener(this);

        spNumberDaughter.setAdapter(daughterAdapter);
        spNumberDaughter.setOnItemSelectedListener(this);

        if (mMember != null) {
            // get father
            Member father = mMember.getFatherFamilyTreeId();
            if (father != null) {
                cbFather.setChecked(true);
                cbFather.setEnabled(false);
                cbFather.setButtonTintList(ColorStateList.valueOf(ContextCompat.getColor(getContext(), R.color.ft_disable)));
            } else {
                cbFather.setChecked(false);
            }
            // get mother
            Member mother = mMember.getMotherFamilyTreeId();
            if (mother != null) {
                cbMother.setChecked(true);
                cbMother.setEnabled(false);
                cbMother.setButtonTintList(ColorStateList.valueOf(ContextCompat.getColor(getContext(), R.color.ft_disable)));
            } else {
                cbMother.setChecked(false);
            }
           /* // get uncle
            List<Member> listUncle = MemberHelper.newInstance().getListMemberInRelationWithYou(mMember.getId(), Constants.RELATION_UNCLE);
            if (listUncle != null && listUncle.size() > 0) {
                spNumberBrother.setSelection(listUncle.size());
            } else {
                spNumberBrother.setSelection(0);
            }
            // get aunt
            List<Member> listAunt = MemberHelper.newInstance().getListMemberInRelationWithYou(mMember.getId(), Constants.RELATION_AUNT);
            if (listAunt != null && listAunt.size() > 0) {
                spNumberSister.setSelection(listAunt.size());
            } else {
                spNumberSister.setSelection(0);
            }

            // get nephew
            List<Member> listNephew = MemberHelper.newInstance().getListMemberInRelationWithYou(mMember.getId(), Constants.RELATION_NEPHEW);
            if (listNephew != null && listNephew.size() > 0) {
                spNumberSon.setSelection(listNephew.size());
            } else {
                spNumberSon.setSelection(0);
            }

            // get niece
            List<Member> listNiece = MemberHelper.newInstance().getListMemberInRelationWithYou(mMember.getId(), Constants.RELATION_NIECE);
            if (listNiece != null && listNiece.size() > 0) {
                spNumberDaughter.setSelection(listNiece.size());
            } else {
                spNumberDaughter.setSelection(0);
            }*/

        }
    }


    private void handleEvent() {


        cbFather.setOnCheckedChangeListener(this);
        cbMother.setOnCheckedChangeListener(this);

        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismiss();
            }
        });

        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

//                confirmData();
                if (null != listener) {
                    listener.onCreateData(confirmData());
                }
                dismiss();
            }
        });
    }

    private Bundle confirmData() {

        // Log

        Log.d(TAG, HAS_FATHER + " : " + hasFather);
        Log.d(TAG, HAS_MOTHER + " : " + hasMother);

        Log.d(TAG, NUMBER_BOTHER + " : " + numberBrother);
        Log.d(TAG, NUMBER_SISTER + " : " + numberSister);
        Log.d(TAG, NUMBER_SON + " : " + numberSon);
        Log.d(TAG, NUMBER_DAUGHTER + " : " + numberDaughter);


        Bundle data = new Bundle();
        data.putBoolean(HAS_FATHER, hasFather);
        data.putBoolean(HAS_MOTHER, hasMother);
        data.putInt(NUMBER_BOTHER, numberBrother);
        data.putInt(NUMBER_SISTER, numberSister);
        data.putInt(NUMBER_SON, numberSon);
        data.putInt(NUMBER_DAUGHTER, numberDaughter);
        return data;
    }

    @Override
    public void onStart() {
        super.onStart();

        Dialog dialog = getDialog();
        if (dialog != null) {
            int width = ViewGroup.LayoutParams.MATCH_PARENT;
            int height = ViewGroup.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        switch (adapterView.getId()) {
            case R.id.sp_numberBrother:
                numberBrother = Integer.parseInt(brotherAdapter.getItem(i));
                break;
            case R.id.sp_numberSister:
                numberSister = Integer.parseInt(sisterAdapter.getItem(i));
                break;
            case R.id.sp_numberSon:
                numberSon = Integer.parseInt(sonAdapter.getItem(i));
                break;
            case R.id.sp_numberDaughter:
                numberDaughter = Integer.parseInt(daughterAdapter.getItem(i));
                break;
            default:

                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
        switch (compoundButton.getId()) {
            case R.id.cb_father:
                if (b) {
                    hasFather = true;
                } else {
                    hasFather = false;
                }
                break;
            case R.id.cb_mother:
                if (b) {
                    hasMother = true;
                } else {
                    hasMother = false;
                }
                break;
            default:

                break;
        }
    }

    public void setListener(DialogCreateFamilyTreeListener listener) {
        this.listener = listener;
    }
}
