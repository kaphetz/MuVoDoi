package com.welby.hae.ui.dialog;

import android.app.Dialog;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.RadioGroup;
import android.widget.Spinner;

import com.welby.hae.R;
import com.welby.hae.adapter.SpinnerAdapter;
import com.welby.hae.data.db.Constants;
import com.welby.hae.data.db.helper.MemberHelper;
import com.welby.hae.data.db.model.Member;

/**
 * Created by Welby Dev on 10/6/2017.
 * File name: DialogCreateFamilyTreeFirst
 */

public class DialogCreateFamilyTreeFirst extends DialogFragment implements AdapterView.OnItemSelectedListener, CompoundButton.OnCheckedChangeListener {

    private final String TAG = DialogCreateFamilyTreeFirst.class.getSimpleName();

    public static final String GENDER = "gender";
    public static final String HAS_FATHER = "has_father";
    public static final String HAS_MOTHER = "has_mother";
    public static final String HAS_SPOUSE = "has_spouse";
    public static final String NUMBER_BOTHER = "number_bother";
    public static final String NUMBER_SISTER = "number_sister";
    public static final String NUMBER_SON = "number_son";
    public static final String NUMBER_DAUGHTER = "number_daughter";


    Button btnConfirm;
    ImageButton btnClose;
    Spinner spNumberBrother, spNumberSister, spNumberSon, spNumberDaughter;
    SpinnerAdapter brotherAdapter, sisterAdapter, sonAdapter, daughterAdapter;

    RadioGroup rgGender;
    CheckBox cbFather, cbMother, cbSpouse;


    private String mGender;
    private boolean hasFather, hasMother, hasSpouse;
    private int numberBrother, numberSister, numberSon, numberDaughter;
    private static Member mMember;


    public interface DialogCreateFamilyTreeFirstListener {
        void onCreateDataFirst(Bundle data);
    }

    private DialogCreateFamilyTreeFirstListener listener;

    public DialogCreateFamilyTreeFirst() {}

    public static DialogCreateFamilyTreeFirst newInstance(Member member) {
        DialogCreateFamilyTreeFirst dialogCreateFamilyTreeFirst = new DialogCreateFamilyTreeFirst();
        mMember = member;
        return dialogCreateFamilyTreeFirst;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.dialog_create_family_tree_first, container, false);
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initView(view);
        setCancelable(false);

        initData();

        handleEvent();
    }


    private void initView(View view) {
        btnConfirm = view.findViewById(R.id.btn_confirm);
        btnClose = view.findViewById(R.id.btn_close);
        spNumberBrother = view.findViewById(R.id.sp_numberBrother);
        spNumberSister = view.findViewById(R.id.sp_numberSister);
        spNumberSon = view.findViewById(R.id.sp_numberSon);
        spNumberDaughter = view.findViewById(R.id.sp_numberDaughter);
        rgGender = view.findViewById(R.id.rg_gender);
        cbFather = view.findViewById(R.id.cb_father);
        cbMother = view.findViewById(R.id.cb_mother);
        cbSpouse = view.findViewById(R.id.cb_spouse);

    }

    private void initData() {
        brotherAdapter = new SpinnerAdapter(getContext(), R.layout.spinner_item, getResources().getStringArray(R.array.number_people));
        sisterAdapter = new SpinnerAdapter(getContext(), R.layout.spinner_item, getResources().getStringArray(R.array.number_people));
        sonAdapter = new SpinnerAdapter(getContext(), R.layout.spinner_item, getResources().getStringArray(R.array.number_people));
        daughterAdapter = new SpinnerAdapter(getContext(), R.layout.spinner_item, getResources().getStringArray(R.array.number_people));

        spNumberBrother.setAdapter(brotherAdapter);
        spNumberBrother.setOnItemSelectedListener(this);

        spNumberSister.setAdapter(sisterAdapter);
        spNumberSister.setOnItemSelectedListener(this);

        spNumberSon.setAdapter(sonAdapter);
        spNumberSon.setOnItemSelectedListener(this);

        spNumberDaughter.setAdapter(daughterAdapter);
        spNumberDaughter.setOnItemSelectedListener(this);

        if (mMember != null) {

            if (mMember.isMan()) {
                rgGender.check(R.id.rb_male);
            } else {
                rgGender.check(R.id.rb_female);
            }

            Log.d(TAG, "member: " + mMember.toString());
            Member father = mMember.getFatherFamilyTreeId();
            if (father != null) {
                cbFather.setChecked(true);
                cbFather.setEnabled(false);
                cbFather.setButtonTintList(ColorStateList.valueOf(ContextCompat.getColor(getContext(), R.color.ft_disable)));
//                cbFather.s
            } else {
                cbFather.setChecked(false);
            }
            Member mother = mMember.getMotherFamilyTreeId();
            if (mother != null) {
                cbMother.setChecked(true);
                cbMother.setEnabled(false);
                cbMother.setButtonTintList(ColorStateList.valueOf(ContextCompat.getColor(getContext(), R.color.ft_disable)));
            } else {
                cbMother.setChecked(false);
            }

            Member spouse = MemberHelper.newInstance().getMemberInRelationWithYou(mMember.getId(), Constants.RELATION_SPOUSE);
            if (spouse != null) {
                cbSpouse.setChecked(true);
                cbSpouse.setEnabled(false);
                cbSpouse.setButtonTintList(ColorStateList.valueOf(ContextCompat.getColor(getContext(), R.color.ft_disable)));
            } else {
                cbSpouse.setChecked(false);
            }
           /* // get brother
            List<Member> brothers = MemberHelper.newInstance().getListMemberInRelationWithYou(mMember.getId(), Constants.RELATION_BROTHER);
            if (brothers != null && brothers.size() > 0) {
                spNumberBrother.setSelection(brothers.size());
            } else {
                spNumberBrother.setSelection(0);
            }
            // get sister
            List<Member> listSister = MemberHelper.newInstance().getListMemberInRelationWithYou(mMember.getId(), Constants.RELATION_SISTER);
            if (listSister != null && listSister.size() > 0) {
                spNumberSister.setSelection(listSister.size());
            } else {
                spNumberSister.setSelection(0);
            }

            // get nephew
            List<Member> listSon = MemberHelper.newInstance().getListMemberInRelationWithYou(mMember.getId(), Constants.RELATION_SON);
            if (listSon != null && listSon.size() > 0) {
                spNumberSon.setSelection(listSon.size());
            } else {
                spNumberSon.setSelection(0);
            }

            //get niece
            List<Member> listDaughter = MemberHelper.newInstance().getListMemberInRelationWithYou(mMember.getId(), Constants.RELATION_DAUGHTER);
            if (listDaughter != null && listDaughter.size() > 0) {
                spNumberDaughter.setSelection(listDaughter.size());
            } else {
                spNumberDaughter.setSelection(0);
            }*/

        }

    }

    private void handleEvent() {
        rgGender.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, @IdRes int i) {
                switch (i) {
                    case R.id.rb_male:
                        mGender = Constants.MAN;
                        break;
                    case R.id.rb_female:
                        mGender = Constants.WOMAN;
                        break;
                    default:
                        mGender = Constants.WOMAN;
                        break;
                }
            }
        });

        cbFather.setOnCheckedChangeListener(this);
        cbMother.setOnCheckedChangeListener(this);
        cbSpouse.setOnCheckedChangeListener(this);

        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismiss();
            }
        });

        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

//                confirmData();
                if (null != listener) {
                    listener.onCreateDataFirst(confirmData());
                }

                dismiss();
            }
        });
    }

    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
        switch (compoundButton.getId()) {
            case R.id.cb_father:
                hasFather = b;
                break;
            case R.id.cb_mother:
                hasMother = b;
                break;
            case R.id.cb_spouse:
                hasSpouse = b;
                break;
        }
    }


    @Override
    public void onStart() {
        super.onStart();

        Dialog dialog = getDialog();
        if (dialog != null) {
            int width = ViewGroup.LayoutParams.MATCH_PARENT;
            int height = ViewGroup.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        switch (adapterView.getId()) {
            case R.id.sp_numberBrother:
                numberBrother = Integer.parseInt(brotherAdapter.getItem(i));
                break;
            case R.id.sp_numberSister:
                numberSister = Integer.parseInt(sisterAdapter.getItem(i));
                break;
            case R.id.sp_numberSon:
                numberSon = Integer.parseInt(sonAdapter.getItem(i));
                break;
            case R.id.sp_numberDaughter:
                numberDaughter = Integer.parseInt(daughterAdapter.getItem(i));
                break;
            default:

                break;
        }
    }

    private Bundle confirmData() {

        /*// Log
        Log.d(TAG, GENDER + " : " + mGender);
        Log.d(TAG, HAS_FATHER + " : " + hasFather);
        Log.d(TAG, HAS_MOTHER + " : " + hasMother);
        Log.d(TAG, HAS_SPOUSE + " : " + hasSpouse);
        Log.d(TAG, NUMBER_BOTHER + " : " + numberBrother);
        Log.d(TAG, NUMBER_SISTER + " : " + numberSister);
        Log.d(TAG, NUMBER_SON + " : " + numberSon);
        Log.d(TAG, NUMBER_DAUGHTER + " : " + numberDaughter);*/


        Bundle data = new Bundle();
        data.putString(GENDER, mGender);
        data.putBoolean(HAS_FATHER, hasFather);
        data.putBoolean(HAS_MOTHER, hasMother);
        data.putBoolean(HAS_SPOUSE, hasSpouse);
        data.putInt(NUMBER_BOTHER, numberBrother);
        data.putInt(NUMBER_SISTER, numberSister);
        data.putInt(NUMBER_SON, numberSon);
        data.putInt(NUMBER_DAUGHTER, numberDaughter);
        return data;
    }


    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    public void setListener(DialogCreateFamilyTreeFirstListener listener) {
        this.listener = listener;
    }
}
