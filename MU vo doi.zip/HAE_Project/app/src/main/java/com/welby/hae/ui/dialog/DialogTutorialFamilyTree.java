package com.welby.hae.ui.dialog;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v4.content.ContextCompat;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.style.ImageSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.welby.hae.HAEApplication;
import com.welby.hae.R;

/**
 * Created by Welby Dev on 10/6/2017.
 * File name: DialogTutorialFamilyTree
 */

public class DialogTutorialFamilyTree extends DialogFragment {

    private TextView tvTutorial1, tvTutorial2, tvTutorialFT, tvTutorialHAE;
    private ImageButton btnClose;
    private Button btnConfirm;

    public DialogTutorialFamilyTree() {}


    public static DialogTutorialFamilyTree newInstance() {
        return new DialogTutorialFamilyTree();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.dialog_tutorial_family_tree, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initView(view);

        SpannableStringBuilder ssb = new SpannableStringBuilder(getResources().getString(R.string.ft_tutorial_1_1) + "   " +
        getResources().getString(R.string.ft_tutorial_1_2));
        Drawable dAdd = ContextCompat.getDrawable(getContext(), R.drawable.ic_add);
        dAdd.setBounds(0, 0, (int) (tvTutorial1.getLineHeight() * 0.8), (int) (tvTutorial1.getLineHeight() * 0.8));
        ImageSpan spanAdd = new ImageSpan(dAdd, ImageSpan.ALIGN_BASELINE);
        ssb.setSpan(spanAdd,16 , 17, Spannable.SPAN_INCLUSIVE_EXCLUSIVE);
        tvTutorial1.setText(ssb, TextView.BufferType.SPANNABLE);


        SpannableString ssFT = new SpannableString("  " + getResources().getString(R.string.ft_tutorial_ft));
        Drawable dFT = ContextCompat.getDrawable(getContext(), R.drawable.ic_ft);
        dFT.setBounds(0, 0, dFT.getIntrinsicWidth(), dFT.getIntrinsicHeight());
        ImageSpan spanFT = new ImageSpan(dFT, ImageSpan.ALIGN_BOTTOM);
        ssFT.setSpan(spanFT, 0, 1, Spannable.SPAN_INCLUSIVE_EXCLUSIVE);
        tvTutorialFT.setText(ssFT, TextView.BufferType.SPANNABLE);

        SpannableString ssHAE = new SpannableString("  " + getResources().getString(R.string.ft_tutorial_hae));
        Drawable dHAE = ContextCompat.getDrawable(getContext(), R.drawable.ic_hae);
        dHAE.setBounds(0, 0, dHAE.getIntrinsicWidth(), dHAE.getIntrinsicHeight());
        ImageSpan spanHAE = new ImageSpan(dHAE, ImageSpan.ALIGN_BOTTOM);
        ssHAE.setSpan(spanHAE, 0, 1, Spannable.SPAN_INCLUSIVE_EXCLUSIVE);
        tvTutorialHAE.setText(ssHAE, TextView.BufferType.SPANNABLE);

        SpannableStringBuilder ssb2 = new SpannableStringBuilder("  " + getResources().getString(R.string.ft_tutorial_2));
        ssb2.setSpan(spanAdd, 0, 1, Spannable.SPAN_INCLUSIVE_EXCLUSIVE);
        tvTutorial2.setText(ssb2, TextView.BufferType.SPANNABLE);

        getDialog().setCancelable(false);

        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getDialog().dismiss();
            }
        });

        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getDialog().dismiss();
            }
        });
    }

    private void initView(View view) {
        tvTutorial1 = view.findViewById(R.id.tv_tutorial_1);
        tvTutorial2 = view.findViewById(R.id.tv_tutorial_2);
        tvTutorialFT = view.findViewById(R.id.tv_tutorial_ft);
        tvTutorialHAE = view.findViewById(R.id.tv_tutorial_hae);
        btnClose = view.findViewById(R.id.btn_close);
        btnConfirm = view.findViewById(R.id.btn_confirm);
    }

    @Override
    public void onStart() {
        super.onStart();

        Dialog dialog = getDialog();
        if (dialog != null) {
            int width = ViewGroup.LayoutParams.MATCH_PARENT;
            int height = ViewGroup.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        HAEApplication.getInstance().trackScreenView(getString(R.string.screen_family_tree_tutorial));
    }
}
