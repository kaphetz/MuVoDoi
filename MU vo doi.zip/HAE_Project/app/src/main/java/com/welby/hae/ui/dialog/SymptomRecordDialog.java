package com.welby.hae.ui.dialog;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.welby.hae.R;
import com.welby.hae.adapter.SymptomItemListAdapter;
import com.welby.hae.model.SymptomItem;
import com.welby.hae.utils.Define;

import java.util.List;

/**
 * Created by WelbyDev.
 */

public class SymptomRecordDialog extends DialogFragment implements View.OnClickListener {
    private static final int SYMPTOM_LIST_COLUMN_COUNT = 2;

    private TextView tvPart;
    private ImageView ivPart;
    private RecyclerView rvSymptomList;
    private Button btnSave;

    private Context context;
    private FragmentManager fragmentManager;
    private String partTitle;
    private List<SymptomItem> symptomItemList;
    private int partOfBody;
    private OnActionListener listener;

    private boolean editable = true;
    private boolean dismissOnClick;
    private boolean cancelable;

    public interface OnActionListener {
        void onSave(List<SymptomItem> result);

        void onBack();
    }

    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null && dialog.getWindow() != null) {
            int width = ViewGroup.LayoutParams.MATCH_PARENT;
            int height = ViewGroup.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.dialog_symptom_record, container, false);
        initView(view);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initData();
    }

    private void initView(View view) {
        tvPart = view.findViewById(R.id.tv_part);
        ivPart = view.findViewById(R.id.iv_part);
        rvSymptomList = view.findViewById(R.id.rv_symptoms);
        btnSave = view.findViewById(R.id.btn_save);
        Button btnBack = view.findViewById(R.id.btn_back);

        btnSave.setOnClickListener(this);
        btnBack.setOnClickListener(this);
    }

    private void initData() {
        if (!TextUtils.isEmpty(partTitle)) {
            tvPart.setText(partTitle);
        }

        rvSymptomList.setLayoutManager(new GridLayoutManager(context, SYMPTOM_LIST_COLUMN_COUNT));
        SymptomItemListAdapter symptomItemListAdapter = new SymptomItemListAdapter(symptomItemList, editable);
        rvSymptomList.setAdapter(symptomItemListAdapter);

        setCancelable(cancelable);

        btnSave.setVisibility(editable ? View.VISIBLE : View.GONE);

        switch (partOfBody) {
            case Define.BodyPart.FACE:
                Glide.with(this).load(R.drawable.detail_face).into(ivPart);
                break;
            case Define.BodyPart.BODY:
                Glide.with(this).load(R.drawable.detail_body).into(ivPart);
                break;
            case Define.BodyPart.RIGHT_ARM:
                Glide.with(this).load(R.drawable.detail_right_arm).into(ivPart);
                break;
            case Define.BodyPart.LEFT_ARM:
                Glide.with(this).load(R.drawable.detail_left_arm).into(ivPart);
                break;
            case Define.BodyPart.RIGHT_FINGER:
                Glide.with(this).load(R.drawable.detail_right_finger).into(ivPart);
                break;
            case Define.BodyPart.LEFT_FINGER:
                Glide.with(this).load(R.drawable.detail_left_finger).into(ivPart);
                break;
            case Define.BodyPart.RIGHT_LEG:
                Glide.with(this).load(R.drawable.detail_right_leg).into(ivPart);
                break;
            case Define.BodyPart.LEFT_LEG:
                Glide.with(this).load(R.drawable.detail_left_leg).into(ivPart);
                break;
            case Define.BodyPart.RIGHT_TOE:
                Glide.with(this).load(R.drawable.detail_right_toe).into(ivPart);
                break;
            case Define.BodyPart.LEFT_TOE:
                Glide.with(this).load(R.drawable.detail_left_toe).into(ivPart);
                break;
            case Define.BodyPart.BODY_BACK:
                Glide.with(this).load(R.drawable.detail_body_back).into(ivPart);
                break;
            case Define.BodyPart.RIGHT_LEG_BACK:
                Glide.with(this).load(R.drawable.detail_back_right_leg).into(ivPart);
                break;
            case Define.BodyPart.LEFT_LEG_BACK:
                Glide.with(this).load(R.drawable.detail_back_left_leg).into(ivPart);
                break;
            default:
                break;
        }
    }

    /**
     * just only display an instance of this dialog
     */
    public void show() {
        Fragment fragment = fragmentManager.findFragmentByTag(this.getClass().getName());
        if (fragment == null) {
            fragmentManager.beginTransaction().add(this, this.getClass().getName()).commitAllowingStateLoss();
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_save:
                if (listener != null) {
                    listener.onSave(symptomItemList);
                }
                if (dismissOnClick) {
                    dismiss();
                }
                break;
            case R.id.btn_back:
                if (listener != null) {
                    listener.onBack();
                }
                if (dismissOnClick) {
                    dismiss();
                }
                break;
            default:
                break;
        }
    }

    public static class Builder {
        private Context context;
        private FragmentManager fragmentManager;
        private String partTitle = Define.STR_EMPTY;
        private List<SymptomItem> symptomItemList;
        private int partOfBody;

        private boolean editable = true;
        private boolean dismissOnClick = true;
        private boolean cancelable = false;
        private OnActionListener listener;

        public Builder(Context context, FragmentManager fragmentManager, List<SymptomItem> symptomItemList, int partOfBody) {
            this.context = context;
            this.fragmentManager = fragmentManager;
            this.symptomItemList = symptomItemList;
            this.partOfBody = partOfBody;
        }

        public Builder partTitle(String partTitle) {
            this.partTitle = partTitle;
            return this;
        }

        public Builder editable(boolean editable) {
            this.editable = editable;
            return this;
        }

        public Builder dismissOnClick(boolean dismissOnClick) {
            this.dismissOnClick = dismissOnClick;
            return this;
        }

        public Builder cancelable(boolean cancelable) {
            this.cancelable = cancelable;
            return this;
        }

        public Builder setOnActionListener(OnActionListener listener) {
            this.listener = listener;
            return this;
        }

        public SymptomRecordDialog build() {
            SymptomRecordDialog dialog = new SymptomRecordDialog();
            dialog.context = this.context;
            dialog.fragmentManager = this.fragmentManager;
            dialog.partTitle = this.partTitle;
            dialog.symptomItemList = this.symptomItemList;
            dialog.partOfBody = this.partOfBody;
            dialog.listener = this.listener;
            dialog.editable = this.editable;
            dialog.dismissOnClick = this.dismissOnClick;
            dialog.cancelable = this.cancelable;
            return dialog;
        }
    }
}
