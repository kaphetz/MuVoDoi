package com.welby.hae.ui.dialog;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.welby.hae.R;

/**
 * Created by WelbyDev.
 */

public class ViewPhotoDialog extends DialogFragment implements View.OnClickListener {

    private FragmentManager fragmentManager;
    private String imagePath;

    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog.getWindow() != null) {
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.dialog_view_photo, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        init(view);
    }

    private void init(View view) {
        ImageView ivClose = view.findViewById(R.id.iv_close);
        ImageView ivPhoto = view.findViewById(R.id.iv_photo);

        ivClose.setOnClickListener(this);

        Glide.with(getContext())
                .load(imagePath)
                .into(ivPhoto);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.iv_close) {
            dismiss();
        }
    }

    /**
     * just only display an instance of this dialog
     */
    public void show() {
        Fragment fragment = fragmentManager.findFragmentByTag(this.getClass().getName());
        if (fragment == null) {
            fragmentManager.beginTransaction().add(this, this.getClass().getName()).commitAllowingStateLoss();
        }
    }

    public static class Builder {
        private FragmentManager fragmentManager;
        private String imagePath;

        public Builder(FragmentManager fragmentManager, String imagePath) {
            this.fragmentManager = fragmentManager;
            this.imagePath = imagePath;
        }

        public ViewPhotoDialog build() {
            ViewPhotoDialog dialog = new ViewPhotoDialog();
            dialog.fragmentManager = this.fragmentManager;
            dialog.imagePath = this.imagePath;
            return dialog;
        }
    }
}
