package com.welby.hae.ui.familytree;

import android.os.Bundle;
import android.view.View;

import com.welby.hae.data.db.model.Member;

/**
 * Created by Welby Dev on 10/9/2017.
 */

public interface FamilyTreeAction {
    void initData();
    void loadData(Member focusMember);
    void addMemberToRealm(Member familyMember, Bundle data);
    void updateDataToRealm(Member member);
    void deleteDataInRealm(Member member);
    void updateHae(int id, int hae_flag);
    void updateFT(int id, boolean family_test_flag);
    void captureViewImage(View view);

}
