package com.welby.hae.ui.familytree;

import android.Manifest;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Point;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;

import com.welby.hae.HAEApplication;
import com.welby.hae.R;
import com.welby.hae.data.db.Constants;
import com.welby.hae.data.db.model.Member;
import com.welby.hae.ui.base.BaseFragment;
import com.welby.hae.ui.custom.HAEFamilyTreeView;
import com.welby.hae.ui.custom.OnFamilySelectListener;
import com.welby.hae.ui.custom.OnFamilyTreeActionListener;
import com.welby.hae.ui.custom.zoom_layout.ZoomEngine;
import com.welby.hae.ui.custom.zoom_layout.ZoomLayout;
import com.welby.hae.ui.dialog.AppAlertDialog;
import com.welby.hae.ui.dialog.DialogCreateFamilyTree;
import com.welby.hae.ui.dialog.DialogCreateFamilyTreeFirst;
import com.welby.hae.ui.dialog.DialogTutorialFamilyTree;
import com.welby.hae.utils.Define;

import io.realm.RealmResults;

public class FamilyTreeFragment extends Fragment implements FamilyTreeView, View.OnClickListener,
        OnFamilySelectListener, OnFamilyTreeActionListener, HAEFamilyTreeView.OnCalculateListener {

    private final String TAG = FamilyTreeFragment.class.getSimpleName();

    enum ZoomType {
        ZOOM_OUT(-1),
        ZOOM_IN(1),
        NONE(0);

        int value;

        ZoomType(int i) {
            value = i;
        }

        public int getValue() {
            return value;
        }
    }

    private static final int PERMISSION_CALLBACK_CONSTANT = 100;
    private ZoomLayout mZoomLayout;
    private HAEFamilyTreeView familyTreeView;
    private FamilyTreePresenter mPresenter;

    private String[] permissionsRequired = new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE};

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_family_tree, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mPresenter = new FamilyTreePresenter(getActivity(), this);
        initView(view);
        mPresenter.initData();
        mPresenter.loadData(null);
    }

    @Override
    public void onResume() {
        super.onResume();
        BaseFragment.setLastVisibleFragment(FamilyTreeFragment.class.getName());
        HAEApplication.getInstance().trackScreenView(getString(R.string.screen_family_tree));
    }

    /**
     * Initialize layout views
     *
     * @param rootView Root view
     */
    private void initView(View rootView) {
        familyTreeView = rootView.findViewById(R.id.family_tree_view);
        familyTreeView.setOnCalculateListener(this);

        ImageButton btnHelp = rootView.findViewById(R.id.btn_help);
        ImageButton btnZoomIn = rootView.findViewById(R.id.btn_zoomIn);
        ImageButton btnZoomOut = rootView.findViewById(R.id.btn_zoomOut);
        Button btnPrint = rootView.findViewById(R.id.btn_print);
        mZoomLayout = rootView.findViewById(R.id.zl_family_parent);

        btnZoomIn.setOnClickListener(this);
        btnZoomOut.setOnClickListener(this);
        btnHelp.setOnClickListener(this);
        btnPrint.setOnClickListener(this);
    }

    private boolean hasPermissions() {
        return ContextCompat.checkSelfPermission(getActivity(), permissionsRequired[0]) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        Log.d(TAG, "onRequestPermissionsResult");
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_CALLBACK_CONSTANT) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                captureFamilyTreeImages();
            } else {
                showPermissionsRequiredAlert(getString(R.string.pd_permission_denied)
                        + Define.STR_RETURN
                        + getString(R.string.pd_permission_storage));
            }
        }
    }

    @Override
    public void drawFamilyTreeView(RealmResults<Member> members, Member member, Member focusMember) {
        if (null != members && member != null) {
            familyTreeView.setMemberList(members);
            Member focusMB = new Member();
            focusMB.setId((focusMember == null ? member : focusMember).getId());
            familyTreeView.setCurrentMember(member, focusMember == null ? member : focusMember);
            familyTreeView.setOnFamilyTreeActionListener(this);
        }
    }

    @Override
    public void showTutorialFamilyTree() {
        FragmentManager fm = getFragmentManager();
        DialogTutorialFamilyTree dialogTutorialFamilyTree = DialogTutorialFamilyTree.newInstance();
        dialogTutorialFamilyTree.show(fm, "tutorial_family_tree");
    }

    @Override
    public void showDialogCreateFamilyTreeFirst(final Member member) {
        FragmentManager fm = getFragmentManager();
        DialogCreateFamilyTreeFirst dialogCreateFamilyTreeFirst = DialogCreateFamilyTreeFirst.newInstance(member);
        dialogCreateFamilyTreeFirst.setListener(new DialogCreateFamilyTreeFirst.DialogCreateFamilyTreeFirstListener() {
            @Override
            public void onCreateDataFirst(Bundle data) {
                if (data != null) {
                    mPresenter.addMemberToRealm(member, data);
                }
            }
        });
        dialogCreateFamilyTreeFirst.show(fm, "create_family_tree_first");
    }

    @Override
    public void showDialogCreateFamilyTree(final Member member) {
        FragmentManager fm = getFragmentManager();
        DialogCreateFamilyTree dialogCreateFamilyTree = DialogCreateFamilyTree.newInstance(member);
        dialogCreateFamilyTree.setListener(new DialogCreateFamilyTree.DialogCreateFamilyTreeListener() {
            @Override
            public void onCreateData(Bundle data) {
                if (data != null) {
                    mPresenter.addMemberToRealm(member, data);
                }
            }
        });
        dialogCreateFamilyTree.show(fm, "create_family_tree");
    }

    @Override
    public void showDialogSaveImageSuccess() {
        new AppAlertDialog.Builder(getChildFragmentManager())
                .message(getString(R.string.save_image_success_message))
                .visibleCloseButton(true)
                .isSaveImageDialog(true)
                .build()
                .show();
    }

    @Override
    public void showDialogSaveImageFail() {
        new AppAlertDialog.Builder(getChildFragmentManager())
                .message(getString(R.string.save_image_fail_message))
                .visibleCloseButton(true)
                .isSaveImageDialog(true)
                .build()
                .show();
    }

    @Override
    public void showPermissionsRequiredAlert(String message) {
        new AlertDialog.Builder(getActivity(), R.style.PermissionAlertDialogStyle)
                .setMessage(message)
                .setNegativeButton(R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                })
                .setCancelable(false)
                .create()
                .show();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_zoomOut: {
                zoom(ZoomType.ZOOM_OUT);
            }
            break;
            case R.id.btn_zoomIn: {
                zoom(ZoomType.ZOOM_IN);
            }
            break;
            case R.id.btn_help:
                HAEApplication.getInstance().trackEvent(getString(R.string.event_label_tutorial_family_tree));
                showTutorialFamilyTree();
                break;
            case R.id.btn_print:
                HAEApplication.getInstance().trackEvent(getString(R.string.event_label_save_family_tree));
                if (hasPermissions()) {
                    captureFamilyTreeImages();
                } else {
                    requestPermissions(permissionsRequired, PERMISSION_CALLBACK_CONSTANT);
                }
                break;
        }
    }

    @Override
    public void onFamilySelect(Member member) {
        if (member != null) {
            if (member.getRelationshipIdWithYou().getClassCode().equals(Constants.RELATION_YOU)) {
                showDialogCreateFamilyTreeFirst(member);
            } else {
                showDialogCreateFamilyTree(member);
            }
        }
    }

    public void captureFamilyTreeImages() {
        mPresenter.captureViewImage(familyTreeView);
    }

    @Override
    public void onAddMember(Member member) {
        if (member != null) {
            if (member.getRelationshipIdWithYou().getClassCode().equals(Constants.RELATION_YOU)) {
                showDialogCreateFamilyTreeFirst(member);
            } else {
                showDialogCreateFamilyTree(member);
            }
        }
        // mPresenter.updateDataToRealm(member);
    }

    @Override
    public void onDeleteMember(final Member member) {
        Log.d(TAG, "onDeleteMember");
        if (member != null) {
            Log.d(TAG, "member_select_delete: " + member.toString());

            new AppAlertDialog.Builder(getChildFragmentManager())
                    .message(getString(R.string.alert_delete_member))
                    .visibleCloseButton(true)
                    .setOnActionListener(new AppAlertDialog.OnActionListener() {
                        @Override
                        public void onConfirm() {
                            mPresenter.deleteDataInRealm(member);
                        }

                        @Override
                        public void onCancel() {

                        }
                    })
                    .build()
                    .show();
        }
    }

    @Override
    public void onHAE(int id, int hae_flag) {
        Log.d(TAG, "onHAE");
        mPresenter.updateHae(id, hae_flag);
    }

    @Override
    public void onFT(int id, boolean family_test_flag) {
        mPresenter.updateFT(id, family_test_flag);
    }

    /**
     * Default min zoom
     **/
    private static final float MIN_ZOOM = 0.5f;
    /**
     * Default max zoom
     **/
    private static final float MAX_ZOOM = 3f;
    /**
     * Default zoom
     **/
    private static final float DEFAULT_ZOOM = 1f;
    /**
     * Default zoom step
     **/
    private static final float DEFAULT_ZOOM_STEP = 0.25f;
    /**
     * Current ratio refer @onCalculatedViewSize
     **/
    float ratio = 1;

    /**
     * To be called when @{@link HAEFamilyTreeView} calculated view size in @{@link HAEFamilyTreeView}
     *
     * @param ratio      Ration between content width / Screen width
     * @param focusPoint Point to focus on
     */
    public void onCalculatedViewSize(final float ratio, final Point focusPoint) {
        this.ratio = ratio;

        final ZoomEngine engine = mZoomLayout.getEngine();
        float lastZoom = engine.getZoom();
        float lastMinZoom = engine.getMinZoom();
        float newMaxZoom = MAX_ZOOM * ratio;
        final float newMinZoom = MIN_ZOOM * ratio;
        engine.setMaxZoom(newMaxZoom, ZoomEngine.TYPE_ZOOM);
        engine.setMinZoom(newMinZoom, ZoomEngine.TYPE_ZOOM);

        final float zoomPerDefault = lastZoom / lastMinZoom;

        mZoomLayout.postDelayed(new Runnable() {
            @Override
            public void run() {
                float zoom = newMinZoom * zoomPerDefault * DEFAULT_ZOOM;
                float zoomLayoutWidth = mZoomLayout.getWidth();
                float zoomLayoutHeight = mZoomLayout.getHeight();

                float panX = focusPoint.x - ratio / zoom * (zoomLayoutWidth / 2);
                float panY = focusPoint.y - ratio / zoom * (zoomLayoutHeight / 2);

                engine.moveTo(zoom, -panX, -panY, true);
            }
        }, 50);
    }

    /**
     * Do zoom family tree by type
     *
     * @param zoomType Zoom type @{@link ZoomType}
     */
    private void zoom(ZoomType zoomType) {
        final ZoomEngine engine = mZoomLayout.getEngine();
        final float newMinZoom = MIN_ZOOM * ratio;
        float lastZoom = engine.getZoom();
        float lastMinZoom = engine.getMinZoom();
        final float zoomPerDefault = lastZoom / lastMinZoom;
        engine.zoomTo(newMinZoom * zoomPerDefault + zoomType.value * DEFAULT_ZOOM_STEP * ratio, true);
    }
}
