package com.welby.hae.ui.familytree;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.welby.hae.HAEApplication;
import com.welby.hae.R;
import com.welby.hae.data.db.Constants;
import com.welby.hae.data.db.helper.MemberHelper;
import com.welby.hae.data.db.helper.RealmManager;
import com.welby.hae.data.db.model.Member;
import com.welby.hae.data.db.model.Relationship;
import com.welby.hae.ui.dialog.DialogCreateFamilyTreeFirst;
import com.welby.hae.utils.Define;
import com.welby.hae.utils.Prefs;
import com.welby.hae.utils.SaveImageAsyncTask;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import io.realm.Realm;
import io.realm.RealmResults;

/**
 * Family Tree Presenter
 * Created by Welby Dev on 10/9/2017.
 */

class FamilyTreePresenter implements FamilyTreeAction, SaveImageAsyncTask.OnSaveImageListener {
    private final String TAG = "FamilyTreePresenter";

    private Realm mRealm;
    private Context mContext;
    private FamilyTreeView mFamilyTreeView;

    private List<Member> listMember = new ArrayList<>();
    private Member fatherMember = null;
    private Member motherMember = null;
    private Member spouseMember = null;
    private int id = 0;
    private Member memberAdd;


    FamilyTreePresenter(Context context, FamilyTreeView familyTreeView) {
        mRealm = RealmManager.getRealmManager().getRealm();
        mContext = context;
        mFamilyTreeView = familyTreeView;
    }


    // when user the first use app
    @Override
    public void initData() {
        if (!Prefs.with(mContext).getPreLoad()) {
            HAEApplication.getInstance().trackEvent(mContext.getString(R.string.event_label_family_tree_start));
            mFamilyTreeView.showTutorialFamilyTree();
            MemberHelper.newInstance().clearAllMember();
            id = MemberHelper.newInstance().getNextMemberId();
            Relationship relationship_you = MemberHelper.newInstance().getRelationshipByClassCode(Constants.RELATION_YOU);
            final Member member1 = new Member(id, 0, false, false, relationship_you, relationship_you, null, null, null, Constants.WOMAN, new Date(System.currentTimeMillis()), null);
            mRealm.executeTransaction(new Realm.Transaction() {
                @Override
                public void execute(@NonNull Realm realm) {
                    realm.copyToRealm(member1);
                }
            });

            Prefs.with(mContext).setPreLoad(true);
        }
    }

    @Override
    public void loadData(Member focusMember) {
        RealmResults<Member> members = MemberHelper.newInstance().getAllMember();
        Member member = MemberHelper.newInstance().getDataFamilyTree();

        if (null == focusMember) {
            focusMember = member;
        }

        mFamilyTreeView.drawFamilyTreeView(members, member, focusMember);
    }

    @Override
    public void addMemberToRealm(final Member member, Bundle data) {
        Log.d(TAG, "addMemberToRealm");
        if (member != null && data != null) {
            String gender = data.getString(DialogCreateFamilyTreeFirst.GENDER);
            boolean hasFather = data.getBoolean(DialogCreateFamilyTreeFirst.HAS_FATHER);
            boolean hasMother = data.getBoolean(DialogCreateFamilyTreeFirst.HAS_MOTHER);
            boolean hasSpouse = data.getBoolean(DialogCreateFamilyTreeFirst.HAS_SPOUSE);
            int numberBrother = data.getInt(DialogCreateFamilyTreeFirst.NUMBER_BOTHER);
            int numberSister = data.getInt(DialogCreateFamilyTreeFirst.NUMBER_SISTER);
            int numberSon = data.getInt(DialogCreateFamilyTreeFirst.NUMBER_SON);
            int numberDaughter = data.getInt(DialogCreateFamilyTreeFirst.NUMBER_DAUGHTER);


            Log.d(TAG, DialogCreateFamilyTreeFirst.GENDER + " : " + gender);
            Log.d(TAG, DialogCreateFamilyTreeFirst.HAS_FATHER + " : " + hasFather);
            Log.d(TAG, DialogCreateFamilyTreeFirst.HAS_MOTHER + " : " + hasMother);
            Log.d(TAG, DialogCreateFamilyTreeFirst.HAS_SPOUSE + " : " + hasSpouse);
            Log.d(TAG, DialogCreateFamilyTreeFirst.NUMBER_BOTHER + " : " + numberBrother);
            Log.d(TAG, DialogCreateFamilyTreeFirst.NUMBER_SISTER + " : " + numberSister);
            Log.d(TAG, DialogCreateFamilyTreeFirst.NUMBER_SON + " : " + numberSon);
            Log.d(TAG, DialogCreateFamilyTreeFirst.NUMBER_DAUGHTER + " : " + numberDaughter);

            Log.d(TAG, "member: " + member.toString());

            Relationship relationship = member.getRelationshipIdWithYou();
            id = MemberHelper.newInstance().getNextMemberId();
            Log.d(TAG, "id: " + id);

            listMember = new ArrayList<>();
            List<Member> listSister = null;
            List<Member> listSon = null;
            List<Member> listDaughter = null;
            List<Member> listBrother = null;
            fatherMember = null;
            motherMember = null;
            spouseMember = null;

            memberAdd = MemberHelper.newInstance().getMemberById(member.getId());
            Relationship relationship_father = MemberHelper.newInstance().getRelationshipByClassCode(Constants.RELATION_FATHER);
            Relationship relationship_mother = MemberHelper.newInstance().getRelationshipByClassCode(Constants.RELATION_MOTHER);
            Relationship relationship_brother = MemberHelper.newInstance().getRelationshipByClassCode(Constants.RELATION_BROTHER);
            Relationship relationship_sister = MemberHelper.newInstance().getRelationshipByClassCode(Constants.RELATION_SISTER);
            Relationship relationship_son = MemberHelper.newInstance().getRelationshipByClassCode(Constants.RELATION_SON);
            Relationship relationship_daughter = MemberHelper.newInstance().getRelationshipByClassCode(Constants.RELATION_DAUGHTER);
            Relationship relationship_nephew = MemberHelper.newInstance().getRelationshipByClassCode(Constants.RELATION_NEPHEW);
            Relationship relationship_niece = MemberHelper.newInstance().getRelationshipByClassCode(Constants.RELATION_NIECE);
            Relationship relationship_grand_father = MemberHelper.newInstance().getRelationshipByClassCode(Constants.RELATION_GRAND_FATHER);
            Relationship relationship_grand_mother = MemberHelper.newInstance().getRelationshipByClassCode(Constants.RELATION_GRAND_MOTHER);
            Relationship relationship_grand_child = MemberHelper.newInstance().getRelationshipByClassCode(Constants.RELATION_GRAND_CHILD);


            switch (relationship.getClassCode()) {

                // the first create
                case Constants.RELATION_YOU:
                    MemberHelper.newInstance().updateYouWhenChangeGender(gender);
                    if (hasFather) {
                        createMemberFather(member, relationship_father, relationship_father);
                        MemberHelper.newInstance().updateParentForMemberWhenAdd(member, fatherMember, Constants.RELATION_BROTHER, Constants.RELATION_SISTER);
                        Log.d(TAG, "father_member: " + fatherMember.toString());
                    } else {
                        fatherMember = member.getFatherFamilyTreeId();
                    }

                    if (hasMother) {
                        createMemberMother(member, relationship_mother, relationship_mother);
                        MemberHelper.newInstance().updateParentForMemberWhenAdd(member, motherMember, Constants.RELATION_BROTHER, Constants.RELATION_SISTER);
                        Log.d(TAG, "mother_member: " + motherMember.toString());
                    } else {
                        motherMember = member.getMotherFamilyTreeId();
                    }

                    if (hasSpouse) {
                        Relationship relationship_spouse = MemberHelper.newInstance().getRelationshipByClassCode(Constants.RELATION_SPOUSE);
                        createMemberSpouse(member, relationship_spouse, relationship_spouse, member.getGenderCode());
                        Log.d(TAG, "spouse_member: " + spouseMember.toString());
                        MemberHelper.newInstance().updateParentForMemberWhenAdd(member, spouseMember, Constants.RELATION_SON, Constants.RELATION_DAUGHTER);
                    } else {
                        spouseMember = MemberHelper.newInstance().getMemberInRelationWithYou(member.getId(), Constants.RELATION_SPOUSE);
                    }

                    listBrother = createListMemberBrother(numberBrother, member, relationship_brother, relationship_brother);
                    listSister = createListMemberSister(numberSister, member, relationship_sister, relationship_sister);
                    listSon = createListMemberSon(numberSon, member, relationship_son, relationship_son, member.getGenderCode());
                    listDaughter = createListMemberDaughter(numberDaughter, member, relationship_daughter, relationship_daughter, member.getGenderCode());

                    break;
                case Constants.RELATION_MOTHER:
                case Constants.RELATION_FATHER:
                case Constants.RELATION_GRAND_MOTHER:
                case Constants.RELATION_GRAND_FATHER:

                    if (hasFather) {
                        createMemberFather(member, relationship_grand_father, relationship_father);
                        MemberHelper.newInstance().updateParentForMemberWhenAdd(member, fatherMember, Constants.RELATION_BROTHER, Constants.RELATION_SISTER);
                        Log.d(TAG, "father_member: " + fatherMember.toString());
                    } else {
                        fatherMember = member.getFatherFamilyTreeId();
                    }

                    if (hasMother) {
                        createMemberMother(member, relationship_grand_mother, relationship_mother);
                        MemberHelper.newInstance().updateParentForMemberWhenAdd(member, motherMember, Constants.RELATION_BROTHER, Constants.RELATION_SISTER);
                        Log.d(TAG, "mother_member: " + motherMember.toString());
                    } else {
                        motherMember = member.getMotherFamilyTreeId();
                    }

                    Relationship relationship_uncle = MemberHelper.newInstance().getRelationshipByClassCode(Constants.RELATION_UNCLE);
                    listBrother = createListMemberBrother(numberBrother, member, relationship_uncle, relationship_brother);

                    Relationship relationship_aunt = MemberHelper.newInstance().getRelationshipByClassCode(Constants.RELATION_AUNT);
                    listSister = createListMemberSister(numberSister, member, relationship_aunt, relationship_sister);

                    // Not add brother and sister of user.

                    break;

                case Constants.RELATION_SISTER:
                case Constants.RELATION_BROTHER:

                    listSon = createListMemberSon(numberSon, member, relationship_nephew, relationship_son, member.getGenderCode());

                    listDaughter = createListMemberDaughter(numberDaughter, member, relationship_niece, relationship_daughter, member.getGenderCode());

                    break;
                case Constants.RELATION_NEPHEW:
                case Constants.RELATION_NIECE:
                case Constants.RELATION_DAUGHTER:
                case Constants.RELATION_SON:


                    listSon = createListMemberSon(numberSon, member, relationship_grand_child, relationship_son, member.getGenderCode());

                    listDaughter = createListMemberDaughter(numberDaughter, member, relationship_grand_child, relationship_daughter, member.getGenderCode());
                    break;

                default:
                    Toast.makeText(mContext, "Member can't create family tree.", Toast.LENGTH_SHORT).show();
                    break;

            }

            // Add to List member

            if (listBrother != null && listBrother.size() > 0) {
                listMember.addAll(listBrother);
            }
            if (listSister != null && listSister.size() > 0) {
                listMember.addAll(listSister);
            }
            if (listSon != null && listSon.size() > 0) {
                listMember.addAll(listSon);
            }
            if (listDaughter != null && listDaughter.size() > 0) {
                listMember.addAll(listDaughter);
            }

            // Add to Realm
            if (listMember != null && listMember.size() > 0) {
                for (Member member1 : listMember) {
                    Log.d(TAG, "member_add: " + member1.toString());
                }
                mRealm.executeTransaction(new Realm.Transaction() {
                    @Override
                    public void execute(@NonNull Realm realm) {
                        for (Member familyMember : listMember) {
                            mRealm.copyToRealmOrUpdate(familyMember);
                        }
                    }
                });

            }
            // redraw view.
            loadData(member);
        } else {
            Log.e(TAG, "Not have data");
        }
    }

    @Override
    public void updateDataToRealm(Member member) {
        MemberHelper.newInstance().updateMember(member);
    }

    @Override
    public void deleteDataInRealm(Member member) {
        Log.d(TAG, "deleteDataInRealm");
        if (member != null) {
            Member focusMember = member.getCreaterFamilyTreeId();

            MemberHelper.newInstance().updateParentForMemberWhenDelete(member);
            MemberHelper.newInstance().deleteMemberByCreatorId(member);

            // re-draw view.
            loadData(focusMember);
        }
    }

    @Override
    public void updateHae(int id, int haeFlag) {
        MemberHelper.newInstance().updateHAEOfMember(id, haeFlag);
    }

    @Override
    public void updateFT(int id, boolean familyTestFlag) {
        MemberHelper.newInstance().updateFTOfMember(id, familyTestFlag);
    }

    @Override
    public void captureViewImage(final View view) {
        Log.d(TAG, "printImages");
        //Define a bitmap with the same size as the view
        final Bitmap returnedBitmap = Bitmap.createBitmap((int) Define.SaveImageSize.WIDTH, (int) Define.SaveImageSize.HEIGHT, Bitmap.Config.ARGB_8888);
        //Bind a canvas to it
        Canvas canvas = new Canvas(returnedBitmap);
        canvas.scale(Define.SaveImageSize.WIDTH / (float) view.getWidth(), Define.SaveImageSize.WIDTH / (float) view.getWidth());
        //Get the view's background
        Drawable bgDrawable = view.getBackground();
        if (bgDrawable != null) {
            //has background drawable, then draw it on the canvas
            bgDrawable.draw(canvas);
        } else {
            //does not have background drawable, then draw white background on the canvas
            canvas.drawColor(Color.WHITE);
        }
        // draw the view on the canvas
        view.draw(canvas);
        new SaveImageAsyncTask(this).execute(returnedBitmap);

    }

    private void createMemberFather(final Member createrFamilyTreeId, final Relationship relationshipIdWithYou, final Relationship relationshipIdWithCreater) {
        mRealm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(@NonNull Realm realm) {
                final Member father = realm.createObject(Member.class, ++id);
                father.setHaeFlag(0);
                father.setSynchronizeFlag(false);
                father.setFamilyTestFlag(false);
                father.setRelationshipIdWithYou(relationshipIdWithYou);
                father.setRelationshipIdWithCreater(relationshipIdWithCreater);
                father.setCreaterFamilyTreeId(createrFamilyTreeId);
                father.setFatherFamilyTreeId(null);
                father.setMotherFamilyTreeId(null);
                father.setGenderCode(Constants.MAN);
                father.setCreated(new Date(System.currentTimeMillis()));
                father.setModified(null);
                fatherMember = father;
                memberAdd.setFatherFamilyTreeId(father);
                memberAdd.setModified(new Date(System.currentTimeMillis()));
            }
        });
    }

    private void createMemberMother(final Member member, final Relationship relationshipIdWithYou, final Relationship relationshipIdWithCreater) {
        mRealm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(@NonNull Realm realm) {
                final Member mother = realm.createObject(Member.class, ++id);
                mother.setHaeFlag(0);
                mother.setSynchronizeFlag(false);
                mother.setFamilyTestFlag(false);
                mother.setRelationshipIdWithYou(relationshipIdWithYou);
                mother.setRelationshipIdWithCreater(relationshipIdWithCreater);
                mother.setCreaterFamilyTreeId(member);
                mother.setFatherFamilyTreeId(null);
                mother.setMotherFamilyTreeId(null);
                mother.setGenderCode(Constants.WOMAN);
                mother.setCreated(new Date(System.currentTimeMillis()));
                mother.setModified(null);
                motherMember = mother;
                memberAdd.setMotherFamilyTreeId(mother);
                memberAdd.setModified(new Date(System.currentTimeMillis()));
            }
        });
    }

    private void createMemberSpouse(final Member member, final Relationship relationshipIdWithYou, final Relationship relationshipIdWithCreater, final String gender) {

        mRealm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(@NonNull Realm realm) {
                String genderCode = "";
                if (Constants.MAN.equals(gender)) {
                    genderCode = Constants.WOMAN;
                } else if (Constants.WOMAN.equals(gender)) {
                    genderCode = Constants.MAN;
                }
                final Member spouse = realm.createObject(Member.class, ++id);
                spouse.setHaeFlag(0);
                spouse.setSynchronizeFlag(false);
                spouse.setFamilyTestFlag(false);
                spouse.setRelationshipIdWithYou(relationshipIdWithYou);
                spouse.setRelationshipIdWithCreater(relationshipIdWithCreater);
                spouse.setCreaterFamilyTreeId(member);
                spouse.setFatherFamilyTreeId(null);
                spouse.setMotherFamilyTreeId(null);
                spouse.setGenderCode(genderCode);
                spouse.setCreated(new Date(System.currentTimeMillis()));
                spouse.setModified(null);
                spouseMember = spouse;

            }
        });

//        Member spouse = new Member(++id, 0, false, false, relationshipIdWithYou, relationshipIdWithCreater, member, null, null, genderCode, null, null);
//        spouseMember = spouse;
//        return spouse;
    }

    private List<Member> createListMemberBrother(int numberBrother, Member createrFamilyTreeId, Relationship relationshipIdWithYou, Relationship relationshipIdWithCreater) {
        if (numberBrother > 0) {
            List<Member> listBrother = new ArrayList<>();
            for (int i = 0; i < numberBrother; i++) {
                Member brother = new Member(++id, 0, false, false, relationshipIdWithYou, relationshipIdWithCreater, createrFamilyTreeId
                        , fatherMember, motherMember, "man", new Date(System.currentTimeMillis()), null);

                listBrother.add(brother);
            }
            return listBrother;
        }

        return null;
    }

    private List<Member> createListMemberSister(int numberSister, Member createrFamilyTreeId, Relationship relationshipIdWithYou, Relationship relationshipIdWithCreater) {
        if (numberSister > 0) {
            List<Member> listSister = new ArrayList<>();
            for (int i = 0; i < numberSister; i++) {
                Member sister = new Member(++id, 0, false, false, relationshipIdWithYou, relationshipIdWithCreater, createrFamilyTreeId
                        , fatherMember, motherMember, "woman", new Date(System.currentTimeMillis()), null);
                listSister.add(sister);
            }
            return listSister;
        }
        return null;
    }

    private List<Member> createListMemberSon(int numberSon, Member createrFamilyTreeId, Relationship relationshipIdWithYou, Relationship relationshipIdWithCreater, String gender) {
        if (numberSon > 0) {
            List<Member> listSon = new ArrayList<>();
            for (int i = 0; i < numberSon; i++) {
                Member son = null;
                if (gender.equals(Constants.WOMAN)) {
                    son = new Member(++id, 0, false, false, relationshipIdWithYou, relationshipIdWithCreater, createrFamilyTreeId
                            , spouseMember, createrFamilyTreeId, Constants.MAN, new Date(System.currentTimeMillis()), null);
                } else if (gender.equals(Constants.MAN)) {
                    son = new Member(++id, 0, false, false, relationshipIdWithYou, relationshipIdWithCreater, createrFamilyTreeId
                            , createrFamilyTreeId, spouseMember, Constants.MAN, new Date(System.currentTimeMillis()), null);
                }
                if (son != null) {
                    listSon.add(son);
                }
            }

            return listSon;
        }

        return null;
    }

    private List<Member> createListMemberDaughter(int numberDaughter, Member createrFamilyTreeId, Relationship relationshipIdWithYou,
                                                  Relationship relationshipIdWithCreater, String gender) {
        if (numberDaughter > 0) {
            List<Member> listDaughter = new ArrayList<>();
            for (int i = 0; i < numberDaughter; i++) {
                Member daughter = null;
                if (gender.equals(Constants.WOMAN)) {
                    daughter = new Member(++id, 0, false, false, relationshipIdWithYou, relationshipIdWithCreater, createrFamilyTreeId
                            , spouseMember, createrFamilyTreeId, Constants.WOMAN, new Date(System.currentTimeMillis()), null);
                } else if (gender.equals(Constants.MAN)) {
                    daughter = new Member(++id, 0, false, false, relationshipIdWithYou, relationshipIdWithCreater, createrFamilyTreeId
                            , createrFamilyTreeId, spouseMember, Constants.WOMAN, new Date(System.currentTimeMillis()), null);
                }
                if (daughter != null) {
                    listDaughter.add(daughter);
                }
            }

            return listDaughter;
        }
        return null;
    }

    private AlertDialog savingDialog;

    @Override
    public void onSaveImageStart() {
        if (null == savingDialog) {
            savingDialog = new AlertDialog.Builder(mContext, R.style.CamAlertDialogStyle)
                    .setMessage(mContext.getString(R.string.sr_saving_alert))
                    .create();
        }
        savingDialog.show();
    }

    @Override
    public void onSaveImageSuccess() {
        if (null != savingDialog) {
            savingDialog.dismiss();
        }
        mFamilyTreeView.showDialogSaveImageSuccess();
    }

    @Override
    public void onSaveImageFail() {
        if (null != savingDialog) {
            savingDialog.dismiss();
        }
        mFamilyTreeView.showDialogSaveImageFail();
    }
}
