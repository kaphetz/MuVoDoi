package com.welby.hae.ui.familytree;

import com.welby.hae.data.db.model.Member;

import io.realm.RealmResults;

/**
 * Created by Welby Dev on 10/9/2017.
 */

public interface FamilyTreeView {
    void drawFamilyTreeView(RealmResults<Member> members, Member member, Member focusMember);

    void showTutorialFamilyTree();

    void showDialogCreateFamilyTreeFirst(Member member);

    void showDialogCreateFamilyTree(Member member);

    void showDialogSaveImageSuccess();

    void showDialogSaveImageFail();

    void showPermissionsRequiredAlert(String message);
}
