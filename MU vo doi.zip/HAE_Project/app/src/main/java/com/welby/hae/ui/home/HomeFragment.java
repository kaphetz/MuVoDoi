package com.welby.hae.ui.home;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.RelativeSizeSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.welby.hae.HAEApplication;
import com.welby.hae.R;
import com.welby.hae.ui.base.BaseFragment;
import com.welby.hae.ui.camera.CamActivity;
import com.welby.hae.ui.custom.ClickHandler;
import com.welby.hae.ui.main.MainActivity;
import com.welby.hae.utils.Define;
import com.welby.hae.utils.TextUtil;
import com.welby.hae.utils.TimeUtil;

import java.util.Date;

/**
 * Created by WelbyDev.
 */

public class HomeFragment extends BaseFragment implements HomeView, View.OnClickListener {
    private TextView tvSeizureCount;
    private TextView tvDate;

    private TextView tvUrl;

    private HomePresenter presenter;
    private ClickHandler clickHandler;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return LayoutInflater.from(getActivity()).inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initData();
    }

    @Override
    public void onResume() {
        super.onResume();
        HAEApplication.getInstance().trackScreenView(getString(R.string.screen_home));
        setLastVisibleFragment(HomeFragment.class.getName());
    }

    @Override
    public void initView(View view) {
        tvSeizureCount = view.findViewById(R.id.tv_count);
        tvDate = view.findViewById(R.id.tv_date);
        View layoutDate = view.findViewById(R.id.layout_date);
        TextView btnCalendar = view.findViewById(R.id.tv_calendar);
        TextView tvList = view.findViewById(R.id.tv_list);
        TextView tvGraph = view.findViewById(R.id.tv_graph);
        ImageView ivRecord = view.findViewById(R.id.iv_record);
        ImageView ivCamera = view.findViewById(R.id.iv_camera);
        TextView tvShareHAE = view.findViewById(R.id.tv_share_hae);
        TextView tvGenFamilyTree = view.findViewById(R.id.tv_gen_family_tree);
        tvUrl = view.findViewById(R.id.tv_url);

        layoutDate.setOnClickListener(this);
        tvSeizureCount.setOnClickListener(this);
        btnCalendar.setOnClickListener(this);
        tvList.setOnClickListener(this);
        tvGraph.setOnClickListener(this);
        ivRecord.setOnClickListener(this);
        ivCamera.setOnClickListener(this);
        tvShareHAE.setOnClickListener(this);
        tvGenFamilyTree.setOnClickListener(this);
        tvUrl.setOnClickListener(this);
    }

    @Override
    public void initData() {
        presenter = new HomePresenter(this);
        tvUrl.setText(TextUtil.fromHtml(getString(R.string.home_url)));
        bindData();
        clickHandler = new ClickHandler(Define.CLICK_DELAY);
    }

    public void bindData() {
        presenter.setSeizureCountInThreeMonths();
        presenter.setLastSeizureDay();
    }

    public boolean isInitialized() {
        return presenter != null;
    }

    @Override
    public void onClick(View view) {
        if (!clickHandler.isClickable(view.getId())) {
            return;
        }
        switch (view.getId()) {
            case R.id.tv_count:
                navigate(Define.Navigate.CALENDAR_GRAPH);
                HAEApplication.getInstance().trackEvent(getString(R.string.event_top_confirm_times_graph));
                break;
            case R.id.layout_date:
                navigate(Define.Navigate.CALENDAR_GRAPH);
                HAEApplication.getInstance().trackEvent(getString(R.string.event_top_confirm_times_graph));
                break;
            case R.id.tv_calendar:
                navigate(Define.Navigate.CALENDAR_SCREEN);
                HAEApplication.getInstance().trackEvent(getString(R.string.event_top_confirm_calender));
                break;
            case R.id.tv_graph:
                navigate(Define.Navigate.CALENDAR_GRAPH);
                HAEApplication.getInstance().trackEvent(getString(R.string.event_top_confirm_graph));
                break;
            case R.id.tv_list:
                navigate(Define.Navigate.CALENDAR_LIST);
                HAEApplication.getInstance().trackEvent(getString(R.string.event_top_confirm_list));
                break;
            case R.id.iv_record:
                // Go to symptom record activity
                navigate(Define.Navigate.SYMPTOM_RECORD);
                HAEApplication.getInstance().trackEvent(getString(R.string.event_top_record_symptom));
                break;
            case R.id.iv_camera: {
                Intent intent = new Intent(getActivity(), CamActivity.class);
                intent.putExtra(Define.ExtrasKey.CALLER_FLAG, getActivity().getClass().getName());
                startActivity(intent);
                HAEApplication.getInstance().trackEvent(getString(R.string.event_top_record_symptom_camera));
            }
            break;
            case R.id.tv_share_hae:
                navigate(Define.Navigate.SHARE_SCREEN);
                HAEApplication.getInstance().trackEvent(getString(R.string.event_top_family_convey));
                break;
            case R.id.tv_gen_family_tree:
                // go to family tree
                navigate(Define.Navigate.FAMILY_TREE);
                HAEApplication.getInstance().trackEvent(getString(R.string.event_top_family_tree));
                break;
            case R.id.tv_url:
                navigate(Define.Navigate.HAE_PAGE);
                HAEApplication.getInstance().trackEvent(getString(R.string.event_top_web_harefukutsuu_navi));
                break;
            default:
                break;
        }
    }

    private void navigate(int screen) {
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).navigate(screen);
        }
    }

    @Override
    public void setSeizureCountInThreeMonths(int seizureCount) {
        Spannable span = new SpannableString(getString(R.string.home_count, seizureCount));
        span.setSpan(new RelativeSizeSpan(2f), 0, String.valueOf(seizureCount).length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        tvSeizureCount.setText(span);
    }

    @Override
    public void setDate(Date date) {
        if (date != null) {
            tvDate.setText(TimeUtil.getTime(TimeUtil.FORMAT_5, date));
        } else {
            tvDate.setText(getString(R.string.home_date_empty));
        }
    }
}
