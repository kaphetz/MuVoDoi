package com.welby.hae.ui.home;

import com.welby.hae.data.db.helper.RealmManager;
import com.welby.hae.ui.base.BasePresenter;

import java.util.Date;

/**
 * Created by WelbyDev.
 */

class HomePresenter extends BasePresenter {
    private HomeView homeView;

    HomePresenter(HomeView homeView) {
        this.homeView = homeView;
    }

    void setSeizureCountInThreeMonths() {
        int seizureCount = RealmManager.getRealmManager()
                .getSymptomHelper()
                .getSeizureCountInRecentMonths(3);
        homeView.setSeizureCountInThreeMonths(seizureCount);
    }

    void setLastSeizureDay() {
        Date date = RealmManager.getRealmManager()
                .getSymptomHelper()
                .getLastSeizureDay();
        homeView.setDate(date);
    }
}
