package com.welby.hae.ui.home;

import com.welby.hae.ui.base.BaseView;

import java.util.Date;

/**
 * Created by WelbyDev.
 */

interface HomeView extends BaseView {
    void setSeizureCountInThreeMonths(int seizureCount);

    void setDate(Date date);
}
