package com.welby.hae.ui.main;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.welby.hae.HAEApplication;
import com.welby.hae.R;
import com.welby.hae.adapter.HomeDrawerAdapter;
import com.welby.hae.model.Version;
import com.welby.hae.ui.base.BaseActivity;
import com.welby.hae.ui.base.BaseFragment;
import com.welby.hae.ui.calendar.CalendarFragment;
import com.welby.hae.ui.custom.ClickHandler;
import com.welby.hae.ui.custom.HomeDrawerDivider;
import com.welby.hae.ui.dialog.AppAlertDialog;
import com.welby.hae.ui.familytree.FamilyTreeFragment;
import com.welby.hae.ui.home.HomeFragment;
import com.welby.hae.ui.review.ReviewFragment;
import com.welby.hae.ui.setting.BackupActivity;
import com.welby.hae.ui.setting.Reminder;
import com.welby.hae.ui.setting.StartActivity;
import com.welby.hae.ui.setting.guide.GuideActivity;
import com.welby.hae.ui.setting.share.ShareFragment;
import com.welby.hae.ui.symptomrecord.SymptomRecordActivity;
import com.welby.hae.utils.Define;
import com.welby.hae.utils.FileUtil;

import java.util.Calendar;

/**
 * Created by WelbyDev.
 */

public class MainActivity extends BaseActivity implements MainView, View.OnClickListener {
    private Toolbar toolbar;
    private DrawerLayout drawerLayout;
    private RecyclerView drawerList;
    private HomeDrawerAdapter drawerAdapter;
    private ImageView ivMenu;

    private MainPresenter presenter;
    private ClickHandler clickHandler;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        initData();
    }

    /**
     * update data in home fragment
     * when back from other activity
     */
    @Override
    protected void onResume() {
        super.onResume();
        Fragment fragment = getSupportFragmentManager().findFragmentByTag(HomeFragment.class.getName());
        if (fragment instanceof HomeFragment && ((HomeFragment) fragment).isInitialized()) {
            ((HomeFragment) fragment).bindData();
        }
        if (lastVisibleActivity.equals(SymptomRecordActivity.class.getName())) {
            navigate(Define.Navigate.CALENDAR_SCREEN);
            setLastVisibleActivity(Define.STR_EMPTY);
        }
        if (lastVisibleActivity.equals(MainActivity.class.getName())) {
            if (getSupportFragmentManager().getBackStackEntryCount() > 1) {
                getSupportFragmentManager().popBackStackImmediate();
                presenter.onBackPress(getSupportFragmentManager());
                presenter.setToolbarContent(this);
                setMenuItemSelected(0);
            }
            setLastVisibleActivity(Define.STR_EMPTY);
        }
    }

    @Override
    public void initView() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(ContextCompat.getColor(this, R.color.colorPrimary));
        }

        toolbar = findViewById(R.id.toolbar);
        drawerLayout = findViewById(R.id.drawer_layout);
        drawerList = findViewById(R.id.rv_drawer);
        ivMenu = findViewById(R.id.iv_menu);

        ivMenu.setOnClickListener(this);
    }

    @Override
    public void initData() {
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }
        drawerAdapter = new HomeDrawerAdapter(getResources().getStringArray(R.array.home_drawer_items));
        drawerAdapter.setOnItemClickListener(new HomeDrawerAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                navigate(position);
                drawerLayout.closeDrawers();
                trackMenuEvent(position);
            }
        });
        drawerList.addItemDecoration(new HomeDrawerDivider(this));
        drawerList.setAdapter(drawerAdapter);
        drawerLayout.setScrimColor(ContextCompat.getColor(this, android.R.color.transparent));
        drawerLayout.addDrawerListener(new DrawerLayout.DrawerListener() {
            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                //implement method
            }

            @Override
            public void onDrawerOpened(View drawerView) {
                Glide.with(MainActivity.this).load(R.drawable.ic_close_toolbar).into(ivMenu);
                HAEApplication.getInstance().trackScreenView(getString(R.string.screen_menu));
                HAEApplication.getInstance().trackEvent(getString(R.string.event_top_menu));
            }

            @Override
            public void onDrawerClosed(View drawerView) {
                Glide.with(MainActivity.this).load(R.drawable.ic_menu).into(ivMenu);
            }

            @Override
            public void onDrawerStateChanged(int newState) {
                //implement method
            }
        });

        presenter = new MainPresenter(this);
        navigate(Define.Navigate.HOME); //display home as default
        presenter.checkUpdate();

        new Reminder(this).create();
        clickHandler = new ClickHandler(Define.CLICK_DELAY);
    }

    @Override
    public void onClick(View view) {
        if (!clickHandler.isClickable(view.getId())) {
            return;
        }
        if (view.getId() == R.id.iv_menu) {
            if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                drawerLayout.closeDrawers();
            } else {
                drawerLayout.openDrawer(GravityCompat.START);
                trackMenuEventInFragment();
            }
        } else if (view.getId() == R.id.iv_back) {
            onBackPressed();
        }
    }

    public void navigate(int position) {
        if (position == drawerAdapter.getSelectedPosition()) {
            return;
        }
        switch (position) {
            case Define.Navigate.HOME:
                presenter.navigateToFragment(getSupportFragmentManager(), HomeFragment.class.getName());
                presenter.setToolbarContent(this);
                break;
            case Define.Navigate.SYMPTOM_RECORD:
                navigateToActivity(SymptomRecordActivity.class);
                break;
            case Define.Navigate.CALENDAR_GRAPH:
                navigateToCalendar(CalendarFragment.TAB_GRAPH, Calendar.getInstance());
                break;
            case Define.Navigate.HAE_PAGE:
                navigateToUrl(getString(R.string.hae_page));
                break;
            case Define.Navigate.SHARE_SCREEN:
                presenter.navigateToFragment(getSupportFragmentManager(), ShareFragment.class.getName());
                presenter.setToolbarContent(this);
                break;
            case Define.Navigate.FAMILY_TREE:
                presenter.navigateToFragment(getSupportFragmentManager(), FamilyTreeFragment.class.getName());
                presenter.setToolbarContent(this);
                break;
            case Define.Navigate.GUIDE_SCREEN:
                navigateToActivity(GuideActivity.class);
                break;
            case Define.Navigate.BACKUP_SCREEN:
                navigateToActivity(BackupActivity.class);
                break;
            case Define.Navigate.START_SCREEN:
                navigateToActivity(StartActivity.class);
                break;
            case Define.Navigate.WELBY_PAGE:
                navigateToUrl(getString(R.string.welby_page));
                break;
            case Define.Navigate.CALENDAR_SCREEN:
                navigateToCalendar(CalendarFragment.TAB_CALENDAR, Calendar.getInstance());
                break;
            case Define.Navigate.CALENDAR_LIST:
                navigateToCalendar(CalendarFragment.TAB_LIST, Calendar.getInstance());
                break;
            default:
                break;
        }
    }

    public void navigateToCalendar(int selectedTab, Calendar cal) {
        presenter.navigateToCalendar(getSupportFragmentManager(), selectedTab, cal);
        presenter.setToolbarContent(this);
    }

    public void navigateToReview(Bundle data) {
        presenter.navigateToReview(getSupportFragmentManager(), data);
        presenter.setToolbarContent(this);
    }

    private void navigateToUrl(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }

    /**
     * tracking menu item click event
     *
     * @param position position of item
     */
    private void trackMenuEvent(int position) {
        switch (position) {
            case Define.Navigate.HOME:
                HAEApplication.getInstance().trackEvent(getString(R.string.event_home_from_menu));
                break;
            case Define.Navigate.SYMPTOM_RECORD:
                HAEApplication.getInstance().trackEvent(getString(R.string.event_record_symptom_from_menu));
                break;
            case Define.Navigate.CALENDAR_GRAPH:
                HAEApplication.getInstance().trackEvent(getString(R.string.event_confirm_graph_from_menu));
                break;
            case Define.Navigate.HAE_PAGE:
                HAEApplication.getInstance().trackEvent(getString(R.string.event_web_harefukutsuu_navi_from_menu));
                break;
            case Define.Navigate.SHARE_SCREEN:
                HAEApplication.getInstance().trackEvent(getString(R.string.event_family_convey_from_menu));
                break;
            case Define.Navigate.FAMILY_TREE:
                HAEApplication.getInstance().trackEvent(getString(R.string.event_family_tree_from_menu));
                break;
            case Define.Navigate.GUIDE_SCREEN:
                HAEApplication.getInstance().trackEvent(getString(R.string.event_tutorial_from_menu));
                break;
            case Define.Navigate.BACKUP_SCREEN:
                HAEApplication.getInstance().trackEvent(getString(R.string.event_backup_from_menu));
                break;
            case Define.Navigate.START_SCREEN:
                HAEApplication.getInstance().trackEvent(getString(R.string.event_regulation_apps_from_menu));
                break;
            case Define.Navigate.WELBY_PAGE:
                HAEApplication.getInstance().trackEvent(getString(R.string.event_welby_site_from_menu));
                break;
            default:
                break;
        }
    }

    private void trackBackEventInFragment() {
        if (FamilyTreeFragment.class.getName().equals(BaseFragment.lastVisibleFragment)) {
            HAEApplication.getInstance().trackEvent(getString(R.string.event_back_previous_family_tree));
        } else if (ShareFragment.class.getName().equals(BaseFragment.lastVisibleFragment)) {
            HAEApplication.getInstance().trackEvent(getString(R.string.event_back_previous_family_convey));
        } else if (ReviewFragment.class.getName().equals(BaseFragment.lastVisibleFragment)) {
            HAEApplication.getInstance().trackEvent(getString(R.string.event_back_previous_confirm_symptom));
        }
    }

    private void trackMenuEventInFragment() {
        if (FamilyTreeFragment.class.getName().equals(BaseFragment.lastVisibleFragment)) {
            HAEApplication.getInstance().trackEvent(getString(R.string.event_menu_family_tree));
        } else if (ReviewFragment.class.getName().equals(BaseFragment.lastVisibleFragment)) {
            HAEApplication.getInstance().trackEvent(getString(R.string.event_menu_family_tree));
        }
    }

    @Override
    public void setToolbarContent(String title, int backVisibility, int backgroundResource, int toolbarHeight) {
        ((TextView) toolbar.findViewById(R.id.tv_toolbar_title)).setText(title);
        toolbar.findViewById(R.id.iv_back).setVisibility(backVisibility);
        // add listener
        toolbar.findViewById(R.id.iv_back).setOnClickListener(this);

        toolbar.getLayoutParams().height = toolbarHeight;
        toolbar.setBackgroundResource(backgroundResource);
        if (title.isEmpty()) {
            (toolbar.findViewById(R.id.tv_toolbar_logo)).setVisibility(View.VISIBLE);
        } else {
            (toolbar.findViewById(R.id.tv_toolbar_logo)).setVisibility(View.GONE);
        }
    }

    @Override
    public void setMenuItemSelected(int position) {
        drawerAdapter.setSelectedPosition(position);
    }

    public void navigateToActivity(Class destActivity) {
        startActivity(new Intent(this, destActivity));
    }

    @Override
    public void navigateToFragment(Fragment destFragment, boolean addToBackStack) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.layout_content, destFragment, destFragment.getClass().getName());
        if (addToBackStack) {
            transaction.addToBackStack(destFragment.getClass().getName());
        }
        transaction.commit();
        presenter.setToolbarContent(this);
        presenter.setMenuItemSelected();

        /*
         * update data in home fragment
         * when back from other fragment
         */
        if (destFragment instanceof HomeFragment && ((HomeFragment) destFragment).isInitialized()) {
            ((HomeFragment) destFragment).bindData();
        }
    }

    @Override
    public void showDialogUpdateVersion(final Version version) {
        new AppAlertDialog.Builder(getSupportFragmentManager())
                .message(version.getUpdate_message())
                .visibleCloseButton(true)
                .setOnActionListener(new AppAlertDialog.OnActionListener() {
                    @Override
                    public void onConfirm() {
                        Intent i = new Intent(Intent.ACTION_VIEW);
                        i.setData(Uri.parse(version.getUpdate_url()));
                        startActivity(i);
                        HAEApplication.getInstance().trackEvent(getString(R.string.event_update_tap));
                    }

                    @Override
                    public void onCancel() {
                        //implement method
                    }
                })
                .build()
                .show();
        HAEApplication.getInstance().trackScreenView(getString(R.string.screen_update_dialog));
    }

    /**
     * check priority: drawer > size of backstack > is HomeFragment exist
     * if drawer is opening -> close drawer and return
     * if size of backstack > 1 -> pop backstack else finish
     * else navigate to home
     */
    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawers();
            return;
        }
        onBack();
    }

    @Override
    public void onBack() {
        if (getSupportFragmentManager().getBackStackEntryCount() == 1) { //keep the first fragment
            finish();
        } else {
            trackBackEventInFragment();
            getSupportFragmentManager().popBackStackImmediate();
            Fragment homeFragment = getSupportFragmentManager().findFragmentByTag(HomeFragment.class.getName());
            if (homeFragment != null) {
                navigateToFragment(homeFragment, false);
            } else {
                super.onBackPressed();
            }
            presenter.onBackPress(getSupportFragmentManager());
            presenter.setToolbarContent(this);
            setMenuItemSelected(0);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        FileUtil.removeTempFile();
        setLastVisibleActivity(Define.STR_EMPTY);
        BaseFragment.setLastVisibleFragment(Define.STR_EMPTY);
    }
}
