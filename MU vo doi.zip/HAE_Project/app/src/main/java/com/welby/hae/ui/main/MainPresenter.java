package com.welby.hae.ui.main;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.util.Log;
import android.view.View;

import com.welby.hae.BuildConfig;
import com.welby.hae.R;
import com.welby.hae.model.Version;
import com.welby.hae.model.VersionApp;
import com.welby.hae.rest.ApiClient;
import com.welby.hae.rest.ApiInterface;
import com.welby.hae.ui.base.BasePresenter;
import com.welby.hae.ui.calendar.CalendarFragment;
import com.welby.hae.ui.familytree.FamilyTreeFragment;
import com.welby.hae.ui.home.HomeFragment;
import com.welby.hae.ui.review.ReviewFragment;
import com.welby.hae.ui.setting.share.ShareFragment;
import com.welby.hae.utils.Define;
import com.welby.hae.utils.RLog;

import java.util.Calendar;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by WelbyDev.
 */

class MainPresenter extends BasePresenter {
    private MainView mainView;
    private Fragment currentFragment = null;

    MainPresenter(MainView mainView) {
        this.mainView = mainView;
    }

    /**
     * navigate to fragment.
     * size of backstack is always equals 2
     * except review fragment is on top
     *
     * @param fragmentManager fragment manager
     * @param fragmentTag     fragment tag
     */
    void navigateToFragment(FragmentManager fragmentManager, String fragmentTag) {
        currentFragment = fragmentManager.findFragmentByTag(fragmentTag);
        if (currentFragment == null) {
            if (fragmentTag.equals(HomeFragment.class.getName())) {
                currentFragment = new HomeFragment();
            } else if (fragmentTag.equals(ShareFragment.class.getName())) {
                currentFragment = new ShareFragment();
            } else if (fragmentTag.equals(FamilyTreeFragment.class.getName())) {
                currentFragment = new FamilyTreeFragment();
            }
        }
        if (currentFragment instanceof HomeFragment && fragmentManager.getBackStackEntryCount() == 0) {
            mainView.navigateToFragment(currentFragment, true);
        } else if (currentFragment instanceof HomeFragment && fragmentManager.getBackStackEntryCount() > 1) {
            mainView.onBack();
        } else {
            mainView.navigateToFragment(currentFragment, fragmentManager.getBackStackEntryCount() < 2); //back stack size is always equals 2
        }
    }

    void navigateToReview(FragmentManager fragmentManager, Bundle data) {
        currentFragment = ReviewFragment.getInstance(data);
        mainView.navigateToFragment(currentFragment, fragmentManager.getBackStackEntryCount() < 2); //back stack size is always equals 2
    }

    void navigateToCalendar(FragmentManager fragmentManager, int tab, Calendar calendar) {
        currentFragment = CalendarFragment.newInstance(tab, calendar);
        mainView.navigateToFragment(currentFragment, fragmentManager.getBackStackEntryCount() < 2); //back stack size is always equals 2
    }

    void setToolbarContent(Context context) {
        if (currentFragment instanceof HomeFragment) {
            mainView.setToolbarContent(Define.STR_EMPTY
                    , View.GONE, R.drawable.bg_toolbar_solid
                    , context.getResources().getDimensionPixelSize(R.dimen.main_toolbar_default_height));
        } else if (currentFragment instanceof CalendarFragment) {
            mainView.setToolbarContent(context.getResources().getStringArray(R.array.home_drawer_items)[2]
                    , View.VISIBLE, R.drawable.bg_toolbar_solid
                    , context.getResources().getDimensionPixelSize(R.dimen.main_toolbar_default_height));
        } else if (currentFragment instanceof ShareFragment) {
            mainView.setToolbarContent(context.getResources().getStringArray(R.array.home_drawer_items)[5]
                    , View.VISIBLE, R.drawable.bg_toolbar_rounded
                    , context.getResources().getDimensionPixelSize(R.dimen.main_toolbar_rounded_height));
        } else if (currentFragment instanceof FamilyTreeFragment) {
            mainView.setToolbarContent(context.getResources().getStringArray(R.array.home_drawer_items)[6]
                    , View.VISIBLE, R.drawable.bg_toolbar_rounded
                    , context.getResources().getDimensionPixelSize(R.dimen.main_toolbar_rounded_height));
        } else if (currentFragment instanceof ReviewFragment) {
            mainView.setToolbarContent(context.getString(R.string.rv_title)
                    , View.VISIBLE, R.drawable.bg_toolbar_rounded
                    , context.getResources().getDimensionPixelSize(R.dimen.main_toolbar_rounded_height));
        }
    }

    void setMenuItemSelected() {
        if (currentFragment instanceof HomeFragment) {
            mainView.setMenuItemSelected(0);
        } else if (currentFragment instanceof CalendarFragment) {
            mainView.setMenuItemSelected(2);
        } else if (currentFragment instanceof ShareFragment) {
            mainView.setMenuItemSelected(5);
        } else if (currentFragment instanceof FamilyTreeFragment) {
            mainView.setMenuItemSelected(6);
        }
    }

    void onBackPress(FragmentManager fragmentManager) {
        currentFragment = fragmentManager.findFragmentByTag(HomeFragment.class.getName());
    }

    void checkUpdate() {
        final ApiInterface apiServer = ApiClient.getClient().create(ApiInterface.class);
        Call<VersionApp> call = apiServer.getVersionApp();
        call.enqueue(new Callback<VersionApp>() {
            @Override
            public void onResponse(Call<VersionApp> call, Response<VersionApp> response) {
                VersionApp versionApp = response.body();
                if (versionApp != null) {
                    Version android = versionApp.getAndroid();
                    if (android != null) {
                        boolean isNeedUpdate = compareVersion(android.getRequired_version());
                        if (isNeedUpdate) {
                            mainView.showDialogUpdateVersion(android);
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<VersionApp> call, Throwable t) {
                RLog.d("error: " + t.getMessage());
            }
        });
    }

    private boolean compareVersion(String serverVersion) {
        if (serverVersion == null) {
            return false;
        }
        String currentVersion = BuildConfig.VERSION_NAME;

        String[] thisParts = currentVersion.split("\\.");
        String[] thatParts = serverVersion.split("\\.");
        int length = Math.max(thisParts.length, thatParts.length);
        for (int i = 0; i < length; i++) {
            int thisPart = i < thisParts.length ?
                    Integer.parseInt(thisParts[i]) : 0;
            int thatPart = i < thatParts.length ?
                    Integer.parseInt(thatParts[i]) : 0;
            if (thisPart < thatPart)
                return true;
            if (thisPart > thatPart)
                return false;
        }
        return false;
    }
}
