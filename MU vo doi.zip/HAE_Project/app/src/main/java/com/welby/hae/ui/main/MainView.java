package com.welby.hae.ui.main;

import android.support.v4.app.Fragment;

import com.welby.hae.model.Version;
import com.welby.hae.ui.base.BaseView;

/**
 * Created by WelbyDev.
 */

interface MainView extends BaseView {
    void setToolbarContent(String title, int backVisibility, int backgroundResource, int toolbarHeight);

    void setMenuItemSelected(int position);

    void navigateToFragment(Fragment destFragment, boolean addToBackStack);

    void showDialogUpdateVersion(Version version);

    void onBack();
}
