package com.welby.hae.ui.review;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.annotation.Nullable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.welby.hae.HAEApplication;
import com.welby.hae.R;
import com.welby.hae.model.Photo;
import com.welby.hae.ui.base.BaseFragment;
import com.welby.hae.ui.custom.PainLevelSeekBar;
import com.welby.hae.ui.dialog.AppAlertDialog;
import com.welby.hae.ui.dialog.ViewPhotoDialog;
import com.welby.hae.ui.main.MainActivity;
import com.welby.hae.ui.symptomrecord.SymptomRecordActivity;
import com.welby.hae.utils.Define;
import com.welby.hae.utils.TimeUtil;

import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * Created by WelbyDev.
 */

public class ReviewFragment extends BaseFragment implements ReviewView, View.OnClickListener {

    private TextView tvStartDate;
    private TextView tvEndDate;
    private ImageView ivPic1;
    private ImageView ivPic2;
    private ImageView ivPic3;
    private ImageView ivPic4;
    private TextView tvPhotoDate1;
    private TextView tvPhotoDate2;
    private TextView tvPhotoDate3;
    private TextView tvPhotoDate4;
    private TextView tvTreatment;
    private PainLevelSeekBar sbPain;
    private TextView tvMemo;
    private TextView tvLabelBody;
    private RadioGroup rgBody;

    private View layoutBodyFront;
    private ImageView ivBody1;
    private ImageView ivFace;
    private ImageView ivBody3;
    private ImageView ivRightArm;
    private ImageView ivBody;
    private ImageView ivLeftArm;
    private ImageView ivRightFinger;
    private ImageView ivRightLeg;
    private ImageView ivLeftLeg;
    private ImageView ivLeftFinger;
    private ImageView ivBody11;
    private ImageView ivRightToe;
    private ImageView ivLeftToe;
    private ImageView ivBody14;

    private ImageView ivSolidFace;
    private ImageView ivSolidBody;
    private ImageView ivSolidRightArm;
    private ImageView ivSolidLeftArm;
    private ImageView ivSolidRightFinger;
    private ImageView ivSolidLeftFinger;
    private ImageView ivSolidRightLeg;
    private ImageView ivSolidLeftLeg;
    private ImageView ivSolidRightToe;
    private ImageView ivSolidLeftToe;

    private View layoutBodyBack;
    private ImageView ivBack1;
    private ImageView ivBack2;
    private ImageView ivBackBody;
    private ImageView ivBack4;
    private ImageView ivBack5;
    private ImageView ivBackLeftLeg;
    private ImageView ivBackRightLeg;
    private ImageView ivBack8;
    private ImageView ivBack9;

    private ImageView ivSolidBackBody;
    private ImageView ivSolidBackLeftLeg;
    private ImageView ivSolidBackRightLeg;

    private ReviewPresenter presenter;

    public static ReviewFragment getInstance(Bundle data) {
        ReviewFragment fragment = new ReviewFragment();
        fragment.setArguments(data);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return LayoutInflater.from(getActivity()).inflate(R.layout.fragment_review, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initData();
    }

    @Override
    public void onResume() {
        super.onResume();
        HAEApplication.getInstance().trackScreenView(getString(R.string.screen_confirm_symptom));
        setLastVisibleFragment(ReviewFragment.class.getName());
    }

    @Override
    public void initView(View view) {
        tvStartDate = view.findViewById(R.id.tv_start_date);
        tvEndDate = view.findViewById(R.id.tv_end_date);
        ivPic1 = view.findViewById(R.id.iv_pic_1);
        ivPic2 = view.findViewById(R.id.iv_pic_2);
        ivPic3 = view.findViewById(R.id.iv_pic_3);
        ivPic4 = view.findViewById(R.id.iv_pic_4);
        tvPhotoDate1 = view.findViewById(R.id.tv_date_1);
        tvPhotoDate2 = view.findViewById(R.id.tv_date_2);
        tvPhotoDate3 = view.findViewById(R.id.tv_date_3);
        tvPhotoDate4 = view.findViewById(R.id.tv_date_4);
        Button btnEdit = view.findViewById(R.id.btn_edit);
        Button btnDelete = view.findViewById(R.id.btn_delete);
        tvTreatment = view.findViewById(R.id.tv_treatment);
        sbPain = view.findViewById(R.id.sb_pain);
        tvMemo = view.findViewById(R.id.tv_memo);
        tvLabelBody = view.findViewById(R.id.tv_label_body);
        rgBody = view.findViewById(R.id.rg_body);

        layoutBodyFront = view.findViewById(R.id.layout_body_front);

        ivBody1 = view.findViewById(R.id.body_01);
        ivFace = view.findViewById(R.id.body_02);
        ivBody3 = view.findViewById(R.id.body_03);
        ivRightArm = view.findViewById(R.id.body_04);
        ivBody = view.findViewById(R.id.body_05);
        ivLeftArm = view.findViewById(R.id.body_06);
        ivRightFinger = view.findViewById(R.id.body_07);
        ivRightLeg = view.findViewById(R.id.body_08);
        ivLeftLeg = view.findViewById(R.id.body_09);
        ivLeftFinger = view.findViewById(R.id.body_10);
        ivBody11 = view.findViewById(R.id.body_11);
        ivRightToe = view.findViewById(R.id.body_12);
        ivLeftToe = view.findViewById(R.id.body_13);
        ivBody14 = view.findViewById(R.id.body_14);

        ivPic1.setOnClickListener(this);
        ivPic2.setOnClickListener(this);
        ivPic3.setOnClickListener(this);
        ivPic4.setOnClickListener(this);
        ivPic4.setOnClickListener(this);
        btnEdit.setOnClickListener(this);
        btnDelete.setOnClickListener(this);

        ivSolidFace = view.findViewById(R.id.solid_face);
        ivSolidBody = view.findViewById(R.id.solid_body);
        ivSolidRightArm = view.findViewById(R.id.solid_right_arm);
        ivSolidLeftArm = view.findViewById(R.id.solid_left_arm);
        ivSolidRightFinger = view.findViewById(R.id.solid_right_finger);
        ivSolidLeftFinger = view.findViewById(R.id.solid_left_finger);
        ivSolidRightLeg = view.findViewById(R.id.solid_right_foot);
        ivSolidLeftLeg = view.findViewById(R.id.solid_left_foot);
        ivSolidRightToe = view.findViewById(R.id.solid_right_toe);
        ivSolidLeftToe = view.findViewById(R.id.solid_left_toe);

        layoutBodyBack = view.findViewById(R.id.layout_body_back);

        ivBack1 = view.findViewById(R.id.back_01);
        ivBack2 = view.findViewById(R.id.back_02);
        ivBackBody = view.findViewById(R.id.back_03);
        ivBack4 = view.findViewById(R.id.back_04);
        ivBack5 = view.findViewById(R.id.back_05);
        ivBackLeftLeg = view.findViewById(R.id.back_06);
        ivBackRightLeg = view.findViewById(R.id.back_07);
        ivBack8 = view.findViewById(R.id.back_08);
        ivBack9 = view.findViewById(R.id.back_09);

        ivSolidBackBody = view.findViewById(R.id.solid_back_body);
        ivSolidBackLeftLeg = view.findViewById(R.id.solid_back_left_leg);
        ivSolidBackRightLeg = view.findViewById(R.id.solid_back_right_leg);

        sbPain.setEnabled(false);

        rgBody.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, @IdRes int checkedIdRes) {
                if(checkedIdRes == R.id.rb_body_front) {
                    layoutBodyFront.setVisibility(View.VISIBLE);
                    layoutBodyBack.setVisibility(View.GONE);
                } else {
                    layoutBodyFront.setVisibility(View.GONE);
                    layoutBodyBack.setVisibility(View.VISIBLE);
                }
            }
        });
    }

    @Override
    public void initData() {
        presenter = new ReviewPresenter(this, getArguments().getInt(Define.ExtrasKey.SYMPTOM_ID));

        Glide.with(this).load(R.drawable.body_01_33_17).into(ivBody1);
        Glide.with(this).load(R.drawable.body_02_34_17).into(ivFace);
        Glide.with(this).load(R.drawable.body_03_33_17).into(ivBody3);
        Glide.with(this).load(R.drawable.body_04_33_29).into(ivRightArm);
        Glide.with(this).load(R.drawable.body_05_34_29).into(ivBody);
        Glide.with(this).load(R.drawable.body_06_33_29).into(ivLeftArm);
        Glide.with(this).load(R.drawable.body_07_33_11).into(ivRightFinger);
        Glide.with(this).load(R.drawable.body_08_17_33).into(ivRightLeg);
        Glide.with(this).load(R.drawable.body_09_17_33).into(ivLeftLeg);
        Glide.with(this).load(R.drawable.body_10_33_11).into(ivLeftFinger);
        Glide.with(this).load(R.drawable.body_11_33_43).into(ivBody11);
        Glide.with(this).load(R.drawable.body_12_17_10).into(ivRightToe);
        Glide.with(this).load(R.drawable.body_13_17_10).into(ivLeftToe);
        Glide.with(this).load(R.drawable.body_14_33_43).into(ivBody14);

        Glide.with(this).load(R.drawable.face).into(ivSolidFace);
        Glide.with(this).load(R.drawable.body).into(ivSolidBody);
        Glide.with(this).load(R.drawable.right_arm).into(ivSolidRightArm);
        Glide.with(this).load(R.drawable.left_arm).into(ivSolidLeftArm);
        Glide.with(this).load(R.drawable.right_finger).into(ivSolidRightFinger);
        Glide.with(this).load(R.drawable.left_finger).into(ivSolidLeftFinger);
        Glide.with(this).load(R.drawable.right_foot).into(ivSolidRightLeg);
        Glide.with(this).load(R.drawable.left_foot).into(ivSolidLeftLeg);
        Glide.with(this).load(R.drawable.right_toe).into(ivSolidRightToe);
        Glide.with(this).load(R.drawable.left_toe).into(ivSolidLeftToe);

        Glide.with(this).load(R.drawable.back_01_100_15).into(ivBack1);
        Glide.with(this).load(R.drawable.back_02_33_40).into(ivBack2);
        Glide.with(this).load(R.drawable.back_03_34_40).into(ivBackBody);
        Glide.with(this).load(R.drawable.back_04_33_40).into(ivBack4);
        Glide.with(this).load(R.drawable.back_05_33_35).into(ivBack5);
        Glide.with(this).load(R.drawable.back_06_17_35).into(ivBackLeftLeg);
        Glide.with(this).load(R.drawable.back_07_17_35).into(ivBackRightLeg);
        Glide.with(this).load(R.drawable.back_08_33_35).into(ivBack8);
        Glide.with(this).load(R.drawable.back_09_100_10).into(ivBack9);

        Glide.with(this).load(R.drawable.back_solid_body).into(ivSolidBackBody);
        Glide.with(this).load(R.drawable.back_solid_left_leg).into(ivSolidBackLeftLeg);
        Glide.with(this).load(R.drawable.back_solid_right_leg).into(ivSolidBackRightLeg);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.iv_pic_1:
                presenter.showPhoto(0);
                break;
            case R.id.iv_pic_2:
                presenter.showPhoto(1);
                break;
            case R.id.iv_pic_3:
                presenter.showPhoto(2);
                break;
            case R.id.iv_pic_4:
                presenter.showPhoto(3);
                break;
            case R.id.btn_edit:
                Intent intent = new Intent(getActivity(), SymptomRecordActivity.class);
                Bundle data = new Bundle();
                data.putInt(Define.ExtrasKey.SYMPTOM_ID, getArguments().getInt(Define.ExtrasKey.SYMPTOM_ID));
                intent.putExtras(data);
                startActivity(intent);
                break;
            case R.id.btn_delete:
                showConfirmDeleteRecordAlert();
                break;
            default:
                break;
        }
    }

    @Override
    public void setStartDate(Date date) {
        if (date != null) {
            tvStartDate.setGravity(Gravity.CENTER);
            tvStartDate.setText(TimeUtil.getTime(TimeUtil.FORMAT_2, date.getTime(), Locale.JAPAN));
        }
    }

    @Override
    public void setEndDate(Date date) {
        if (date != null) {
            tvEndDate.setGravity(Gravity.CENTER);
            tvEndDate.setText(TimeUtil.getTime(TimeUtil.FORMAT_2, date.getTime(), Locale.JAPAN));
        }
    }

    @Override
    public void setPhoto(int position, Photo photo) {
        ImageView targetPhoto;
        TextView targetPhotoDate;
        switch (position) {
            case 1:
                targetPhoto = ivPic2;
                targetPhotoDate = tvPhotoDate2;
                break;
            case 2:
                targetPhoto = ivPic3;
                targetPhotoDate = tvPhotoDate3;
                break;
            case 3:
                targetPhoto = ivPic4;
                targetPhotoDate = tvPhotoDate4;
                break;
            default:
                targetPhoto = ivPic1;
                targetPhotoDate = tvPhotoDate1;
                break;
        }
        if (photo != null) {
            Glide.with(this).load(photo.getPath()).into(targetPhoto);
            targetPhotoDate.setText(TimeUtil.getTime(TimeUtil.FORMAT_3, photo.getCreatedTime()));
        } else {
            targetPhoto.setImageResource(position == 0
                    ? R.drawable.ic_empty_pic_1 : position == 1
                    ? R.drawable.ic_empty_pic_2 : position == 2
                    ? R.drawable.ic_empty_pic_3 : R.drawable.ic_empty_pic_4);
            targetPhotoDate.setText(R.string.sr_pic_date_empty);
        }
    }

    @Override
    public void showPhoto(String photoPath) {
        new ViewPhotoDialog.Builder(getActivity().getSupportFragmentManager(), photoPath).build().show();
    }

    @Override
    public void setTreatment(boolean isTreatment) {
        tvTreatment.setText(isTreatment ? getString(R.string.sr_treatment_yes) : getString(R.string.sr_treatment_no));
    }

    @Override
    public void setPainLevel(int level) {
        sbPain.setProgress(level);
    }

    @Override
    public void setMemo(String memo) {
        tvMemo.setText(memo);
    }

    @Override
    public void showConfirmDeleteRecordAlert() {
        new AppAlertDialog.Builder(getActivity().getSupportFragmentManager())
                .visibleCloseButton(true)
                .message(getString(R.string.rv_alert_delete_symptom))
                .setOnActionListener(new AppAlertDialog.OnActionListener() {
                    @Override
                    public void onConfirm() {
                        presenter.removeRecord();
                    }

                    @Override
                    public void onCancel() {
                        //implement method
                    }
                })
                .build()
                .show();
        HAEApplication.getInstance().trackScreenView(getString(R.string.screen_delete_dialog));
    }

    /**
     * solid part of body
     *
     * @param partOfBody 's id
     * @param isSolid    = true -> solid
     */
    @Override
    public void solidPart(int partOfBody, boolean isSolid) {
        switch (partOfBody) {
            case Define.BodyPart.FACE:
                ivSolidFace.setVisibility(isSolid ? View.VISIBLE : View.GONE);
                break;
            case Define.BodyPart.BODY:
                ivSolidBody.setVisibility(isSolid ? View.VISIBLE : View.GONE);
                break;
            case Define.BodyPart.RIGHT_ARM:
                ivSolidRightArm.setVisibility(isSolid ? View.VISIBLE : View.GONE);
                break;
            case Define.BodyPart.LEFT_ARM:
                ivSolidLeftArm.setVisibility(isSolid ? View.VISIBLE : View.GONE);
                break;
            case Define.BodyPart.RIGHT_FINGER:
                ivSolidRightFinger.setVisibility(isSolid ? View.VISIBLE : View.GONE);
                break;
            case Define.BodyPart.LEFT_FINGER:
                ivSolidLeftFinger.setVisibility(isSolid ? View.VISIBLE : View.GONE);
                break;
            case Define.BodyPart.RIGHT_LEG:
                ivSolidRightLeg.setVisibility(isSolid ? View.VISIBLE : View.GONE);
                break;
            case Define.BodyPart.LEFT_LEG:
                ivSolidLeftLeg.setVisibility(isSolid ? View.VISIBLE : View.GONE);
                break;
            case Define.BodyPart.RIGHT_TOE:
                ivSolidRightToe.setVisibility(isSolid ? View.VISIBLE : View.GONE);
                break;
            case Define.BodyPart.LEFT_TOE:
                ivSolidLeftToe.setVisibility(isSolid ? View.VISIBLE : View.GONE);
                break;
            case Define.BodyPart.BODY_BACK:
                ivSolidBackBody.setVisibility(isSolid ? View.VISIBLE : View.GONE);
                break;
            case Define.BodyPart.RIGHT_LEG_BACK:
                ivSolidBackRightLeg.setVisibility(isSolid ? View.VISIBLE : View.GONE);
                break;
            case Define.BodyPart.LEFT_LEG_BACK:
                ivSolidBackLeftLeg.setVisibility(isSolid ? View.VISIBLE : View.GONE);
                break;
            default:
                break;
        }
    }

    @Override
    public void setBodyTitle(String title) {
        tvLabelBody.setText(title);
    }

    @Override
    public void removeSuccess(Calendar calendar) {
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).navigateToCalendar(getArguments().getInt(Define.ExtrasKey.CALLER_FLAG), calendar);
        }
    }
}

