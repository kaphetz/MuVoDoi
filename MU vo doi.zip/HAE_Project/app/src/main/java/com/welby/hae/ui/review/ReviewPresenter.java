package com.welby.hae.ui.review;

import com.welby.hae.data.db.helper.RealmManager;
import com.welby.hae.data.db.model.Symptom;
import com.welby.hae.model.Photo;
import com.welby.hae.model.SymptomItem;
import com.welby.hae.ui.base.BasePresenter;
import com.welby.hae.utils.Define;
import com.welby.hae.utils.RLog;

import java.util.Calendar;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by WelbyDev.
 */

class ReviewPresenter extends BasePresenter {
    private ReviewView reviewView;
    private Symptom symptom;

    ReviewPresenter(ReviewView reviewView, int symptomId) {
        this.reviewView = reviewView;
        this.symptom = RealmManager.getRealmManager().getSymptomHelper().getSymptomRecord(symptomId);
        initView();
    }

    public void initView() {
        if (symptom == null) {
            RLog.d("null symptom");
            return;
        }

        reviewView.setStartDate(symptom.getSeizureStartDate());

        reviewView.setEndDate(symptom.getSeizureEndDate());

        for (int i = 0; i < symptom.getSymptomPhotos().size(); i++) {
            Photo photo = new Photo(symptom.getSymptomPhotos().get(i).getFileName(), symptom.getSymptomPhotos().get(i).getCreated().getTime());
            reviewView.setPhoto(i, photo);
        }

        reviewView.setPainLevel(symptom.getPainLevel());

        reviewView.setTreatment(symptom.getTreatmentFlag() == 1);

        reviewView.setMemo(symptom.getMemo());

        solidPart();
    }

    /**
     * solid color and show the name of the chosen part
     */
    private void solidPart() {
        StringBuilder bodyTitle = new StringBuilder();
        List<SymptomItem> symptomItemList = RealmManager.getRealmManager().getSymptomHelper().getSymptomPartDetails(symptom.getId());
        Set<Integer> solidParts = new LinkedHashSet<>();
        for (SymptomItem item : symptomItemList) {
            if (item.isChosen()) {
                solidParts.add(item.getPartId());
                if (bodyTitle.length() > 0) {
                    bodyTitle.append(Define.STR_COMMAND_JP).append(item.getName()).append(getPartOfBodySide(item.getPartId()));
                } else {
                    bodyTitle.append(item.getName()).append(getPartOfBodySide(item.getPartId()));
                }
            }
        }
        reviewView.setBodyTitle(bodyTitle.toString());
        for (int partOfBody = Define.BodyPart.MIN; partOfBody <= Define.BodyPart.MAX; partOfBody++) {
            boolean isSolid = false;
            for (Integer solidPart : solidParts) {
                if (partOfBody == solidPart) {
                    isSolid = true;
                    break;
                }
            }
            reviewView.solidPart(partOfBody, isSolid);
        }
    }

    private String getPartOfBodySide(int partId) {
        switch (partId) {
            case Define.BodyPart.FACE:
                return Define.STR_EMPTY;
            case Define.BodyPart.BODY:
                return Define.STR_EMPTY;
            case Define.BodyPart.LEFT_ARM:
                return Define.STR_BODY_LEFT;
            case Define.BodyPart.RIGHT_ARM:
                return Define.STR_BODY_RIGHT;
            case Define.BodyPart.LEFT_FINGER:
                return Define.STR_BODY_LEFT;
            case Define.BodyPart.RIGHT_FINGER:
                return Define.STR_BODY_RIGHT;
            case Define.BodyPart.LEFT_TOE:
                return Define.STR_BODY_LEFT;
            case Define.BodyPart.RIGHT_TOE:
                return Define.STR_BODY_RIGHT;
            case Define.BodyPart.LEFT_LEG:
                return Define.STR_BODY_LEFT;
            case Define.BodyPart.RIGHT_LEG:
                return Define.STR_BODY_RIGHT;
            default:
                return Define.STR_EMPTY;
        }
    }

    void showPhoto(int position) {
        if (position < symptom.getSymptomPhotos().size()) {
            reviewView.showPhoto(symptom.getSymptomPhotos().get(position).getFileName());
        }
    }

    void removeRecord() {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(symptom.getSeizureStartDate());
        RealmManager.getRealmManager().getSymptomHelper().removeSymptomRecord(symptom.getId());
        reviewView.removeSuccess(calendar);
    }
}
