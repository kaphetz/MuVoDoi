package com.welby.hae.ui.review;

import com.welby.hae.model.Photo;
import com.welby.hae.ui.base.BaseView;

import java.util.Calendar;
import java.util.Date;

/**
 * Created by WelbyDev.
 */

interface ReviewView extends BaseView {
    void setStartDate(Date date);

    void setEndDate(Date date);

    void setPhoto(int position, Photo photo);

    void showPhoto(String photoPath);

    void setTreatment(boolean isTreatment);

    void setPainLevel(int level);

    void setMemo(String memo);

    void showConfirmDeleteRecordAlert();

    void solidPart(int partOfBody, boolean isSolid);

    void setBodyTitle(String title);

    void removeSuccess(Calendar calendar);
}
