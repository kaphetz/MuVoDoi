package com.welby.hae.ui.setting;

import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import com.welby.hae.R;
import com.welby.hae.ui.base.BaseActivity;
import com.welby.hae.utils.TextUtil;

import me.biubiubiu.justifytext.library.JustifyTextView;

public class BackupActivity extends BaseActivity implements View.OnClickListener {
    private Toolbar toolbar;
    private ImageButton btnClose;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        lastVisibleActivity = BackupActivity.class.getName();
        initView();
        initData();
    }

    @Override
    public void initView() {
        setContentView(R.layout.activity_backup);
        toolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(toolbar);
        btnClose = toolbar.findViewById(R.id.btn_close_backup);

    }

    @Override
    public void initData() {
        btnClose.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_close_backup:
                finish();
        }
    }
}
