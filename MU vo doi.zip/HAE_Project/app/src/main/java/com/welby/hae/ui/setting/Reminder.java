package com.welby.hae.ui.setting;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;

import java.util.Calendar;

/**
 * Created by Welby
 */

public class Reminder {
    private Context context;

    public Reminder(Context context) {
        this.context = context;
    }

    /**
     * notify 18:00 every day
     */
    public void create() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 18);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        if(System.currentTimeMillis() >= calendar.getTimeInMillis()){
            calendar.add(Calendar.HOUR_OF_DAY, 24);
        }

        JobScheduler jobScheduler = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        jobScheduler.cancelAll();

        ComponentName serviceComponent = new ComponentName(context, ShowNotificationService.class);
        JobInfo.Builder builder = new JobInfo.Builder(0, serviceComponent);
        builder.setMinimumLatency(calendar.getTimeInMillis() - System.currentTimeMillis());
        builder.setOverrideDeadline(calendar.getTimeInMillis() - System.currentTimeMillis() + 90000); //15 minutes = 90000ms

        jobScheduler.schedule(builder.build());
    }
}
