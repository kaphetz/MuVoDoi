package com.welby.hae.ui.setting;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.welby.hae.HAEApplication;
import com.welby.hae.R;
import com.welby.hae.data.db.helper.RealmManager;
import com.welby.hae.data.db.model.Symptom;
import com.welby.hae.ui.symptomrecord.SymptomRecordActivity;
import com.welby.hae.utils.Define;
import com.welby.hae.utils.Field;
import com.welby.hae.utils.RLog;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Created by Welby Dev.
 */

public class ShowNotificationService extends JobService {

    @Override
    public boolean onStartJob(JobParameters jobParameters) {

        if (isSessionExpired()) {
            new Reminder(getApplicationContext()).create(); // reschedule the job
            return true;
        }

        title = getString(R.string.title_notification);

        List<Symptom> symptomList = RealmManager.with(getApplication()).getSymptomHelper().getJustCreatedRecords();
        for (Symptom symptom : symptomList) {
            final int symptomId = symptom.getId();
            boolean needNotify = false;
            /*
            if (symptom.getTreatmentFlag() == 0 && symptom.getSymptomPartRelations().isEmpty()) {
                description = getString(R.string.type_drug_position);
                needNotify = true;
            } else if (symptom.getTreatmentFlag() == 0) {
                description = getString(R.string.type_drug);
                needNotify = true;
            } else if (symptom.getSymptomPartRelations().isEmpty()) {
                description = getString(R.string.type_position);
                needNotify = true;
            }
            */
            if (symptom.getSymptomPartRelations().isEmpty()) {
                description = getString(R.string.type_position);
                needNotify = true;
            }
            if (needNotify) {
                RLog.d("notify " + delayTime);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        showNotification(title, description, symptomId);
                    }
                }, getDelayTime());
            }

        }

        new Reminder(getApplicationContext()).create(); // reschedule the job

        return true;
    }

    @Override
    public boolean onStopJob(JobParameters jobParameters) {
        return true;
    }

    private final static AtomicInteger c = new AtomicInteger(0);

    private static int getID() {
        return c.incrementAndGet();
    }

    private final static AtomicLong delayTime = new AtomicLong(0);

    private static long getDelayTime() {
        return delayTime.getAndAdd(500);
    }

    private String title = Define.STR_EMPTY;
    private String description = Define.STR_EMPTY;

    void showNotification(String title, String description, int symptomId) {
        int notificationId = getID();
        cancelNotification(notificationId);
        // Send data to SymptomRecordActivity
        Intent symptomRecordIntent = new Intent(this, SymptomRecordActivity.class);
        symptomRecordIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        Bundle data = new Bundle();
        data.putInt(Define.ExtrasKey.SYMPTOM_ID, symptomId);
        data.putString(Define.ExtrasKey.CALLER_FLAG, ShowNotificationService.class.getName());
        symptomRecordIntent.putExtras(data);

        // Open SymptomRecordActivity
        PendingIntent pIntent = PendingIntent.getActivity(this, notificationId, symptomRecordIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);

        // Create Notification Manager
        NotificationManager notificationmanager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        //Create Notification using NotificationCompat.Builder
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel mChannel = new NotificationChannel(getString(R.string.app_name), getString(R.string.app_name), NotificationManager.IMPORTANCE_HIGH);
            notificationmanager.createNotificationChannel(mChannel);
        }
        Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, getString(R.string.app_name))
                .setSmallIcon(R.drawable.ic_notification_hae)
                .setTicker(description)
                .setContentTitle(title)
                .setSound(alarmSound)
                .setContentText(description)
                .setContentIntent(pIntent)
                .setChannelId(getString(R.string.app_name))
                .setAutoCancel(true);

        // Build Notification with Notification Manager
        notificationmanager.notify(notificationId, builder.build());

        HAEApplication.getInstance().trackScreenView(getString(R.string.screen_local_notification));
    }

    /**
     * if notification delayed > 15 minutes -> don't push
     */
    private boolean isSessionExpired() {
        Calendar remindTime = Calendar.getInstance();
        remindTime.set(Calendar.HOUR_OF_DAY, 18);
        remindTime.set(Calendar.MINUTE, 0);
        remindTime.set(Calendar.SECOND, 0);
        remindTime.set(Calendar.MILLISECOND, 0);
        long delayedTime = System.currentTimeMillis() - remindTime.getTimeInMillis();
        return delayedTime > 900000 || System.currentTimeMillis() < remindTime.getTimeInMillis(); //15 minutes = 900000 ms
    }

    private void cancelNotification(int notifyId) {
        NotificationManager notificationmanager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        notificationmanager.cancel(notifyId);
    }
}
