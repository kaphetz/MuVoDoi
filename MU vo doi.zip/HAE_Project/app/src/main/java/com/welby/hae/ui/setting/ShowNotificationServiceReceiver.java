package com.welby.hae.ui.setting;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Created by Welby Dev.
 */

public class ShowNotificationServiceReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        new Reminder(context).create();
    }
}
