package com.welby.hae.ui.setting;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.welby.hae.HAEApplication;
import com.welby.hae.R;
import com.welby.hae.data.db.helper.RealmManager;
import com.welby.hae.ui.setting.guide.GuideActivity;
import com.welby.hae.utils.SharedPref;

import static com.welby.hae.utils.Define.SharedPreferenceKey.ACCEPT_TERM_OF_SERVICE;

public class StartActivity extends AppCompatActivity implements View.OnClickListener {
    private Button btnAccept;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
        //toolbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(toolbar);
        ImageButton btnClose = toolbar.findViewById(R.id.btn_close_startActivity);

        btnAccept = (Button) findViewById(R.id.btn_accept_term);
        if (RealmManager.getRealmManager().getRealm().isEmpty()) {
            // show btn accept
            btnAccept.setVisibility(View.VISIBLE);
            //hide btn close
            btnClose.setVisibility(View.GONE);
        } else {
            // hide btn accept
            btnAccept.setVisibility(View.GONE);
            //show btn close
            btnClose.setVisibility(View.VISIBLE);
        }
        // btn accept
        btnAccept.setOnClickListener(this);
        btnClose.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_accept_term:
                HAEApplication.getInstance().trackEvent(getString(R.string.tracking_start_screen_accept_ev));;
                btnAccept.setClickable(false);
                SharedPref.getInstance().putBoolean(ACCEPT_TERM_OF_SERVICE, true);
                Intent intent = new Intent(StartActivity.this, GuideActivity.class);
                startActivity(intent);
                finish();
                break;
            case R.id.btn_close_startActivity:
                finish();
                break;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
            HAEApplication.getInstance().trackScreenView(getString(R.string.tracking_start_screen));
    }
}
