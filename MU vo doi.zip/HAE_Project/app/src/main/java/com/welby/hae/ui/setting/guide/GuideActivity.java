package com.welby.hae.ui.setting.guide;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.welby.hae.HAEApplication;
import com.welby.hae.R;
import com.welby.hae.data.db.helper.RealmManager;
import com.welby.hae.ui.base.BaseActivity;
import com.welby.hae.ui.custom.DotIndicator;
import com.welby.hae.ui.main.MainActivity;

/**
 * guide screen
 * Created by WelbyDev on 29-Sep-17.
 */
public class GuideActivity extends BaseActivity implements View.OnClickListener {
    public static final int NUMBER_OF_PAGE = 4;
    private Button btnSkip;
    private ImageButton btnClose;

    ViewPager pagerGuideSliders;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        lastVisibleActivity = GuideActivity.class.getName();
        initView();
        initData();
    }

    @Override
    public void initData() {
        if (RealmManager.getRealmManager().getRealm().isEmpty()) {
            btnClose.setVisibility(View.GONE);
            btnSkip.setVisibility(View.VISIBLE);
        } else {
            btnClose.setVisibility(View.VISIBLE);
            btnSkip.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public void initView() {
        setContentView(R.layout.activity_guide);

        final DotIndicator dotIndicator = (DotIndicator) findViewById(R.id.indicator);

        // View page
        pagerGuideSliders = (ViewPager) findViewById(R.id.pg_slide_page);
        pagerGuideSliders.setAdapter(new GuidePagerAdapter(getSupportFragmentManager(), NUMBER_OF_PAGE));
        pagerGuideSliders.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                dotIndicator.moveWithViewPager(position, positionOffset);
            }

            @Override
            public void onPageSelected(int position) {
                setViewArrow();
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });


        // Toolbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(toolbar);
        btnSkip = (Button) findViewById(R.id.btn_skip_guide);
        btnClose = toolbar.findViewById(R.id.btn_close_guide);
        // Skip button
        findViewById(R.id.btn_skip_guide).setOnClickListener(this);
        // Close image button
        toolbar.findViewById(R.id.btn_close_guide).setOnClickListener(this);
        // Next guide
        findViewById(R.id.btn_arrow_previous).setOnClickListener(this);
        findViewById(R.id.btn_arrow_next).setOnClickListener(this);

    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_skip_guide:
                HAEApplication.getInstance().trackEvent(getString(R.string.tracking_guide_screen_skip_ev));
                btnSkip.setClickable(false);
                RealmManager.getRealmManager().initData();
                startActivity(new Intent(GuideActivity.this, MainActivity.class));
                finish();
                break;
            case R.id.btn_close_guide:
                finish();
                break;
//            case R.id.btn_next_slide:
//                int currentPage = pagerGuideSliders.getCurrentItem();
//                int nextPage = currentPage + 1;
//                if (nextPage < NUMBER_OF_PAGE) {
//                    pagerGuideSliders.setCurrentItem(nextPage);
//                } else if (firstStart) {
//                    startActivity(new Intent(GuideActivity.this, MainActivity.class));
//                    finish();
//                } else {
//                    finish();
//                }
//                break;
            case R.id.btn_arrow_next:
                if (pagerGuideSliders.getCurrentItem() < NUMBER_OF_PAGE) {
                    pagerGuideSliders.setCurrentItem(pagerGuideSliders.getCurrentItem() + 1);
                }
                break;
            case R.id.btn_arrow_previous:
                if (pagerGuideSliders.getCurrentItem() < NUMBER_OF_PAGE) {
                    pagerGuideSliders.setCurrentItem(pagerGuideSliders.getCurrentItem() - 1);
                }
                break;
        }
    }

    public void setViewArrow() {
        switch (pagerGuideSliders.getCurrentItem()) {
            case 0:
                findViewById(R.id.btn_arrow_previous).setVisibility(View.GONE);
                findViewById(R.id.btn_arrow_next).setVisibility(View.VISIBLE);
                break;
            case 1:
                findViewById(R.id.btn_arrow_previous).setVisibility(View.VISIBLE);
                findViewById(R.id.btn_arrow_next).setVisibility(View.VISIBLE);
                break;
            case 2:
                findViewById(R.id.btn_arrow_previous).setVisibility(View.VISIBLE);
                findViewById(R.id.btn_arrow_next).setVisibility(View.VISIBLE);
                break;
            case 3:
                findViewById(R.id.btn_arrow_previous).setVisibility(View.VISIBLE);
                findViewById(R.id.btn_arrow_next).setVisibility(View.GONE);
                break;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
    }
}
