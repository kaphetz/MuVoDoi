package com.welby.hae.ui.setting.guide;


import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.welby.hae.HAEApplication;
import com.welby.hae.R;
import com.welby.hae.data.db.helper.RealmManager;
import com.welby.hae.utils.TextUtil;

/**
 * Guide page
 * Created by WelbyDev on 29-Sep-17.
 */
public class GuidePageFragment extends Fragment {
    private static final String ARG_PARAM1 = "param1";

    private int pageIndex;


    public GuidePageFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param pageIndex Page index
     * @return A new instance of fragment GuidePageFragment.
     */
    public static GuidePageFragment newInstance(int pageIndex) {
        GuidePageFragment fragment = new GuidePageFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_PARAM1, pageIndex);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            pageIndex = getArguments().getInt(ARG_PARAM1);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_guide_page, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        TextView text1 = view.findViewById(R.id.tv_title);
        TextView text2 = view.findViewById(R.id.textView2);
        TextView text3 = view.findViewById(R.id.textView3);
        ImageView iv_pic = view.findViewById(R.id.iv_pic);
        switch (pageIndex) {
            case 0:
                ((GuideActivity) getActivity()).setViewArrow();
                text1.setText(Html.fromHtml(getActivity().getString(R.string.guide_screen_text_1_1)));
                text2.setText(Html.fromHtml(getActivity().getString(R.string.guide_screen_text_1_2)));
                text3.setText(String.valueOf(getActivity().getString(R.string.guide_screen_text_1_3)));
                iv_pic.setImageResource(R.drawable.ic_guide_1);
                break;
            case 1:
                text1.setText(Html.fromHtml(getActivity().getString(R.string.guide_screen_text_2_1)));
                text2.setVisibility(View.INVISIBLE);
                text3.setText(String.valueOf(getActivity().getString(R.string.guide_screen_text_2_3)));
                text3.setTypeface(null, Typeface.BOLD);
                iv_pic.setImageResource(R.drawable.ic_guide_2);
                break;
            case 2:
                text1.setText(Html.fromHtml(getActivity().getString(R.string.guide_screen_text_3_1)));
                text2.setVisibility(View.INVISIBLE);
                text3.setVisibility(View.INVISIBLE);
                iv_pic.setImageResource(R.drawable.ic_guide_3);
                break;
            case 3:
                text1.setText(Html.fromHtml(getActivity().getString(R.string.guide_screen_text_4_1)));
                text2.setVisibility(View.INVISIBLE);
                if (RealmManager.getRealmManager().getRealm().isEmpty()) {
                    text3.setText(getString(R.string.guide_screen_text_4_3_start));
                    text3.setTypeface(null, Typeface.BOLD);
                    text3.setBackgroundResource(R.drawable.bg_white_stroke_black);
                } else {
                    text3.setText(TextUtil.fromHtml(getActivity().getString(R.string.guide_screen_text_4_3)));
                }
                iv_pic.setImageResource(R.drawable.ic_guide_4);
                break;
        }
    }

    @Override
    public void onResume() {
        HAEApplication.getInstance().trackScreenView(getString(R.string.tracking_guide_screen));
        super.onResume();
    }
}
