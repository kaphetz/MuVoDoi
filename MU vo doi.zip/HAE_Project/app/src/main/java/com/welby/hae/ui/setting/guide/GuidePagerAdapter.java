package com.welby.hae.ui.setting.guide;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

/**
 * Created by Welby Dev on 10/1/17.
 */

public class GuidePagerAdapter extends FragmentStatePagerAdapter {

    private int numberOfPage;

    public GuidePagerAdapter(FragmentManager fm, int numberOfPage) {
        super(fm);
        this.numberOfPage = numberOfPage;
    }

    @Override
    public Fragment getItem(int position) {
        return GuidePageFragment.newInstance(position);
    }

    @Override
    public int getCount() {
        return numberOfPage;
    }
}
