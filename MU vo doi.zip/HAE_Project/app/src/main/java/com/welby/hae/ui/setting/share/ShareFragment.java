package com.welby.hae.ui.setting.share;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.welby.hae.HAEApplication;
import com.welby.hae.R;
import com.welby.hae.ui.base.BaseFragment;
import com.welby.hae.utils.Define;
import com.welby.hae.utils.ToastUtil;

/**
 * Screen share HAE
 * Created by WelbyDev.
 */

public class ShareFragment extends BaseFragment implements View.OnClickListener, ShareView {
    private TextView contentMessage;

    private SharePresenter presenter;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_share_hae, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
        initData();
    }

    @Override
    public void onResume() {
        super.onResume();
        setLastVisibleFragment(ShareFragment.class.getName());
        HAEApplication.getInstance().trackScreenView(getString(R.string.tracking_share_screen));
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public void initData() {
        presenter = new SharePresenter(this,getActivity());
    }

    @Override
    public void initView(View view) {

        ImageView btnLineMessage = view.findViewById(R.id.btnLineMessage);
        LinearLayout btnMailMessage = view.findViewById(R.id.btnMailMessage);
        LinearLayout btnCopyMessage = view.findViewById(R.id.btnCopyMessage);
        ImageView btnLineVideo = view.findViewById(R.id.btnLineUrlVideo);
        TextView btnMailVideo = view.findViewById(R.id.btnMailUrlVideo);
        TextView btnMailUrlVideo2 = view.findViewById(R.id.btnMailUrlVideo2);
        ImageView btnLineUrlVideo2 = view.findViewById(R.id.btnLineUrlVideo2);
        contentMessage = view.findViewById(R.id.content_message);
        contentMessage.setText(Html.fromHtml(getActivity().getString(R.string.share_hae_message)));
        LinearLayout viewLinkURL1 = view.findViewById(R.id.viewLinkURL1);
        LinearLayout viewLinkURL2 = view.findViewById(R.id.viewLinkURL2);

        viewLinkURL1.setOnClickListener(this);
        viewLinkURL2.setOnClickListener(this);
        btnLineMessage.setOnClickListener(this);
        btnMailMessage.setOnClickListener(this);
        btnCopyMessage.setOnClickListener(this);
        btnLineVideo.setOnClickListener(this);
        btnMailVideo.setOnClickListener(this);
        btnMailUrlVideo2.setOnClickListener(this);
        btnLineUrlVideo2.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.viewLinkURL1:
                HAEApplication.getInstance().trackEvent(getString(R.string.tracking_share_screen_movie_1minute_ev));
                viewURL(Define.URL_1_MINUTE_VIDEO);
                break;
            case R.id.viewLinkURL2:
                HAEApplication.getInstance().trackEvent(getString(R.string.tracking_share_screen_movie_explain_ev));
                viewURL(Define.URL_EXPLAIN_VIDEO);
                break;
            case R.id.btnMailUrlVideo:
                HAEApplication.getInstance().trackEvent(getString(R.string.tracking_share_screen_movie_1minute_share_mail_ev));
                presenter.sendMessageToMail(Define.URL_1_MINUTE_VIDEO);
                break;
            case R.id.btnLineUrlVideo:
                HAEApplication.getInstance().trackEvent(getString(R.string.tracking_share_screen_movie_1minute_share_line_ev));
                presenter.sendMessageToLINE(Define.URL_1_MINUTE_VIDEO);
                break;
            case R.id.btnLineUrlVideo2:
                HAEApplication.getInstance().trackEvent(getString(R.string.tracking_share_screen_movie_explain_share_line_ev));
                presenter.sendMessageToLINE(Define.URL_EXPLAIN_VIDEO);
                break;
            case R.id.btnMailUrlVideo2:
                HAEApplication.getInstance().trackEvent(getString(R.string.tracking_share_screen_movie_explain_share_mail_ev));
                presenter.sendMessageToMail(Define.URL_EXPLAIN_VIDEO);
                break;
            case R.id.btnCopyMessage:
                HAEApplication.getInstance().trackEvent(getString(R.string.tracking_share_screen_text_share_copy_ev));
                presenter.copyMessage(contentMessage.getText().toString());
                break;
            case R.id.btnMailMessage:
                HAEApplication.getInstance().trackEvent(getString(R.string.tracking_share_screen_text_share_mail_ev));
                presenter.sendMessageToMail(contentMessage.getText().toString());
                break;
            case R.id.btnLineMessage:
                HAEApplication.getInstance().trackEvent(getString(R.string.tracking_share_screen_text_share_line_ev));
                presenter.sendMessageToLINE(contentMessage.getText().toString());
                break;
        }
    }

    /**
     * open browser link url
     *
     * @param URL: link web
     */
    private void viewURL(String URL) {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(URL));
        startActivity(i);
    }

    @Override
    public void sendMessageToLineSuccess(String content) {
        Intent sharingIntent = new Intent(Intent.ACTION_SEND);
        sharingIntent.setPackage(Define.PACKAGE_APP_LINE);
        sharingIntent.setType(getString(R.string.text_plain));
        sharingIntent.putExtra(Intent.EXTRA_TEXT, content);
        startActivity(Intent.createChooser(sharingIntent, getString(R.string.line)));
    }

    @Override
    public void sendMessageToLineFailed() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.market) + Define.PACKAGE_APP_LINE)));
        } catch (android.content.ActivityNotFoundException anfe) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.google_play) + Define.PACKAGE_APP_LINE)));
        }
    }

    @Override
    public void sendMessageToAppMail(String content, boolean installedGmail) {
        Intent sharingIntent = new Intent(Intent.ACTION_SEND);
        if (installedGmail) {
            sharingIntent.setPackage(Define.PACKAGE_APP_GMAIL);
        }
        sharingIntent.putExtra(Intent.EXTRA_EMAIL, new String[] {  });
        sharingIntent.setType(getString(R.string.text_plain));
        sharingIntent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.subject_share_hae));//Subject
        sharingIntent.putExtra(Intent.EXTRA_TEXT, content);
        startActivity(Intent.createChooser(sharingIntent, getString(R.string.email)));
    }

    @Override
    public void copyMessage() {
        ToastUtil.showToast(getActivity(),getString(R.string.copied));
    }
}
