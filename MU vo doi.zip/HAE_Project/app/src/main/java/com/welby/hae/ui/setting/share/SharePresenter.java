package com.welby.hae.ui.setting.share;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.support.annotation.NonNull;
import android.text.TextUtils;

import com.welby.hae.R;
import com.welby.hae.ui.base.BasePresenter;
import com.welby.hae.utils.Define;

/**
 * Share Presenter
 * Created by WelbyDev.
 */

class SharePresenter extends BasePresenter {
    private ShareView shareView;
    private Context context;
    private boolean installed;

    SharePresenter(ShareView shareView, Context context) {
        this.shareView = shareView;
        this.context = context;
    }

    /**
     * copy text to clipboard
     *
     * @param content content to copy
     */
    void copyMessage(@NonNull String content) {
        ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText(context.getString(R.string.copied), content);
        if (clipboard != null) {
            clipboard.setPrimaryClip(clip);
            shareView.copyMessage();
        }
    }

    /**
     * Send content message go Line
     *
     * @param content: content message
     */
    void sendMessageToLINE(String content) {
        installed = appInstalledOrNot(Define.PACKAGE_APP_LINE);
        if (installed) {
            shareView.sendMessageToLineSuccess(content);
        } else {
            shareView.sendMessageToLineFailed();
        }
    }

    /**
     * Send content message go Mail
     *
     * @param content: content message
     */
    void sendMessageToMail(String content) {
        installed = appInstalledOrNot(Define.PACKAGE_APP_GMAIL);
        shareView.sendMessageToAppMail(content, installed);
    }

    /**
     * Check if application is installed
     *
     * @param packageName package to check
     * @return true = installed, false = not installed
     */
    private boolean appInstalledOrNot(String packageName) {
        PackageManager pm = context.getPackageManager();
        boolean app_installed;
        try {
            pm.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES);
            app_installed = true;
        } catch (PackageManager.NameNotFoundException e) {
            app_installed = false;
        }
        return app_installed;
    }
}
