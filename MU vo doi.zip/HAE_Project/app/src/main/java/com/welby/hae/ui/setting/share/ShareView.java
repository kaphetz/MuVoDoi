package com.welby.hae.ui.setting.share;

import com.welby.hae.ui.base.BaseView;

/**
 *  Share HAE view
 * Created by WelbyDev.
 */

interface ShareView extends BaseView {
    void sendMessageToLineSuccess(String content);
    void sendMessageToLineFailed();
    void sendMessageToAppMail(String content,boolean installed);
    void copyMessage();
}
