package com.welby.hae.ui.start;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;

import com.welby.hae.HAEApplication;
import com.welby.hae.R;
import com.welby.hae.data.db.helper.RealmManager;
import com.welby.hae.ui.main.MainActivity;
import com.welby.hae.ui.setting.StartActivity;


/**
 * Splash screen
 * Created by WelbyDev on 29-Sep-17.
 */
public class SplashActivity extends AppCompatActivity {
    public static final int DELAY_TIME = 3000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_splash);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Class targetClass;
                if (RealmManager.getRealmManager().getRealm().isEmpty()) {
                    targetClass = StartActivity.class;
                } else {
                    targetClass = MainActivity.class;
                }
                startActivity(new Intent(SplashActivity.this, targetClass));
                finish();
            }
        }, DELAY_TIME);
    }

    @Override
    protected void onResume() {
        HAEApplication.getInstance().trackScreenView(getString(R.string.tracking_splash_screen));
        super.onResume();
    }
}
