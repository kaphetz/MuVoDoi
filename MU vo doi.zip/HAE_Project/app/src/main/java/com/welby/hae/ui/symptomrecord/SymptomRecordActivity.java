package com.welby.hae.ui.symptomrecord;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.IdRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.github.florent37.singledateandtimepicker.dialog.SingleDateAndTimePickerDialog;
import com.welby.hae.HAEApplication;
import com.welby.hae.R;
import com.welby.hae.model.Photo;
import com.welby.hae.ui.base.BaseActivity;
import com.welby.hae.ui.custom.ClickHandler;
import com.welby.hae.ui.custom.SymptomRecordShowCase;
import com.welby.hae.ui.dialog.AppAlertDialog;
import com.welby.hae.ui.dialog.ViewPhotoDialog;
import com.welby.hae.ui.main.MainActivity;
import com.welby.hae.utils.Define;
import com.welby.hae.utils.FileUtil;
import com.welby.hae.utils.RLog;
import com.welby.hae.utils.SharedPref;
import com.welby.hae.utils.TimeUtil;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

/**
 * Created by WelbyDev.
 */

public class SymptomRecordActivity extends BaseActivity implements SymptomRecordView, View.OnClickListener {
    public static final int FLAG_START_DATE = 1;
    public static final int FLAG_END_DATE = 2;
    public static final int REQUEST_OPEN_CAMERA = 100;
    public static final int REQUEST_OPEN_CAMERA_ROLL = 101;
    private static final int ACCESS_STORAGE_REQUEST_CODE = 102;

    private TextView tvStartDate;
    private TextView tvEndDate;
    private Button btnCamera;
    private Button btnCameraRoll;
    private FrameLayout layoutCam;
    private FrameLayout layoutCamRoll;
    private ImageView ivPic1;
    private ImageView ivPic2;
    private ImageView ivPic3;
    private ImageView ivPic4;
    private ImageView ivRemove1;
    private ImageView ivRemove2;
    private ImageView ivRemove3;
    private ImageView ivRemove4;
    private TextView tvPhotoDate1;
    private TextView tvPhotoDate2;
    private TextView tvPhotoDate3;
    private TextView tvPhotoDate4;
    private Button btnSave;
    private SeekBar sbPain;
    private RadioGroup rgTreatment;
    private EditText etMemo;
    private ScrollView svMain;
    private RelativeLayout mainLayout;
    private RadioGroup rgBody;

    private SymptomRecordPresenter presenter;
    private ClickHandler clickHandler;
    private SymptomRecordShowCase showCase;
    private boolean showCaseVisible;
    private View layoutGuideClose;

    private View layoutBodyFront;
    private ImageView ivBody1;
    private ImageView ivFace;
    private ImageView ivBody3;
    private ImageView ivRightArm;
    private ImageView ivBody;
    private ImageView ivLeftArm;
    private ImageView ivRightFinger;
    private ImageView ivRightLeg;
    private ImageView ivLeftLeg;
    private ImageView ivLeftFinger;
    private ImageView ivBody11;
    private ImageView ivRightToe;
    private ImageView ivLeftToe;
    private ImageView ivBody14;

    private ImageView ivSolidFace;
    private ImageView ivSolidBody;
    private ImageView ivSolidRightArm;
    private ImageView ivSolidLeftArm;
    private ImageView ivSolidRightFinger;
    private ImageView ivSolidLeftFinger;
    private ImageView ivSolidRightLeg;
    private ImageView ivSolidLeftLeg;
    private ImageView ivSolidRightToe;
    private ImageView ivSolidLeftToe;

    private View layoutBodyBack;
    private ImageView ivBack1;
    private ImageView ivBack2;
    private ImageView ivBackBody;
    private ImageView ivBack4;
    private ImageView ivBack5;
    private ImageView ivBackLeftLeg;
    private ImageView ivBackRightLeg;
    private ImageView ivBack8;
    private ImageView ivBack9;

    private ImageView ivSolidBackBody;
    private ImageView ivSolidBackLeftLeg;
    private ImageView ivSolidBackRightLeg;

    private String[] permissionsRequired = new String[]{
            Manifest.permission.READ_EXTERNAL_STORAGE};
    private Intent intent;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initView();
        initData();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        this.intent = intent;
        if (intent.getAction() != null && Intent.ACTION_SEND.equals(intent.getAction()) || Intent.ACTION_SEND_MULTIPLE.equals(intent.getAction())) {
            if (hasPermissions()) {
                handleSharedPhotoFromOtherApp();
            } else {
                ActivityCompat.requestPermissions(this,
                        permissionsRequired,
                        ACCESS_STORAGE_REQUEST_CODE);
            }
        }
    }

    @Override
    public void initView() {
        setContentView(R.layout.activity_symptom_record);
        setStatusBarColor(R.color.colorPrimary);

        ImageView ivBack = findViewById(R.id.iv_back);
        ImageView ivInstruction = findViewById(R.id.iv_instruction);
        tvStartDate = findViewById(R.id.tv_start_date);
        tvEndDate = findViewById(R.id.tv_end_date);
        btnCamera = findViewById(R.id.btn_camera);
        btnCameraRoll = findViewById(R.id.btn_camera_roll);
        layoutCam = findViewById(R.id.layout_cam);
        layoutCamRoll = findViewById(R.id.layout_cam_roll);
        ivPic1 = findViewById(R.id.iv_pic_1);
        ivPic2 = findViewById(R.id.iv_pic_2);
        ivPic3 = findViewById(R.id.iv_pic_3);
        ivPic4 = findViewById(R.id.iv_pic_4);
        ivRemove1 = findViewById(R.id.iv_remove_1);
        ivRemove2 = findViewById(R.id.iv_remove_2);
        ivRemove3 = findViewById(R.id.iv_remove_3);
        ivRemove4 = findViewById(R.id.iv_remove_4);
        tvPhotoDate1 = findViewById(R.id.tv_date_1);
        tvPhotoDate2 = findViewById(R.id.tv_date_2);
        tvPhotoDate3 = findViewById(R.id.tv_date_3);
        tvPhotoDate4 = findViewById(R.id.tv_date_4);
        btnSave = findViewById(R.id.btn_save);
        sbPain = findViewById(R.id.sb_pain);
        rgTreatment = findViewById(R.id.rg_treatment);
        etMemo = findViewById(R.id.et_memo);
        rgBody = findViewById(R.id.rg_body);

        Button btnGuideClose = findViewById(R.id.btn_guide_close);
        svMain = findViewById(R.id.sv_main);
        mainLayout = findViewById(R.id.appbar);
        layoutGuideClose = findViewById(R.id.layout_guide_close);

        ivBack.setOnClickListener(this);
        ivInstruction.setOnClickListener(this);
        tvStartDate.setOnClickListener(this);
        tvEndDate.setOnClickListener(this);
        btnCamera.setOnClickListener(this);
        btnCameraRoll.setOnClickListener(this);
        ivPic1.setOnClickListener(this);
        ivPic2.setOnClickListener(this);
        ivPic3.setOnClickListener(this);
        ivPic4.setOnClickListener(this);
        ivPic4.setOnClickListener(this);
        ivRemove1.setOnClickListener(this);
        ivRemove2.setOnClickListener(this);
        ivRemove3.setOnClickListener(this);
        ivRemove4.setOnClickListener(this);
        btnSave.setOnClickListener(this);
        btnGuideClose.setOnClickListener(this);

        layoutBodyFront = findViewById(R.id.layout_body_front);

        ivBody1 = findViewById(R.id.body_01);
        ivFace = findViewById(R.id.body_02);
        ivBody3 = findViewById(R.id.body_03);
        ivRightArm = findViewById(R.id.body_04);
        ivBody = findViewById(R.id.body_05);
        ivLeftArm = findViewById(R.id.body_06);
        ivRightFinger = findViewById(R.id.body_07);
        ivRightLeg = findViewById(R.id.body_08);
        ivLeftLeg = findViewById(R.id.body_09);
        ivLeftFinger = findViewById(R.id.body_10);
        ivBody11 = findViewById(R.id.body_11);
        ivRightToe = findViewById(R.id.body_12);
        ivLeftToe = findViewById(R.id.body_13);
        ivBody14 = findViewById(R.id.body_14);

        ivFace.setOnClickListener(this);
        ivRightArm.setOnClickListener(this);
        ivBody.setOnClickListener(this);
        ivLeftArm.setOnClickListener(this);
        ivRightFinger.setOnClickListener(this);
        ivRightLeg.setOnClickListener(this);
        ivLeftLeg.setOnClickListener(this);
        ivLeftFinger.setOnClickListener(this);
        ivRightToe.setOnClickListener(this);
        ivLeftToe.setOnClickListener(this);

        ivSolidFace = findViewById(R.id.solid_face);
        ivSolidBody = findViewById(R.id.solid_body);
        ivSolidRightArm = findViewById(R.id.solid_right_arm);
        ivSolidLeftArm = findViewById(R.id.solid_left_arm);
        ivSolidRightFinger = findViewById(R.id.solid_right_finger);
        ivSolidLeftFinger = findViewById(R.id.solid_left_finger);
        ivSolidRightLeg = findViewById(R.id.solid_right_foot);
        ivSolidLeftLeg = findViewById(R.id.solid_left_foot);
        ivSolidRightToe = findViewById(R.id.solid_right_toe);
        ivSolidLeftToe = findViewById(R.id.solid_left_toe);

        layoutBodyBack = findViewById(R.id.layout_body_back);

        ivBack1 = findViewById(R.id.back_01);
        ivBack2 = findViewById(R.id.back_02);
        ivBackBody = findViewById(R.id.back_03);
        ivBack4 = findViewById(R.id.back_04);
        ivBack5 = findViewById(R.id.back_05);
        ivBackLeftLeg = findViewById(R.id.back_06);
        ivBackRightLeg = findViewById(R.id.back_07);
        ivBack8 = findViewById(R.id.back_08);
        ivBack9 = findViewById(R.id.back_09);

        ivBackBody.setOnClickListener(this);
        ivBackLeftLeg.setOnClickListener(this);
        ivBackRightLeg.setOnClickListener(this);

        ivSolidBackBody = findViewById(R.id.solid_back_body);
        ivSolidBackLeftLeg = findViewById(R.id.solid_back_left_leg);
        ivSolidBackRightLeg = findViewById(R.id.solid_back_right_leg);

        sbPain.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                presenter.setPainLevel(progress);
                HAEApplication.getInstance().trackEvent(getString(R.string.event_strength_seizure));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                //implement method
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                //implement method
            }
        });

        rgTreatment.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, @IdRes int checkedIdRes) {
                boolean isTreatment = checkedIdRes == R.id.rb_treatment_yes;
                presenter.setTreatment(isTreatment);
                HAEApplication.getInstance().trackEvent(isTreatment
                        ? getString(R.string.event_treatment_yes)
                        : getString(R.string.event_treatment_no));
            }
        });

        rgBody.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, @IdRes int checkedIdRes) {
                if(checkedIdRes == R.id.rb_body_front) {
                    layoutBodyFront.setVisibility(View.VISIBLE);
                    layoutBodyBack.setVisibility(View.GONE);
                } else {
                    layoutBodyFront.setVisibility(View.GONE);
                    layoutBodyBack.setVisibility(View.VISIBLE);
                }
            }
        });

        svMain.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                return showCaseVisible;
            }
        });

        etMemo.setOnTouchListener(new View.OnTouchListener() {  //Register a callback to be invoked when a touch event is sent to this view.
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                //Called when a touch event is dispatched to a view. This allows listeners to get a chance to respond before the target view.
                svMain.requestDisallowInterceptTouchEvent(true);
                return false;
            }
        });
    }


    @Override
    public void initData() {
        if (getIntent().getExtras() != null && getIntent().getExtras().containsKey(Define.ExtrasKey.SYMPTOM_ID)) {
            presenter = new SymptomRecordPresenter(this, getIntent().getExtras().getInt(Define.ExtrasKey.SYMPTOM_ID));
            if (getIntent().getExtras().containsKey(Define.ExtrasKey.CALLER_FLAG)) {
                HAEApplication.getInstance().trackEvent(getString(R.string.event_launch_from_notification));
            }
        } else {
            presenter = new SymptomRecordPresenter(this);
        }

        presenter.initView();

        this.intent = getIntent();

        if (intent.getAction() != null && Intent.ACTION_SEND.equals(intent.getAction()) || Intent.ACTION_SEND_MULTIPLE.equals(intent.getAction())) {
            if (hasPermissions()) {
                handleSharedPhotoFromOtherApp();
            } else {
                ActivityCompat.requestPermissions(this,
                        permissionsRequired,
                        ACCESS_STORAGE_REQUEST_CODE);
            }
        }

        //check received photo from camera
        handleSharedPhotoFromCamera();

        Glide.with(this).load(R.drawable.body_01_33_17).into(ivBody1);
        Glide.with(this).load(R.drawable.body_02_34_17).into(ivFace);
        Glide.with(this).load(R.drawable.body_03_33_17).into(ivBody3);
        Glide.with(this).load(R.drawable.body_04_33_29).into(ivRightArm);
        Glide.with(this).load(R.drawable.body_05_34_29).into(ivBody);
        Glide.with(this).load(R.drawable.body_06_33_29).into(ivLeftArm);
        Glide.with(this).load(R.drawable.body_07_33_11).into(ivRightFinger);
        Glide.with(this).load(R.drawable.body_08_17_33).into(ivRightLeg);
        Glide.with(this).load(R.drawable.body_09_17_33).into(ivLeftLeg);
        Glide.with(this).load(R.drawable.body_10_33_11).into(ivLeftFinger);
        Glide.with(this).load(R.drawable.body_11_33_43).into(ivBody11);
        Glide.with(this).load(R.drawable.body_12_17_10).into(ivRightToe);
        Glide.with(this).load(R.drawable.body_13_17_10).into(ivLeftToe);
        Glide.with(this).load(R.drawable.body_14_33_43).into(ivBody14);

        Glide.with(this).load(R.drawable.face).into(ivSolidFace);
        Glide.with(this).load(R.drawable.body).into(ivSolidBody);
        Glide.with(this).load(R.drawable.right_arm).into(ivSolidRightArm);
        Glide.with(this).load(R.drawable.left_arm).into(ivSolidLeftArm);
        Glide.with(this).load(R.drawable.right_finger).into(ivSolidRightFinger);
        Glide.with(this).load(R.drawable.left_finger).into(ivSolidLeftFinger);
        Glide.with(this).load(R.drawable.right_foot).into(ivSolidRightLeg);
        Glide.with(this).load(R.drawable.left_foot).into(ivSolidLeftLeg);
        Glide.with(this).load(R.drawable.right_toe).into(ivSolidRightToe);
        Glide.with(this).load(R.drawable.left_toe).into(ivSolidLeftToe);

        Glide.with(this).load(R.drawable.back_01_100_15).into(ivBack1);
        Glide.with(this).load(R.drawable.back_02_33_40).into(ivBack2);
        Glide.with(this).load(R.drawable.back_03_34_40).into(ivBackBody);
        Glide.with(this).load(R.drawable.back_04_33_40).into(ivBack4);
        Glide.with(this).load(R.drawable.back_05_33_35).into(ivBack5);
        Glide.with(this).load(R.drawable.back_06_17_35).into(ivBackLeftLeg);
        Glide.with(this).load(R.drawable.back_07_17_35).into(ivBackRightLeg);
        Glide.with(this).load(R.drawable.back_08_33_35).into(ivBack8);
        Glide.with(this).load(R.drawable.back_09_100_10).into(ivBack9);

        Glide.with(this).load(R.drawable.back_solid_body).into(ivSolidBackBody);
        Glide.with(this).load(R.drawable.back_solid_left_leg).into(ivSolidBackLeftLeg);
        Glide.with(this).load(R.drawable.back_solid_right_leg).into(ivSolidBackRightLeg);

        if (!SharedPref.getInstance().contains(Define.SharedPreferenceKey.SYMPTOM_RECORD_FIRST_TIME)) {
            showGuide();
            SharedPref.getInstance().putBoolean(Define.SharedPreferenceKey.SYMPTOM_RECORD_FIRST_TIME, true);
        }

        clickHandler = new ClickHandler(Define.CLICK_DELAY);
    }

    @Override
    public void onClick(View view) {
        if (showCaseVisible && view.getId() != R.id.btn_guide_close) {
            return;
        }
        if (!clickHandler.isClickable(view.getId())) {
            return;
        }
        switch (view.getId()) {
            case R.id.iv_back:
                confirmExit();
                HAEApplication.getInstance().trackEvent(getString(R.string.event_back_previous_record_symptom));
                break;
            case R.id.iv_instruction:
                showGuide();
                HAEApplication.getInstance().trackEvent(getString(R.string.event_guide));
                break;
            case R.id.tv_start_date:
                presenter.showTimePicker(FLAG_START_DATE);
                HAEApplication.getInstance().trackEvent(getString(R.string.event_day_seizure_started));
                break;
            case R.id.tv_end_date:
                presenter.showTimePicker(FLAG_END_DATE);
                HAEApplication.getInstance().trackEvent(getString(R.string.event_day_seizure_ended));
                break;
            case R.id.btn_camera:
                presenter.pickPhotoFromCamera(this);
                HAEApplication.getInstance().trackEvent(getString(R.string.event_camera_tap));
                break;
            case R.id.btn_camera_roll:
                presenter.pickPhotoFromGallery(this);
                HAEApplication.getInstance().trackEvent(getString(R.string.event_camerarole_tap));
                break;
            case R.id.iv_pic_1:
                presenter.showPhoto(0);
                break;
            case R.id.iv_pic_2:
                presenter.showPhoto(1);
                break;
            case R.id.iv_pic_3:
                presenter.showPhoto(2);
                break;
            case R.id.iv_pic_4:
                presenter.showPhoto(3);
                break;
            case R.id.iv_remove_1:
                showRemovePhotoAlert(0);
                break;
            case R.id.iv_remove_2:
                showRemovePhotoAlert(1);
                break;
            case R.id.iv_remove_3:
                showRemovePhotoAlert(2);
                break;
            case R.id.iv_remove_4:
                showRemovePhotoAlert(3);

                break;
            case R.id.btn_save:
                presenter.saveRecord(this, etMemo.getText().toString(), false);
                btnSave.setClickable(false);
                HAEApplication.getInstance().trackEvent(getString(R.string.event_save_tap));
                break;
            case R.id.btn_guide_close:
                showCase.removeAllViews();
                mainLayout.removeView(showCase);
                layoutGuideClose.setVisibility(View.GONE);
                showCaseVisible = false;
                btnSave.setVisibility(View.VISIBLE);
                setStatusBarColor(R.color.colorPrimary);
                break;
            case R.id.body_02: //face
                presenter.showSymptomRecordDialog(this, getSupportFragmentManager(), Define.BodyPart.FACE);
                HAEApplication.getInstance().trackScreenView(getString(R.string.screen_body_part_face));
                HAEApplication.getInstance().trackEvent(getString(R.string.event_body_part_face));
                break;
            case R.id.body_04: //right arm
                presenter.showSymptomRecordDialog(this, getSupportFragmentManager(), Define.BodyPart.RIGHT_ARM);
                HAEApplication.getInstance().trackScreenView(getString(R.string.screen_body_part_right_arm));
                HAEApplication.getInstance().trackEvent(getString(R.string.event_body_part_right_arm));
                break;
            case R.id.body_05: //body
                presenter.showSymptomRecordDialog(this, getSupportFragmentManager(), Define.BodyPart.BODY);
                HAEApplication.getInstance().trackScreenView(getString(R.string.screen_body_part_body));
                HAEApplication.getInstance().trackEvent(getString(R.string.event_body_part_body));
                break;
            case R.id.body_06: //left arm
                presenter.showSymptomRecordDialog(this, getSupportFragmentManager(), Define.BodyPart.LEFT_ARM);
                HAEApplication.getInstance().trackScreenView(getString(R.string.screen_body_part_left_arm));
                HAEApplication.getInstance().trackEvent(getString(R.string.event_body_part_left_arm));
                break;
            case R.id.body_07: //right finger
                presenter.showSymptomRecordDialog(this, getSupportFragmentManager(), Define.BodyPart.RIGHT_FINGER);
                HAEApplication.getInstance().trackScreenView(getString(R.string.screen_body_part_right_hand));
                HAEApplication.getInstance().trackEvent(getString(R.string.event_body_part_right_hand));
                break;
            case R.id.body_08: //right leg
                presenter.showSymptomRecordDialog(this, getSupportFragmentManager(), Define.BodyPart.RIGHT_LEG);
                HAEApplication.getInstance().trackScreenView(getString(R.string.screen_body_part_right_leg));
                HAEApplication.getInstance().trackEvent(getString(R.string.event_body_part_right_leg));
                break;
            case R.id.body_09: //left leg
                presenter.showSymptomRecordDialog(this, getSupportFragmentManager(), Define.BodyPart.LEFT_LEG);
                HAEApplication.getInstance().trackScreenView(getString(R.string.screen_body_part_left_leg));
                HAEApplication.getInstance().trackEvent(getString(R.string.event_body_part_left_leg));
                break;
            case R.id.body_10: //left finger
                presenter.showSymptomRecordDialog(this, getSupportFragmentManager(), Define.BodyPart.LEFT_FINGER);
                HAEApplication.getInstance().trackScreenView(getString(R.string.screen_body_part_left_hand));
                HAEApplication.getInstance().trackEvent(getString(R.string.event_body_part_left_hand));
                break;
            case R.id.body_12: //right toe
                presenter.showSymptomRecordDialog(this, getSupportFragmentManager(), Define.BodyPart.RIGHT_TOE);
                HAEApplication.getInstance().trackScreenView(getString(R.string.screen_body_part_right_foot));
                HAEApplication.getInstance().trackEvent(getString(R.string.event_body_part_right_foot));
                break;
            case R.id.body_13: //left toe
                presenter.showSymptomRecordDialog(this, getSupportFragmentManager(), Define.BodyPart.LEFT_TOE);
                HAEApplication.getInstance().trackScreenView(getString(R.string.screen_body_part_left_foot));
                HAEApplication.getInstance().trackEvent(getString(R.string.event_body_part_left_foot));
                break;
            case R.id.back_03:
                presenter.showSymptomRecordDialog(this, getSupportFragmentManager(), Define.BodyPart.BODY_BACK);
                break;
            case R.id.back_06:
                presenter.showSymptomRecordDialog(this, getSupportFragmentManager(), Define.BodyPart.LEFT_LEG_BACK);
                break;
            case R.id.back_07:
                presenter.showSymptomRecordDialog(this, getSupportFragmentManager(), Define.BodyPart.RIGHT_LEG_BACK);
                break;
            default:
                break;
        }
    }

    @Override
    public void setStartDate(Calendar cal) {
        tvStartDate.setGravity(Gravity.CENTER);
        tvStartDate.setText(TimeUtil.getTime(TimeUtil.FORMAT_2, cal.getTimeInMillis(), Locale.JAPAN));
    }

    @Override
    public void setEndDate(Calendar cal) {
        if (cal.getTimeInMillis() != Long.MAX_VALUE) {
            tvEndDate.setGravity(Gravity.CENTER);
            tvEndDate.setText(TimeUtil.getTime(TimeUtil.FORMAT_2, cal.getTimeInMillis(), Locale.JAPAN));
        } else {
            tvEndDate.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        }
    }

    @Override
    public void setPhoto(int position, Photo photo) {
        ImageView targetPhoto;
        ImageView targetRemove;
        TextView targetPhotoDate;
        switch (position) {
            case 1:
                targetRemove = ivRemove2;
                targetPhoto = ivPic2;
                targetPhotoDate = tvPhotoDate2;
                break;
            case 2:
                targetRemove = ivRemove3;
                targetPhoto = ivPic3;
                targetPhotoDate = tvPhotoDate3;
                break;
            case 3:
                targetRemove = ivRemove4;
                targetPhoto = ivPic4;
                targetPhotoDate = tvPhotoDate4;
                break;
            default:
                targetRemove = ivRemove1;
                targetPhoto = ivPic1;
                targetPhotoDate = tvPhotoDate1;
                break;
        }
        if (photo != null) {
            Glide.with(this).load(photo.getPath()).into(targetPhoto);
            targetPhotoDate.setText(TimeUtil.getTime(TimeUtil.FORMAT_3, photo.getCreatedTime()));
            targetRemove.setVisibility(View.VISIBLE);
        } else {
            targetPhoto.setImageResource(position == 0
                    ? R.drawable.ic_empty_pic_1 : position == 1
                    ? R.drawable.ic_empty_pic_2 : position == 2
                    ? R.drawable.ic_empty_pic_3 : R.drawable.ic_empty_pic_4);
            targetPhotoDate.setText(R.string.sr_pic_date_empty);
            targetRemove.setVisibility(View.GONE);
        }
    }

    @Override
    public void showPhoto(String photoPath) {
        new ViewPhotoDialog.Builder(getSupportFragmentManager(), photoPath).build().show();
    }

    @Override
    public void enablePickPhoto(boolean isEnabled) {
        layoutCam.setBackgroundResource(isEnabled ? R.drawable.bg_rounded_red_light_2 : R.drawable.bg_rounded_grey);
        layoutCamRoll.setBackgroundResource(isEnabled ? R.drawable.bg_rounded_red_light_2 : R.drawable.bg_rounded_grey);

        btnCamera.setEnabled(isEnabled);
        btnCamera.setClickable(isEnabled);
        btnCameraRoll.setEnabled(isEnabled);
        btnCameraRoll.setClickable(isEnabled);
    }

    @Override
    public void setPainLevel(int level) {
        sbPain.setProgress(level);
    }

    @Override
    public void setTreatment(boolean isTreatment) {
        rgTreatment.check(isTreatment ? R.id.rb_treatment_yes : R.id.rb_treatment_no);
    }

    @Override
    public void setMemo(String memo) {
        etMemo.setText(memo);
    }

    /**
     * show success dialog when save completed
     *
     * @param isBack = true if not show calendar when save completed
     *               else false
     */
    @Override
    public void saveCompleted(final boolean isBack) {
        StringBuilder content = new StringBuilder(getString(R.string.sr_save_success_title));
        String[] messages = getResources().getStringArray(R.array.sr_save_success_messages);
        content.append(Define.STR_RETURN).append(messages[new Random().nextInt(messages.length)]);
        new AppAlertDialog.Builder(getSupportFragmentManager())
                .message(content.toString())
                .setOnActionListener(new AppAlertDialog.OnActionListener() {
                    @Override
                    public void onConfirm() {
                        setLastVisibleActivity(isBack ? MainActivity.class.getName() : SymptomRecordActivity.class.getName());
                        startActivity(new Intent(SymptomRecordActivity.this, MainActivity.class));
                        finish();
                        HAEApplication.getInstance().trackEvent(getString(R.string.event_record_symptom_done));
                    }

                    @Override
                    public void onCancel() {
                        //implement method
                    }
                })
                .build()
                .show();
        HAEApplication.getInstance().trackScreenView(getString(R.string.screen_record_symptom_done_dialog));
    }

    /**
     * show confirm override start time dialog
     *
     * @param timeInMillis photo's created time
     */
    @Override
    public void showTimestampAlert(final long timeInMillis) {
        new AppAlertDialog.Builder(getSupportFragmentManager())
                .visibleCloseButton(true)
                .message(getString(R.string.sr_alert_timestamp))
                .setOnActionListener(new AppAlertDialog.OnActionListener() {
                    @Override
                    public void onConfirm() {
                        Calendar cal = Calendar.getInstance();
                        cal.setTimeInMillis(timeInMillis);
                        presenter.setStartDate(cal);
                        HAEApplication.getInstance().trackEvent(getString(R.string.event_timestamp_change));
                    }

                    @Override
                    public void onCancel() {
                        //implement method
                    }
                })
                .build()
                .show();
        HAEApplication.getInstance().trackScreenView(getString(R.string.screen_record_symptom_timestamp_dialog));
    }

    @Override
    public void showSeizureDateConflictAlert() {
        new AppAlertDialog.Builder(getSupportFragmentManager())
                .message(getString(R.string.sr_alert_seizure_date_conflict))
                .build()
                .show();
    }

    @Override
    public void showRemovePhotoAlert(final int position) {
        new AppAlertDialog.Builder(getSupportFragmentManager())
                .visibleCancelButton(true)
                .cancelText(getString(R.string.sr_dialog_confirm_cancel_remove_photo))
                .message(getString(R.string.sr_alert_remove_photo))
                .setOnActionListener(new AppAlertDialog.OnActionListener() {
                    @Override
                    public void onConfirm() {
                        presenter.removePhoto(position);
                    }

                    @Override
                    public void onCancel() {
                        //implement method
                    }
                })
                .build()
                .show();
    }

    @Override
    public void showTimePicker(final int dateFlag, Date defaultDate) {
        new SingleDateAndTimePickerDialog.Builder(this)
                .bottomSheet()
                .curved()
                .title(getString(R.string.time_picker_cancel))
                .todayText(getString(R.string.today))
                .minutesStep(1)
                .setDayFormatter(new SimpleDateFormat(getString(R.string.time_picker_format_date), Locale.getDefault()))
                .defaultDate(defaultDate)
                .listener(new SingleDateAndTimePickerDialog.Listener() {
                    @Override
                    public void onDateSelected(Date date) {
                        Calendar cal = Calendar.getInstance();
                        cal.setTime(date);
                        if (dateFlag == FLAG_START_DATE) {
                            presenter.setStartDate(cal);
                            presenter.setTimePickedByUser(true);
                        } else if (dateFlag == FLAG_END_DATE) {
                            presenter.setEndDate(cal);
                        }
                    }
                })
                .display();
    }

    public void confirmExit() {
        new AppAlertDialog.Builder(getSupportFragmentManager())
                .message(getString(R.string.sr_dialog_confirm_cancel_message))
                .confirmText(getString(R.string.sr_dialog_confirm_cancel_yes))
                .cancelText(getString(R.string.sr_dialog_confirm_cancel_no))
                .visibleCancelButton(true)
                .cancelable(false)
                .setOnActionListener(new AppAlertDialog.OnActionListener() {
                    @Override
                    public void onConfirm() {
                        presenter.saveRecord(SymptomRecordActivity.this, etMemo.getText().toString(), true);
                    }

                    @Override
                    public void onCancel() {
                        /*
                        setLastVisibleActivity(MainActivity.class.getName());
                        startActivity(new Intent(SymptomRecordActivity.this, MainActivity.class));
                        finish();
                        */
                    }
                })
                .build()
                .show();
    }

    /**
     * solid part of body
     *
     * @param partOfBody 's id
     * @param isSolid    = true -> solid
     */
    @Override
    public void solidPart(int partOfBody, boolean isSolid) {
        switch (partOfBody) {
            case Define.BodyPart.FACE:
                ivSolidFace.setVisibility(isSolid ? View.VISIBLE : View.GONE);
                break;
            case Define.BodyPart.BODY:
                ivSolidBody.setVisibility(isSolid ? View.VISIBLE : View.GONE);
                break;
            case Define.BodyPart.RIGHT_ARM:
                ivSolidRightArm.setVisibility(isSolid ? View.VISIBLE : View.GONE);
                break;
            case Define.BodyPart.LEFT_ARM:
                ivSolidLeftArm.setVisibility(isSolid ? View.VISIBLE : View.GONE);
                break;
            case Define.BodyPart.RIGHT_FINGER:
                ivSolidRightFinger.setVisibility(isSolid ? View.VISIBLE : View.GONE);
                break;
            case Define.BodyPart.LEFT_FINGER:
                ivSolidLeftFinger.setVisibility(isSolid ? View.VISIBLE : View.GONE);
                break;
            case Define.BodyPart.RIGHT_LEG:
                ivSolidRightLeg.setVisibility(isSolid ? View.VISIBLE : View.GONE);
                break;
            case Define.BodyPart.LEFT_LEG:
                ivSolidLeftLeg.setVisibility(isSolid ? View.VISIBLE : View.GONE);
                break;
            case Define.BodyPart.RIGHT_TOE:
                ivSolidRightToe.setVisibility(isSolid ? View.VISIBLE : View.GONE);
                break;
            case Define.BodyPart.LEFT_TOE:
                ivSolidLeftToe.setVisibility(isSolid ? View.VISIBLE : View.GONE);
                break;
            case Define.BodyPart.BODY_BACK:
                ivSolidBackBody.setVisibility(isSolid ? View.VISIBLE : View.GONE);
                break;
            case Define.BodyPart.RIGHT_LEG_BACK:
                ivSolidBackRightLeg.setVisibility(isSolid ? View.VISIBLE : View.GONE);
                break;
            case Define.BodyPart.LEFT_LEG_BACK:
                ivSolidBackLeftLeg.setVisibility(isSolid ? View.VISIBLE : View.GONE);
                break;
            default:
                break;
        }
    }

    @Override
    public void showPermissionsRequiredAlert(String message) {
        new AlertDialog.Builder(this, R.style.PermissionAlertDialogStyle)
                .setMessage(message)
                .setNegativeButton(R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //implement method
                    }
                })
                .setCancelable(false)
                .create()
                .show();
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        ArrayList<Photo> receivedPhotoPaths = new ArrayList<>();
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_OPEN_CAMERA) {
                receivedPhotoPaths.add((Photo) data.getExtras().getParcelable(Define.ExtrasKey.PHOTO));
                presenter.receivedPhotos(receivedPhotoPaths);
            } else if (requestCode == REQUEST_OPEN_CAMERA_ROLL) {
                receivedPhotoPaths = data.getExtras().getParcelableArrayList(Define.ExtrasKey.PHOTO_LIST);
                presenter.receivedPhotos(receivedPhotoPaths);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (requestCode == ACCESS_STORAGE_REQUEST_CODE) {
                handleSharedPhotoFromOtherApp();
            }
        } else {
            showPermissionsRequiredAlert(getString(R.string.pd_permission_denied)
                    + Define.STR_RETURN
                    + getString(R.string.pd_permission_storage));
        }
    }

    @Override
    public void onBackPressed() {
//        confirmExit();
    }

    private void setStatusBarColor(int colorId) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(ContextCompat.getColor(this, colorId));
        }
    }

    //check received photo from camera
    private void handleSharedPhotoFromCamera() {
        Bundle data = intent.getExtras();
        if (data != null) {
            Photo photo = data.getParcelable(Define.ExtrasKey.PHOTO);
            if (photo != null) {
                presenter.receivedPhoto(photo);
            }
        }
    }

    /**
     * handle shared photo from other app
     * get photo uri from other app
     * using content resolver to query path and created date of photo uri
     * if cannot query -> use uri as path and get current time as created time of photo
     */
    private void handleSharedPhotoFromOtherApp() {
        //check received photo from other app
        String action = intent.getAction();
        String type = intent.getType();
        if (Intent.ACTION_SEND.equals(action) && type.contains(Define.MIME_TYPE_IMAGE)) {
            Uri imageUri = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (imageUri != null) {
                String imagePath = FileUtil.getPathFromImageUri(this, imageUri);
                if (imagePath == null) {
                    RLog.d("can not query image data");
                    Photo photo = new Photo(imageUri.toString(), System.currentTimeMillis());
                    presenter.receivedPhoto(photo);
                    return;
                }
                Photo photo = new Photo(imagePath, FileUtil.getFileModifiedTime(imagePath).getTime());
                presenter.receivedPhoto(photo);
            }
        } else if (Intent.ACTION_SEND_MULTIPLE.equals(action) && type.contains(Define.MIME_TYPE_IMAGE)) {
            ArrayList<Uri> imageUris = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
            ArrayList<Photo> photos = new ArrayList<>();
            if (imageUris != null) {
                for (Uri uri : imageUris) {
                    String imagePath = FileUtil.getPathFromImageUri(this, uri);
                    if (imagePath == null) {
                        RLog.d("can not query image data");
                        Photo photo = new Photo(uri.toString(), System.currentTimeMillis());
                        presenter.receivedPhoto(photo);
                        return;
                    }
                    photos.add(new Photo(imagePath, FileUtil.getFileModifiedTime(imagePath).getTime()));
                }
            }
            presenter.receivedPhotos(photos);
        }
    }

    /**
     * check storage access permissions.
     *
     * @return false if permission denied
     */
    private boolean hasPermissions() {
        return ContextCompat.checkSelfPermission(this, permissionsRequired[0]) == PackageManager.PERMISSION_GRANTED;
    }

    /**
     * show guide
     * scroll to top when showcase start
     * touchable = false if showcase is showing
     */
    private void showGuide() {
        svMain.scrollTo(0, 0);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                showCaseVisible = true;
                layoutGuideClose.setVisibility(View.VISIBLE);
                btnSave.setVisibility(View.GONE);
                ArrayList<SymptomRecordShowCase.Item> itemList = new ArrayList<>();
                itemList.add(new SymptomRecordShowCase.Item(getString(R.string.srg_guide_photo), btnCamera, true));
                itemList.add(new SymptomRecordShowCase.Item(getString(R.string.srg_guide_touch_body), rgBody, false));
                itemList.add(new SymptomRecordShowCase.Item(getString(R.string.srg_guide_set_pain_level), sbPain, true));
                itemList.add(new SymptomRecordShowCase.Item(getString(R.string.srg_guide_treatment), rgTreatment, false));

                showCase = new SymptomRecordShowCase(SymptomRecordActivity.this, mainLayout.getMeasuredWidth(), svMain.getChildAt(0).getHeight(), itemList);
                mainLayout.addView(showCase);

                showCase.setShowCaseListener(new SymptomRecordShowCase.ShowCaseListener() {
                    @Override
                    public void onClose() {
                        showCaseVisible = false;
                    }

                    @Override
                    public void onNext() {
                        showCase.hideMoreButton();
                        View labelMemo = findViewById(R.id.tv_label_memo);
                        labelMemo.setFocusableInTouchMode(true);
                        labelMemo.setFocusable(true);
                        labelMemo.clearFocus();
                        labelMemo.requestFocus();
                    }
                });

                showCase.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View view, MotionEvent motionEvent) {
                        return view.getId() != R.id.btn_guide_close;
                    }
                });
                setStatusBarColor(R.color.srg_status_bar);
            }
        }, 100);
    }
}
