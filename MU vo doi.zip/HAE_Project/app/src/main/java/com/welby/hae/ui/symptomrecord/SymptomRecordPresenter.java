package com.welby.hae.ui.symptomrecord;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v4.app.FragmentManager;

import com.welby.hae.data.db.helper.RealmManager;
import com.welby.hae.data.db.model.Symptom;
import com.welby.hae.data.db.model.SymptomPartRelation;
import com.welby.hae.data.db.model.SymptomPhoto;
import com.welby.hae.model.Photo;
import com.welby.hae.model.SymptomItem;
import com.welby.hae.ui.base.BasePresenter;
import com.welby.hae.ui.camera.CamActivity;
import com.welby.hae.ui.cameraroll.CameraRollActivity;
import com.welby.hae.ui.dialog.SymptomRecordDialog;
import com.welby.hae.utils.Define;
import com.welby.hae.utils.FileUtil;
import com.welby.hae.utils.SavePhotosAsync;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by WelbyDev.
 */

class SymptomRecordPresenter extends BasePresenter {
    private SymptomRecordView symptomRecordView;
    private ArrayList<Photo> photoList;
    private ArrayList<Photo> needDeletePhotoList; //photos was removed by user and waiting for delete from storage
    private List<SymptomItem> symptomItemList;
    private Set<Integer> solidParts;
    private Symptom symptom;
    private boolean isNewSymptomRecord; //check if symptom record is new or modifying (false if modifying)

    private boolean timePickedByUser;
    private long currentStartDate;
    private long currentEndDate = Long.MAX_VALUE;

    SymptomRecordPresenter(SymptomRecordView symptomRecordView) {
        this.symptomRecordView = symptomRecordView;
        this.symptom = new Symptom();
        this.photoList = new ArrayList<>();
        this.needDeletePhotoList = new ArrayList<>();
        this.solidParts = new LinkedHashSet<>();
        this.symptomItemList = RealmManager.getRealmManager().getSymptomHelper().getDefaultPartDetails();
        isNewSymptomRecord = true;
    }

    SymptomRecordPresenter(SymptomRecordView symptomRecordView, int symptomId) {
        this.symptomRecordView = symptomRecordView;
        this.photoList = new ArrayList<>();
        this.needDeletePhotoList = new ArrayList<>();
        this.solidParts = new LinkedHashSet<>();
        this.symptom = RealmManager.getRealmManager().getSymptomHelper().getSymptomRecord(symptomId);
        this.symptomItemList = RealmManager.getRealmManager().getSymptomHelper().getSymptomPartDetails(symptomId);
        isNewSymptomRecord = false;
    }

    public void initView() {
        if (!isNewSymptomRecord) {
            if (symptom.getSeizureStartDate() != null) {
                Calendar cal = Calendar.getInstance();
                cal.setTime(symptom.getSeizureStartDate());
                symptomRecordView.setStartDate(cal);
                currentStartDate = cal.getTimeInMillis();
            }

            if (symptom.getSeizureEndDate() != null) {
                Calendar cal = Calendar.getInstance();
                cal.setTime(symptom.getSeizureEndDate());
                symptomRecordView.setEndDate(cal);
                currentEndDate = cal.getTimeInMillis();
            }

            for (int i = 0; i < symptom.getSymptomPhotos().size(); i++) {
                Photo photo = new Photo(symptom.getSymptomPhotos().get(i).getFileName(), symptom.getSymptomPhotos().get(i).getCreated().getTime());
                symptomRecordView.setPhoto(i, photo);
                photoList.add(photo);
            }

            symptomRecordView.enablePickPhoto(photoList.size() < Define.MAX_PHOTOS);

            symptomRecordView.setPainLevel(symptom.getPainLevel());

            symptomRecordView.setTreatment(symptom.getTreatmentFlag() == 1);

            symptomRecordView.setMemo(symptom.getMemo());

            solidPart();
        } else {
            Calendar c = Calendar.getInstance();
            symptom.setSeizureStartDate(c.getTime());
            symptomRecordView.setStartDate(c);
            currentStartDate = c.getTimeInMillis();
        }
    }

    private void solidPart() {
        solidParts.clear();
        for (SymptomItem item : symptomItemList) {
            if (item.isChosen()) {
                solidParts.add(item.getPartId());
            }
        }
        for (int partOfBody = Define.BodyPart.MIN; partOfBody <= Define.BodyPart.MAX; partOfBody++) {
            boolean isSolid = false;
            for (Integer solidPart : solidParts) {
                if (partOfBody == solidPart) {
                    isSolid = true;
                    break;
                }
            }
            symptomRecordView.solidPart(partOfBody, isSolid);
        }

    }

    void setTimePickedByUser(boolean timePickedByUser) {
        this.timePickedByUser = timePickedByUser;
    }

    void showTimePicker(int flagDate) {
        if (flagDate == SymptomRecordActivity.FLAG_START_DATE) {
            symptomRecordView.showTimePicker(flagDate, new Date(currentStartDate));
        } else {
            symptomRecordView.showTimePicker(flagDate, new Date(currentEndDate != Long.MAX_VALUE ? currentEndDate : System.currentTimeMillis()));
        }
    }

    void setStartDate(Calendar cal) {
        if (cal.getTimeInMillis() > currentEndDate) {
            symptomRecordView.showSeizureDateConflictAlert();
            return;
        }
        currentStartDate = cal.getTimeInMillis();
        symptom.setSeizureStartDate(cal.getTime());
        symptomRecordView.setStartDate(cal);

    }

    void setEndDate(Calendar cal) {
        if (cal.getTimeInMillis() < currentStartDate) {
            symptomRecordView.showSeizureDateConflictAlert();
            return;
        }
        currentEndDate = cal.getTimeInMillis();
        symptom.setSeizureEndDate(cal.getTime());
        symptomRecordView.setEndDate(cal);
    }

    /**
     * show choose symptom dialog
     *
     * @param context    context
     * @param fm         fragment manager
     * @param partOfBody partOfBody's id
     */
    void showSymptomRecordDialog(Context context, FragmentManager fm, final int partOfBody) {
        ArrayList<SymptomItem> tempSymptomItemList = new ArrayList<>();
        for (SymptomItem item : symptomItemList) {
            if (item.getPartId() == partOfBody) {
                SymptomItem si = new SymptomItem(item.getDetailId(), item.getPartId(), item.getDetailPartId(), item.getName(), item.isChosen());
                tempSymptomItemList.add(si);
            }
        }
        new SymptomRecordDialog.Builder(context, fm, tempSymptomItemList, partOfBody)
                .partTitle(RealmManager.getRealmManager().getSymptomHelper().getPart(partOfBody) != null
                        ? RealmManager.getRealmManager().getSymptomHelper().getPart(partOfBody).getName()
                        : Define.STR_EMPTY)
                .setOnActionListener(new SymptomRecordDialog.OnActionListener() {
                    @Override
                    public void onSave(List<SymptomItem> result) {
                        for (int i = 0; i < symptomItemList.size(); i++) {
                            for (int j = 0; j < result.size(); j++) {
                                if (symptomItemList.get(i).getDetailId() == result.get(j).getDetailId()) {
                                    symptomItemList.get(i).setChosen(result.get(j).isChosen());
                                    result.remove(j);
                                    break;
                                }
                            }
                        }
                        solidPart();
                    }

                    @Override
                    public void onBack() {
                        //implement method
                    }
                })
                .cancelable(true)
                .build()
                .show();
    }

    void pickPhotoFromCamera(Activity activity) {
        Intent intent = new Intent(activity, CamActivity.class);
        activity.startActivityForResult(intent, SymptomRecordActivity.REQUEST_OPEN_CAMERA);
    }

    void pickPhotoFromGallery(Activity activity) {
        Intent intent = new Intent(activity, CameraRollActivity.class);
        intent.putExtra(Define.ExtrasKey.NUMBER_OF_SELECTED_PHOTOS, photoList.size());
        activity.startActivityForResult(intent, SymptomRecordActivity.REQUEST_OPEN_CAMERA_ROLL);
    }

    /**
     * handle received photo.
     * if number of photos is max -> do nothing.
     * set pickable photo = false if number of photos is max.
     * show override timestamp dialog alert if photo's created date < current start date (in minute)
     *
     * @param photo received photo
     */
    void receivedPhoto(Photo photo) {
        if (photoList.size() == Define.MAX_PHOTOS) {
            return;
        }
        photoList.add(photo);
        Collections.sort(photoList, new Comparator<Photo>() {
            @Override
            public int compare(Photo photo1, Photo photo2) {
                return photo1.getCreatedTime() > photo2.getCreatedTime() ? 1 : -1;
            }
        });
        for (int i = 0; i < photoList.size(); i++) {
            symptomRecordView.setPhoto(i, photoList.get(i));
        }
        symptomRecordView.enablePickPhoto(photoList.size() < Define.MAX_PHOTOS);

        //a minute = 60000 milliseconds
        if (!timePickedByUser && photo.getCreatedTime() < currentStartDate - 60000) {
            symptomRecordView.showTimestampAlert(photo.getCreatedTime());
        }
    }

    /**
     * handle received photo list.
     * if number of photos is max -> do nothing.
     * set pickable photo = false if number of photos is max.
     *
     * @param receivedPhotoList received photo list
     */
    void receivedPhotos(ArrayList<Photo> receivedPhotoList) {
        for (Photo photo : receivedPhotoList) {
            if (photoList.size() == Define.MAX_PHOTOS) {
                break;
            }
            photoList.add(photo);
        }
        Collections.sort(photoList, new Comparator<Photo>() {
            @Override
            public int compare(Photo photo1, Photo photo2) {
                return photo1.getCreatedTime() > photo2.getCreatedTime() ? 1 : -1;
            }
        });
        for (int i = 0; i < photoList.size(); i++) {
            symptomRecordView.setPhoto(i, photoList.get(i));
        }
        symptomRecordView.enablePickPhoto(photoList.size() < Define.MAX_PHOTOS);

        if (!timePickedByUser) {
            long oldestTime = getOldestTime();
            if (oldestTime < currentStartDate - 60000) {
                symptomRecordView.showTimestampAlert(getOldestTime());
            }
        }
    }

    void showPhoto(int position) {
        if (position < photoList.size()) {
            symptomRecordView.showPhoto(photoList.get(position).getPath());
        }
    }

    private long getOldestTime() {
        long oldestTime = currentStartDate;
        for (Photo photo : photoList) {
            if (photo.getCreatedTime() < oldestTime) {
                oldestTime = photo.getCreatedTime();
            }
        }
        return oldestTime;
    }

    /**
     * remove photo
     * set pickable photo = true if number of photos < max
     *
     * @param position remove photo with this position
     */
    void removePhoto(int position) {
        if (position < photoList.size()) {
            needDeletePhotoList.add(photoList.get(position));
            photoList.remove(position);
        }
        for (int i = 0; i < Define.MAX_PHOTOS; i++) {
            symptomRecordView.setPhoto(i, i < photoList.size() ? photoList.get(i) : null);
        }
        symptomRecordView.enablePickPhoto(true);
    }

    void setPainLevel(int level) {
        symptom.setPainLevel(level);
    }

    void setTreatment(boolean treatment) {
        symptom.setTreatmentFlag(treatment ? 1 : 0);
    }

    /**
     * save symptom record
     * delete all photos which removed by user and waiting for delete from storage
     *
     * @param context view context
     * @param memo    symptom memo
     * @param isBack  is user click back before save
     */
    void saveRecord(Context context, String memo, final boolean isBack) {
        Date currentDate = new Date(System.currentTimeMillis());
        if (isNewSymptomRecord) {
            symptom.setId(RealmManager.getRealmManager().getNextId(Symptom.class));
            symptom.setCreated(currentDate);
        }
        symptom.setModified(currentDate);

        symptom.setMemo(memo);

        symptom.getSymptomPartRelations().clear();
        ArrayList<SymptomPartRelation> symptomPartRelations = new ArrayList<>();
        for (SymptomItem symptomItem : symptomItemList) {
            if (symptomItem.isChosen()) {
                symptomPartRelations.add(RealmManager.getRealmManager()
                        .getSymptomHelper().insertSymptomPartRelation(symptom.getId(), symptomItem.getDetailId()));
            } else {
                RealmManager.getRealmManager().getSymptomHelper().removeSymptomPartRelation(symptom.getId(), symptomItem.getDetailId());
            }
        }
        symptom.getSymptomPartRelations().addAll(symptomPartRelations);

        SavePhotosAsync savePhotosAsync = new SavePhotosAsync(context, photoList);
        savePhotosAsync.setSavePhotosListener(new SavePhotosAsync.SavePhotosListener() {
            @Override
            public void onSavePhotoSuccess(List<Photo> photoList) {
                symptom.getSymptomPhotos().clear();
                for (Photo photo : photoList) {
                    SymptomPhoto symptomPhoto = new SymptomPhoto();
                    symptomPhoto.setFileName(photo.getPath());
                    symptomPhoto.setCreated(new Date(photo.getCreatedTime()));
                    RealmManager.getRealmManager().getSymptomHelper().insertPhoto(symptomPhoto);
                    symptom.getSymptomPhotos().add(symptomPhoto);
                }

                if (isNewSymptomRecord) {
                    RealmManager.getRealmManager().getSymptomHelper().insertRecord(symptom);
                } else {
                    RealmManager.getRealmManager().getSymptomHelper().updateRecord(symptom);
                }
                symptomRecordView.saveCompleted(isBack);
            }
        });

        //remove real photo file in app folder
        for (Photo photo : needDeletePhotoList) {
            if (photo.getPath() != null && photo.getPath().contains(Define.APP_FOLDER_NAME)) {
                FileUtil.removeRecursive(new File(photo.getPath()));
            }
        }

        savePhotosAsync.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
    }
}
