package com.welby.hae.ui.symptomrecord;

import com.welby.hae.model.Photo;
import com.welby.hae.ui.base.BaseView;

import java.util.Calendar;
import java.util.Date;

/**
 * Created by WelbyDev.
 */

interface SymptomRecordView extends BaseView {
    void setStartDate(Calendar cal);

    void setEndDate(Calendar cal);

    void showTimePicker(int dateFlag, Date defaultDate);

    void setPhoto(int position, Photo photo);

    void showPhoto(String photoPath);

    void enablePickPhoto(boolean isEnabled);

    void setPainLevel(int level);

    void saveCompleted(boolean isBack);

    void showTimestampAlert(long timeInMillis);

    void showSeizureDateConflictAlert();

    void showRemovePhotoAlert(int position);

    void setTreatment(boolean isTreatment);

    void setMemo(String memo);

    void solidPart(int partOfBody, boolean isSolid);

    void showPermissionsRequiredAlert(String message);

}
