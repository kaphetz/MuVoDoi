package com.welby.hae.utils;

/**
 * Created by WelbyDev.
 * Filename Define
 */

public class Define {
    public static final String HAE_DB = "hae.realm";

    /**
     * Save image size for A4 paper
     * Current: A4 1220PPI
     */
    public static class SaveImageSize {
        public static final float WIDTH = 8419f;
        public static final float HEIGHT = 5953f;
        public static final float RATIO = WIDTH / HEIGHT;
    }

    public static class SharedPreferenceKey {
        public static final String ACCEPT_TERM_OF_SERVICE = "isAcceptTermOfService";
        public static final String SYMPTOM_RECORD_FIRST_TIME = "symptomRecordFirstTime";
    }

    public static class ExtrasKey {
        public static final String NUMBER_OF_SELECTED_PHOTOS = "numberOfSelectedPhotos";
        public static final String PHOTO = "photoPath";
        public static final String PHOTO_LIST = "photoPaths";
        public static final String CALLER_FLAG = "callerFlag";
        public static final String SYMPTOM_ID = "symptomId";
    }

    public static class BodyPart {
        public static final int MIN = 1;
        public static final int MAX = 13;
        public static final int FACE = 1;
        public static final int BODY = 2;
        public static final int RIGHT_ARM = 3;
        public static final int LEFT_ARM = 4;
        public static final int RIGHT_FINGER = 5;
        public static final int LEFT_FINGER = 6;
        public static final int RIGHT_LEG = 7;
        public static final int LEFT_LEG = 8;
        public static final int RIGHT_TOE = 9;
        public static final int LEFT_TOE = 10;
        public static final int BODY_BACK = 11;
        public static final int RIGHT_LEG_BACK = 12;
        public static final int LEFT_LEG_BACK = 13;
    }

    public static class BodyPartDetail {
        public static final int FACE = 1;
        public static final int BODY = 2;
        public static final int RIGHT_ARM = 3;
        public static final int LEFT_ARM = 4;
        public static final int RIGHT_FINGER = 5;
        public static final int LEFT_FINGER = 6;
        public static final int RIGHT_LEG = 7;
        public static final int LEFT_LEG = 8;
        public static final int RIGHT_TOE = 9;
        public static final int LEFT_TOE = 10;
    }

    public static final String STR_EMPTY = "";
    public static final String STR_RETURN = "\n";
    public static final String STR_COMMAND_JP = "、";
    public static final String STR_BODY_RIGHT = "（右）";
    public static final String STR_BODY_LEFT = "（左）";

    public static final int MAX_PHOTOS = 4;
    public static final String APP_FOLDER_NAME = ".welby_hae";
    public static final String APP_FOLDER_TEMP = ".welby_hae_temp";
    public static final int CLICK_DELAY = 1000;

    public static final String MIME_TYPE_IMAGE = "image/";

    //Share HAE screen
    public static final String URL_1_MINUTE_VIDEO = "https://google.com";
    public static final String URL_EXPLAIN_VIDEO = "https://www.harefukutsuu-hae.jp/";
    public static final String PACKAGE_APP_LINE = "jp.naver.line.android";
    public static final String PACKAGE_APP_GMAIL = "com.google.android.gm";
    public static final String PACKAGE_APP_GMAIL_CLASS_NAME = "com.google.android.gm.ComposeActivityGmail";
    // Guide
    public static final String FIRST_START_APP = "FirstStart";

    //Navigate screen
    public static class Navigate {
        public static final int HOME = 0;
        public static final int SYMPTOM_RECORD = 1;
        public static final int CALENDAR_GRAPH = 2;
        public static final int CALENDAR_SCREEN = 20;
        public static final int CALENDAR_LIST = 21;
        public static final int SHARE_SCREEN = 5;
        public static final int FAMILY_TREE = 6;
        public static final int GUIDE_SCREEN = 8;
        public static final int BACKUP_SCREEN = 9;
        public static final int START_SCREEN = 10;
        public static final int HAE_PAGE = 3;
        public static final int WELBY_PAGE = 11;
    }
}
