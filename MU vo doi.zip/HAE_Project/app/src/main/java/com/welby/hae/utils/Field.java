package com.welby.hae.utils;

/**
 * Created by WelbyDev.
 */

public class Field {


    // Family tree
    public static final String RELATION_ID_WITH_YOU = "relationship_id_with_you";
    public static final String RELATION_ID_WITH_CREATER = "relationship_id_with_creater";
    public static final String CREATER_FAMILY_TREE_ID = "creater_family_tree_id";
    public static final String FATHER_FAMILY_TREE_ID = "father_family_tree_id";
    public static final String MOTHER_FAMILY_TREE_ID = "mother_family_tree_id";
    public static final String CLASS_CODE = "class_code";

    // Symptom field
    public static final String ID = "id";
    public static final String SEIZURE_START_DATE = "seizure_start_date";
    public static final String SYMPTOM_ID = "symptom_id";
    public static final String PART_ID = "part_id";
    public static final String PART_DETAIL_ID = "part_detail_id";
    public static final String TREATMENT_FLAG = "treatment_flag";
    public static final String CREATED = "created";
}
