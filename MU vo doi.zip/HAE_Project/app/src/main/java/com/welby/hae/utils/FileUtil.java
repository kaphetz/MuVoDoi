package com.welby.hae.utils;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

import com.welby.hae.R;
import com.welby.hae.data.db.model.Medication;
import com.welby.hae.data.db.model.Part;
import com.welby.hae.data.db.model.PartDetail;
import com.welby.hae.data.db.model.Relationship;
import com.welby.hae.model.Photo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;

/**
 * Created by WelbyDev.
 */

public class FileUtil<T> {
    private static FileUtil fileUtil;
    private ArrayList<T> arrayList;

    public static FileUtil getInstance() {
        if (fileUtil == null) {
            fileUtil = new FileUtil();
        }
        return fileUtil;
    }

    public ArrayList<T> readDataFromFile(Context context, int fileId) {
        FileReader fileReader = null;
        BufferedReader bufferedReader = null;

        arrayList = new ArrayList<>();

        try {
            InputStream inputStream = context.getResources().openRawResource(fileId);
            bufferedReader = new BufferedReader(new InputStreamReader(inputStream));

            String line;

            while ((line = bufferedReader.readLine()) != null) {
                if (!line.startsWith("#") && !line.trim().isEmpty()) {
                    parserFile(line, fileId);
                }
            }

        } catch (Exception e) {
            RLog.e("importFile error!!!");
        } finally {
            try {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
            } catch (IOException e) {
                RLog.e("Cannot close bufferedReader - " + e.getMessage());
            }

            try {
                if (fileReader != null) {
                    fileReader.close();
                }
            } catch (IOException e) {
                RLog.e("Cannot close fileReader - " + e.getMessage());
            }
        }
        return arrayList;
    }


    private void parserFile(String line, int fileId) {
        String[] fields = line.split(",");
        StringUtil.trim(fields);

        switch (fileId) {
            case R.raw.mediacation:
                Medication medication = new Medication();
                medication.setId(Integer.parseInt(fields[0]));
                medication.setName(fields[1]);
                medication.setCreated(new Date());
                medication.setModified(new Date());
                arrayList.add((T) medication);
                break;
            case R.raw.part:
                Part part = new Part();
                part.setId(Integer.parseInt(fields[0]));
                part.setName(fields[1]);
                part.setCreated(new Date());
                part.setModified(new Date());
                arrayList.add((T) part);
                break;
            case R.raw.part_detail:
                PartDetail partDetail = new PartDetail();
                partDetail.setId(Integer.parseInt(fields[0]));
                partDetail.setName(fields[1]);
                partDetail.setPartId(Integer.parseInt(fields[2]));
                partDetail.setCreated(new Date());
                partDetail.setModified(new Date());
                partDetail.setDetailPartId(Integer.parseInt(fields[5]));
                arrayList.add((T) partDetail);
                break;
            case R.raw.relationship:
                Relationship relationship = new Relationship();
                relationship.setId(Integer.parseInt(fields[0]));
                relationship.setName(fields[1]);
                relationship.setDegreeOfRelationship(Integer.parseInt(fields[2]));
                relationship.setCreatePermissionFlag(Integer.parseInt(fields[3]));
                relationship.setClassCode(fields[4]);
                relationship.setCreated(new Date());
                relationship.setModified(new Date());
                arrayList.add((T) relationship);
                break;
        }
    }

    /**
     * decrease photo quality ~80% and save to app folder
     *
     * @param photoPath path of input photo
     * @param fileName  compressed photo filename
     * @return compressed photo path
     */
    public static String savePhoto(String photoPath, String fileName) {
        String root = Environment.getExternalStorageDirectory().toString();
        File dir = new File(root, Define.APP_FOLDER_NAME);
        dir.mkdirs();
        File file = new File(dir, fileName);
        if (file.exists()) file.delete();
        try {
            FileOutputStream out = new FileOutputStream(file);
            BitmapFactory.decodeFile(photoPath)
                    .compress(Bitmap.CompressFormat.JPEG, 80, out);
            out.flush();
            out.close();
            return file.getAbsolutePath();
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * decrease photo quality ~80% and save to app folder
     *
     * @param bitmap   input photo
     * @param fileName compressed photo filename
     * @return compressed photo path
     */
    public static String savePhoto(Bitmap bitmap, String fileName) {
        String root = Environment.getExternalStorageDirectory().toString();
        File dir = new File(root, Define.APP_FOLDER_NAME);
        dir.mkdirs();
        File file = new File(dir, fileName);
        if (file.exists()) file.delete();
        try {
            FileOutputStream out = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 80, out);
            out.flush();
            out.close();
            return file.getAbsolutePath();
        } catch (Exception e) {
            return null;
        }
    }

    public static void removeTempFile() {
        String root = Environment.getExternalStorageDirectory().toString();
        File dir = new File(root, Define.APP_FOLDER_TEMP);
        removeRecursive(dir);
    }

    public static void removeRecursive(File fileOrDirectory) {
        if (fileOrDirectory.isDirectory() && null != fileOrDirectory.listFiles()) {
            for (File child : fileOrDirectory.listFiles()) {
                removeRecursive(child);
            }
        }
        if(fileOrDirectory.exists()) {
            fileOrDirectory.delete();
        }
    }

    /**
     * create and return temp photo file
     *
     * @return photo file path
     */
    public static Photo getTempPhotoFile() {
        String root = Environment.getExternalStorageDirectory().toString();
        File dir = new File(root, Define.APP_FOLDER_TEMP);
        dir.mkdirs();
        long createdTime = System.currentTimeMillis();
        File file = new File(dir, createdTime + ".jpg");
        if (file.exists()) file.delete();
        return new Photo(file.getAbsolutePath(), createdTime);
    }

    /**
     * create and return app photo file
     *
     * @return photo file path
     */
    public static Photo getPhotoFile() {
        String root = Environment.getExternalStorageDirectory().toString();
        File dir = new File(root, Define.APP_FOLDER_NAME);
        dir.mkdirs();
        long createdTime = System.currentTimeMillis();
        File file = new File(dir, createdTime + ".jpg");
        if (file.exists()) file.delete();
        return new Photo(file.getAbsolutePath(), createdTime);
    }

    public static Date getFileModifiedTime(String filePath) {
        File file = new File(filePath);
        return new Date(file.lastModified());
    }

    public static String getPathFromImageUri(Context context, Uri uri) {
        String result = null;
        Cursor cursor = context.getContentResolver().query(uri, null, null, null, null);
        if (cursor != null) {
            cursor.moveToFirst();
            int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            result = cursor.getString(idx);
            cursor.close();
        }
        return result;
    }
}
