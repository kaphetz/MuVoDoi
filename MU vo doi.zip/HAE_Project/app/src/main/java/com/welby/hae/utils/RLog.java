package com.welby.hae.utils;

import android.util.Log;

import com.welby.hae.BuildConfig;

/**
 * Created by WelbyDev on 18-Aug-17.
 */

public class RLog {
    private static final String TAG = "HAE_Project";

    /**
     * Log: verbose
     * @param message
     */
    public static void v(Object message){
        if(BuildConfig.DEBUG){
            Log.v(TAG, String.valueOf(message));
        }
    }

    /**
     * Log: debug
     * @param message
     */
    public static void d(Object message){
        if(BuildConfig.DEBUG){
            Log.d(TAG, String.valueOf(message));
        }
    }

    /**
     * Log: info
     * @param message
     */
    public static void i(Object message){
        if(BuildConfig.DEBUG){
            Log.i(TAG, String.valueOf(message));
        }

        Log.i(TAG, String.valueOf(message));
    }

    /**
     * Log: warning
     * @param message
     */
    public static void w(Object message){
        if(BuildConfig.DEBUG){
            Log.w(TAG, String.valueOf(message));
        }
    }

    /**
     * Log: error
     * @param message
     */
    public static void e(Object message){
        if(BuildConfig.DEBUG){
            Log.e(TAG, String.valueOf(message));
        }
    }
}
