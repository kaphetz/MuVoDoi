package com.welby.hae.utils;

import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Locale;

/**
 * Support save image in background
 * Created by Welby Dev on 10/31/17.
 */

public class SaveImageAsyncTask extends AsyncTask<Bitmap, Void, Boolean> {
    public static final String TAG = "SaveImageAsyncTask";

    private static final String PREFIX_CAPTURE_FILE = "HAE_IMAGE_%s.jpg";

    private OnSaveImageListener onSaveImageListener;

    public SaveImageAsyncTask(OnSaveImageListener onSaveImageListener) {
        this.onSaveImageListener = onSaveImageListener;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        if (null != onSaveImageListener) {
            onSaveImageListener.onSaveImageStart();
        }
    }

    @Override
    protected Boolean doInBackground(Bitmap... bitmaps) {
        try {
            File mediaStoreDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
            if (mediaStoreDir.exists() || mediaStoreDir.mkdirs()) {
                String fileName = String.format(Locale.getDefault(), PREFIX_CAPTURE_FILE, String.valueOf(System.currentTimeMillis()));

                File myFile = new File(mediaStoreDir.getPath() + File.separator + fileName);
                Log.d(TAG, "Capture file: " + myFile.toString());

                FileOutputStream out = new FileOutputStream(myFile);

                Bitmap bitmap = bitmaps[0];
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
                return true;
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    protected void onPostExecute(Boolean isSuccess) {
        super.onPostExecute(isSuccess);
        if (null != onSaveImageListener) {
            if (isSuccess) {
                onSaveImageListener.onSaveImageSuccess();
            } else {
                onSaveImageListener.onSaveImageFail();
            }
        }
    }

    /**
     * Save image callback
     */
    public interface OnSaveImageListener {
        void onSaveImageStart();
        void onSaveImageSuccess();
        void onSaveImageFail();
    }
}