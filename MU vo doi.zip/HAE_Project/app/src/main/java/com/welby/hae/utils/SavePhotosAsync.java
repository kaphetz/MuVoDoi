package com.welby.hae.utils;

import android.content.Context;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;

import com.welby.hae.R;
import com.welby.hae.model.Photo;

import java.util.List;

/**
 * Created by Welby Dev on 10/24/2017.
 *
 */

public class SavePhotosAsync extends AsyncTask<Void, Void, List<Photo>> {

    private List<Photo> photoList;
    private SavePhotosListener listener;
    private AlertDialog dialog;

    public SavePhotosAsync(Context context, List<Photo> photoList) {
        this.photoList = photoList;
        dialog = new AlertDialog.Builder(context, R.style.CamAlertDialogStyle)
                .setMessage(context.getString(R.string.sr_saving_alert))
                .create();
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        dialog.show();
    }

    @Override
    protected List<Photo> doInBackground(Void... voids) {
        for (Photo photo : photoList) {
            if(!photo.getPath().contains(Define.APP_FOLDER_NAME)) {
                String resultPath = FileUtil.savePhoto(photo.getPath(), photo.getCreatedTime() + ".jpg");
                photo.setPath(resultPath);
            }
        }
        return photoList;
    }

    @Override
    protected void onPostExecute(List<Photo> photoList) {
        super.onPostExecute(photoList);
        dialog.dismiss();
        if (listener != null) {
            listener.onSavePhotoSuccess(photoList);
        }
    }

    public void setSavePhotosListener(SavePhotosListener listener) {
        this.listener = listener;
    }

    public interface SavePhotosListener {
        void onSavePhotoSuccess(List<Photo> photoList);
    }
}
