package com.welby.hae.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * Created by WelbyDev.
 */

public class TimeUtil {
    public static final String FORMAT_1 = "dd-MM-yyyy";
    public static final String FORMAT_2 = "yyyy年MM月dd日（E）HH:mm";
    public static final String FORMAT_3 = "yyyy/MM/dd\nHH:mm";
    public static final String FORMAT_4 = "MM月dd日";
    public static final String FORMAT_5 = "前回記録日……… yyyy/MM/dd HH:mm";
    public static final String FORMAT_6 = "HH:mm";

    /**
     * get time in string with format
     *
     * @param format   datetime format
     * @param datetime input time
     * @return time in string with input format
     */
    public static String getTime(String format, Date datetime) {
        return new SimpleDateFormat(format, Locale.US)
                .format(datetime);
    }

    /**
     * get time in string with format
     *
     * @param format       datetime format
     * @param timeInMillis input time
     * @return time in string with input format
     */
    public static String getTime(String format, long timeInMillis) {
        return new SimpleDateFormat(format, Locale.US)
                .format(new Date(timeInMillis));
    }

    /**
     * get time in string with format
     *
     * @param format       datetime format
     * @param timeInMillis input time
     * @return time in string with input format
     */
    public static String getTime(String format, long timeInMillis, Locale locale) {
        return new SimpleDateFormat(format, locale)
                .format(new Date(timeInMillis));
    }

    /**
     * get time with format
     *
     * @param format datetime format
     * @param time   input time
     * @return time in string with input format
     */
    public static Date getTime(String format, String time) {
        try {
            return new SimpleDateFormat(format, Locale.US)
                    .parse(time);
        } catch (ParseException e) {
            return new Date(0);
        }
    }

    /**
     * get time in millisecond with format
     *
     * @param format datetime format
     * @param time   input time
     * @return time in string with input format
     */
    public static long getTimeInMillis(String format, String time) {
        try {
            return new SimpleDateFormat(format, Locale.US)
                    .parse(time).getTime();
        } catch (ParseException e) {
            return -1;
        }
    }

    /**
     * get current time in string with input format
     *
     * @param format datetime format
     * @return current time in string with input format
     */
    public static String getCurrentTime(String format) {
        return new SimpleDateFormat(format, Locale.US)
                .format(Calendar.getInstance().getTime());
    }

    /**
     * convert date to calendar
     */
    public static Calendar dateToCalendar(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar;

    }

    /***
     * convert calendar to date
     */
    public static Date calendarToDate(Calendar calendar) {
        return calendar.getTime();
    }
}
