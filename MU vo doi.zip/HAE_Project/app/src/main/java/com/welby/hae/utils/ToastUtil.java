package com.welby.hae.utils;

import android.content.Context;
import android.widget.Toast;

/**
 * WelbyDev WelbyDev on 18-Aug-17.
 */

public class ToastUtil {
    private static Toast mToast;

    /**
     * Show Toast by a String
     * @param context
     * @param message
     */
    public static void showToast(Context context, String message){
        if(mToast != null){
            mToast.cancel();
        }
        mToast = Toast.makeText(context, message, Toast.LENGTH_LONG);
        mToast.show();
    }

    /**
     * Show Toast by resource ID content
     * @param context
     * @param messageResID
     */
    public static void showToast(Context context, int messageResID){
        if(mToast != null){
            mToast.cancel();
        }
        mToast = Toast.makeText(context, context.getResources().getString(messageResID), Toast.LENGTH_LONG);
        mToast.show();
    }
}
