package com.welby.hae.utils;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.util.Log;
import android.util.TypedValue;

import com.welby.hae.R;
import com.welby.hae.data.db.Constants;
import com.welby.hae.data.db.model.Member;
import com.welby.hae.model.Photo;

import java.io.File;
import java.util.ArrayList;

import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;

/**
 * Created by WelbyDev.
 * Filename Utils
 */

public class Utils {
    private final static String TAG = Utils.class.getSimpleName();

    public static ArrayList<Photo> getCameraPhotos(Context context) {
        ArrayList<Photo> result = new ArrayList<>();
        Uri uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {MediaStore.Images.ImageColumns.DATA,
                MediaStore.Images.ImageColumns.DATE_TAKEN};
        String orderBy = MediaStore.Images.ImageColumns.DATE_TAKEN + " DESC";
        Cursor c = context.getContentResolver().query(uri, projection, null, null, orderBy);
        if (c != null) {
            while (c.moveToNext()) {
                String imagePath = c.getString(0);
                long takenTime = c.getLong(1);
                if (imagePath == null) {
                    continue;
                }
                if (new File(imagePath).exists()) {
                    result.add(new Photo(imagePath, takenTime));
                }
            }
            c.close();
        }
        return result;
    }

    /**
     * format dp to px
     *
     * @param context context
     * @param dp      dp
     */
    public static int dpToPx(Context context, int dp) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, context.getResources().getDisplayMetrics());
    }

    public static String getAssetsTxtByName(Context context, String name) {
        try {
            InputStream is = context.getAssets().open(name);
            int size = is.available();

            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();

            return new String(buffer, "UTF-8");

        } catch (IOException e) {
            e.printStackTrace();
            return "";
        }
    }


    public static int getImageResourceMember(@NonNull Context context, Member member) {
        int image_resource = R.drawable.ic_you_woman;
        if (member != null) {
            String class_code = member.getRelationshipIdWithYou().getClassCode();
            String gender = member.getGenderCode();
            String image_name = String.format(Locale.getDefault(), "ic_%s_%s", class_code, gender);
            image_resource = context.getResources().getIdentifier(image_name, "drawable", context.getPackageName());
        }

        return image_resource;
    }
}
