package com.welby.hae.utils.graph;

import android.content.Context;

import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.welby.hae.R;

/**
 * Created by WelbyDev.
 */

public class GraphXAxisValueFormatter implements IAxisValueFormatter {
    private Context context;
    private float startMonth;
    private int monthCount;

    public GraphXAxisValueFormatter(Context context, float startMonth, int monthCount) {
        this.context = context;
        this.startMonth = startMonth;
        this.monthCount = monthCount;
    }

    @Override
    public String getFormattedValue(float value, AxisBase axis) {
        if (value < startMonth || value >= startMonth + monthCount) {
            if (value == startMonth - 1) {
                return context.getString(R.string.calendar_graph_month_title);
            } else {
                return "";
            }
        }
        if (value < 0f) {
            value += 13;
        } else {
            value += 1;
        }
        return String.valueOf((int) value);
    }
}
