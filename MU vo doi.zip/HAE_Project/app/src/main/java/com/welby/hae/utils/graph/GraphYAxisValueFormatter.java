package com.welby.hae.utils.graph;

import android.content.Context;

import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.welby.hae.R;

import java.text.DecimalFormat;

/**
 * Created by WelbyDev.
 */

public class GraphYAxisValueFormatter implements IAxisValueFormatter
{
    private Context context;
    private DecimalFormat mFormat;

    public GraphYAxisValueFormatter(Context context) {
        mFormat = new DecimalFormat("###,###,###,###");
        this.context = context;
    }

    @Override
    public String getFormattedValue(float value, AxisBase axis) {
        return "";
    }
}
