package com.welby.hae.utils.graph;

import android.content.Context;

import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.welby.hae.R;

import java.text.DecimalFormat;

/**
 * Created by WelbyDev.
 */

public class PartGraphYAxisValueFormatter implements IAxisValueFormatter
{
    private Context context;
    private DecimalFormat mFormat;

    public PartGraphYAxisValueFormatter(Context context) {
        mFormat = new DecimalFormat("###,###,###,###");
        this.context = context;
    }

    @Override
    public String getFormattedValue(float value, AxisBase axis) {
        if (value == 0f) {
            value = 1f;
        } else if (value % 5 != 0) {
            return "";
        }
        return mFormat.format(value);
    }
}
