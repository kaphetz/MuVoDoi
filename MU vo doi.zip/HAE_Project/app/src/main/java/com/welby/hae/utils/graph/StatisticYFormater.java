package com.welby.hae.utils.graph;

import android.content.Context;

import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.formatter.IValueFormatter;
import com.github.mikephil.charting.utils.ViewPortHandler;
import com.welby.hae.R;

/**
 * Created by WelbyDev.
 */

public class StatisticYFormater implements IValueFormatter {
    private Context context;

    public StatisticYFormater(Context context) {
        this.context = context;
    }

    @Override
    public String getFormattedValue(float value, Entry entry, int dataSetIndex, ViewPortHandler viewPortHandler) {
        if (entry.getY() == 0) {
            return "";
        }
        return (int) entry.getY() + context.getString(R.string.calendar_graph_time_character);
    }
}
